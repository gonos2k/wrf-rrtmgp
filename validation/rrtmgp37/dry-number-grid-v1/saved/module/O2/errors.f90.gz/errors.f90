module module_wrf_error
contains
subroutine wrf_debug(level,text)
integer,intent(in)::level
character(*),intent(in)::text
end subroutine
end module
subroutine wrf_error_fatal(text)
character(*),intent(in)::text
print *,text
error stop 2
end subroutine
