from pathlib import Path
import json,gzip,hashlib,shutil,netCDF4,numpy as np
r=Path('/NHNHOME/WORKSPACE/26weather002_A/yhlee/RRTMGP/build/udm37-sustained-pr-work');b=r/'validation/rrtmgp37/sustained-research';runs=r.parent/'udm37-sustained-v2'
sha=lambda x:hashlib.sha256(x).hexdigest()
def save(n,x):
 p=b/'saved'/(n+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(x,mtime=0))
def file(n,p):save(n,Path(p).read_bytes())
def js(n,x):save(n,(json.dumps(x,indent=2)+'\n').encode())
def packet(n,p):
 data=bytearray();rows=[]
 with netCDF4.Dataset(p) as d:
  attrs={n:int(d.getncattr(n)) for n in ('UDM_NUMBER_POLICY','UDM_POPULATION_POLICY','RRTMGP_CAPACITY_POLICY','RRTMGP_LIQUID_SIZE_POLICY')}
  for name,v in d.variables.items():
   if 'Time' not in v.dimensions:continue
   a=np.asarray(v[:]);x=a.tobytes();rows.append({'variable':name,'dtype':a.dtype.str,'shape':list(a.shape),'offset':len(data),'bytes':len(x),'sha256':sha(x),'units':getattr(v,'units',''),'description':getattr(v,'description','')});data.extend(x)
 js('host/'+n+'.json',{'source_NetCDF_sha256':sha(p.read_bytes()),'attrs':attrs,'records':rows,'payload_sha256':sha(data)});save('host/'+n+'.bin',data)
for stage in ('hour','day','restart'):
 d=runs/('restart-aligned' if stage=='restart' else stage);file(stage+'/receipt.json',d/'receipt.json')
 if (d/'preregistration.json').exists():file(stage+'/preregistration.json',d/'preregistration.json')
 for p in d.glob('command-*.json'):file(stage+'/'+p.name,p)
 rec=json.loads((d/'receipt.json').read_text())
 for i,c in enumerate(rec['processes'],1):
  name=c['kind'];case=d/name
  file('logs/'+name+'.stdout',d/f'command-{i:02d}.stdout')
  file('logs/'+name+'.stderr',d/f'command-{i:02d}.stderr')
  file('namelist/'+name,case/'namelist.input')
  packet(name,next(case.glob('wrfout*')))
  for p in (case/'capture').iterdir():file('capture/'+name+'/'+p.name,p)
  if name=='day_11':packet('checkpoint21610',case/'wrfrst_d01_1999-10-23_01:00:10')
for p in (r.parent/'udm37-sustained-v1/hour').glob('command-*'):file('attempts/loader/'+p.name,p)
file('attempts/loader/receipt.json',r.parent/'udm37-sustained-v1/hour/receipt.json')
file('attempts/loader/preregistration.json',r.parent/'udm37-sustained-v1/hour/preregistration.json')
for n in ['udm37-sustained-v2-launch.log','udm37-sustained-v2-restart-launch.log']:
 file('attempts/harness/'+n,r.parent/n)
for attempt in ('restart','restart-timers'):
 d=runs/attempt
 for p in d.glob('command-*'):file('attempts/'+attempt+'/'+p.name,p)
 file('attempts/'+attempt+'/receipt.json',d/'receipt.json')
 file('attempts/'+attempt+'/namelist.input',d/'resumed_11/namelist.input')
 packet('attempt_'+attempt,next((d/'resumed_11').glob('wrfout*')))
file('recipe/pack.py',__file__)
for name in ('resume_sustained.py','resume_sustained_timers_run.py','resume_sustained_aligned.py'):file('recipe/'+name,'/tmp/'+name)
inputs={}
for choice in ('00','11'):
 p=runs/'day'/('day_'+choice)/'wrfinput_d01'
 file('input/wrfinput_'+choice+'.nc',p)
 with netCDF4.Dataset(p) as nc:
  inputs[choice]={'physical_arrays':{n:sha(np.asarray(v[:]).tobytes()) for n,v in nc.variables.items()},'policies':[int(nc.getncattr('RRTMGP_CAPACITY_POLICY')),int(nc.getncattr('RRTMGP_LIQUID_SIZE_POLICY'))]}
if inputs['00']['physical_arrays']!=inputs['11']['physical_arrays']:raise ValueError('physical inputs differ')
js('input/identity.json',inputs)
for name in ('run_research_radiation_sustained.py','resume_research_radiation_sustained.py'):
 file('recipe/'+name,r/'WRF/test/rrtmgp'/name)
source=json.loads((r/'validation/rrtmgp37/research-radiation-integration/identity.json').read_text())
require=all(sha((r/p).read_bytes())==h for p,h in source['source_files'].items())
if not require:raise ValueError('runtime source changed')
identity={'baseline_commit':'038f53e9f3002f0379a0c54426559424dc278071','baseline_tree':'d143ddd13e045263603aa28e757a627bd1b0e726','source_files':source['source_files'],'execution':source['execution'],'library_binding':'Exact executable from PR180; full linked-library/build receipts retained in research-radiation-integration/identity.json and saved/build.','new_WRF_model_processes':7,'qualified_sustained_and_aligned_restart_processes':5,'completed_output_timer_deviation_and_probe_processes':2,'loader_failures_before_model':2,'harness_failures_before_launch':2,'normal_completed_model_processes':7,'new_WRF_builds':0,'production_accepted':False,'defaults_changed':False,'runtime_source_changed':False,'seven_closure_conditions_changed':False,'long_run_actual_applied_energy_budget':'NOT_ASSESSED_NO_NEW_ACOUSTIC_OBSERVER','whole_host_water_budget_approved':False}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
shutil.copy2(r/'validation/rrtmgp37/research-radiation-integration/closure-conditions.json',b/'closure-conditions.json')
print('packed',len(list((b/'saved').rglob('*.gz'))))
