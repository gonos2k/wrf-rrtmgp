from pathlib import Path
import importlib.util,datetime as dt,json,os,shutil,sys
import netCDF4,numpy as np
r=Path('/NHNHOME/WORKSPACE/26weather002_A/yhlee/RRTMGP/build/udm37-sustained-pr-work')
b=r.parent/'udm37-sustained-v2'
sys.path.insert(0,str(r/'WRF/test/rrtmgp'))
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
h=load(r/'WRF/test/rrtmgp/test_netcdf_zz.py','runner');setup=load(r/'WRF/test/rrtmgp/test_udm_startup_snow_scm.py','setup')
case=b/'day/day_11';checkpoint=case/'wrfrst_d01_1999-10-23_01:00:10'
if not checkpoint.exists():raise RuntimeError('continuous checkpoint not yet available')
out=b/'restart-timers';out.mkdir(exist_ok=False);d=out/'resumed_11';d.mkdir()
for p in case.iterdir():
 if p.is_file() and not p.name.startswith(('wrfout','wrfrst','rsl.','udm_')) and p.name not in ('stdout.log','namelist.output'):shutil.copy2(p,d/p.name)
shutil.copy2(checkpoint,d/checkpoint.name)
text=(case/'namelist.input').read_text()
settings={'run_days':'0','run_hours':'0','run_minutes':'10','run_seconds':'0','end_hour':'1','end_minute':'10','end_second':'10','start_day':'23','start_hour':'1','start_minute':'0','start_second':'10','restart':'.true.','write_hist_at_0h_rst':'.true.','restart_interval_s':'0','override_restart_timers':'.true.','history_begin_s':'290'}
for k,v in settings.items():text=setup.set_assignment(text,k,v,group='time_control')
(d/'namelist.input').write_text(text);(d/'capture').mkdir()
env=dict(os.environ,OMP_NUM_THREADS='1',LD_LIBRARY_PATH=str(r.parent/'deps/netcdf/lib')+':'+os.environ.get('LD_LIBRARY_PATH',''))
for k in list(env):
 if k.startswith(('WRF_RRTMGP_','WRF_UDM_','WRF_RESEARCH_','WRF_RADIATION_ENERGY')):env.pop(k)
env.update(WRF_RRTMGP_CAPTURE_DIR=str(d/'capture'),WRF_RRTMGP_CAPTURE_CALL='1',WRF_RRTMGP_BATCH_SIZE='1')
runner=h.Runner(out,10800,env,1)
receipt={'schema':'SUSTAINED_RESTART_V1','preregistration':h.pin(b/'day/preregistration.json'),'checkpoint':h.pin(checkpoint),'executable':h.pin(r.parent/'udm37-radiation-options-build-v1/producer/main/wrf'),'status':'PREPARED','production_accepted':False}
h.write_json(out/'receipt.json',receipt)
try:
 log=runner.run([r.parent/'udm37-radiation-options-build-v1/producer/main/wrf'],d,'resumed_11').read_text()
 receipt['status']='COMPLETED' if 'SUCCESS COMPLETE WRF' in log and 'FATAL CALLED' not in log else 'MODEL_REJECTED'
finally:
 receipt['processes']=runner.commands;h.write_json(out/'receipt.json',receipt)
print(receipt['status'],flush=True)
