from pathlib import Path
import re,os,shlex,subprocess,json,hashlib,shutil,importlib.util
root=Path.cwd();b=root.parent/'udm37-budget-observer-v2';b.mkdir(exist_ok=False);old=root.parent/'udm37-cf0-transition-build-v1/producer';src=(root/'WRF/dyn_em/solve_em.F').read_text()
# This diagnostic-only object links against the exact retained PR174 archive.
# Neither the retained archive/source nor production core is modified.
fields=['-(grid%c1h(k)*grid%mut(i,j)+grid%c2h(k))*grid%dnw(k)/g','grid%rho(i,k,j)','dz8w(i,k,j)','th_phy(i,k,j)*pi_phy(i,k,j)','moist(i,k,j,P_QV)','moist(i,k,j,P_QC)','moist(i,k,j,P_QR)','scalar(i,k,j,P_QNN)','scalar(i,k,j,P_QNC)','scalar(i,k,j,P_QNR)','grid%rainnc(i,j)','grid%udm_cldfra(i,k,j)','p_phy(i,k,j)','grid%dx*grid%dy/(grid%msftx(i,j)*grid%msfty(i,j))','g','cp','cpv','xlv','grid%qfx(i,j)','grid%hfx(i,j)','grid%lh(i,j)','grid%mut(i,j)','grid%c1h(k)','grid%c2h(k)','grid%dnw(k)']
src=src.replace('   IMPLICIT NONE','   IMPLICIT NONE\n! BUDGET_OBSERVER_BEGIN\n   character(len=8) :: udm_budget_env\n! BUDGET_OBSERVER_END',1) if '   IMPLICIT NONE' in src else src.replace('   implicit none','   implicit none\n! BUDGET_OBSERVER_BEGIN\n   character(len=8) :: udm_budget_env\n! BUDGET_OBSERVER_END',1)
assert 'udm_budget_env' in src

def block(phase):
 s='! BUDGET_OBSERVER_BEGIN\n     udm_budget_env=""\n     call get_environment_variable("WRF_UDM_BUDGET",udm_budget_env)\n     if(trim(udm_budget_env)=="1") then\n     do j=jds,jde-1\n     do k=kds,kde-1\n     do i=ids,ide-1\n'
 s+=f'       write(*,\'(a,4(i0,1x),25(es24.16,1x))\') "MB_{phase} ",grid%itimestep,i,j,k, &\n'
 s+='        '+', &\n        '.join('real('+x+',8)' for x in fields)+'\n'
 s+='     enddo\n     enddo\n     enddo\n     endif\n! BUDGET_OBSERVER_END\n';return s
anchor='     CALL microphysics_driver(                                            &';assert src.count(anchor)==1;src=src.replace(anchor,block('PRE')+anchor)
anchor='BENCH_END(micro_driver_tim)';assert src.count(anchor)==1;src=src.replace(anchor,block('POST')+anchor)

rfields=['t_tendf(i,k,j)','grid%c1h(k)*grid%mut(i,j)+grid%c2h(k)','grid%dnw(k)','grid%p(i,k,j)+grid%pb(i,k,j)','grid%t_2(i,k,j)+300.','moist(i,k,j,P_QV)','grid%dt','g','cp','r_d','r_v','grid%dx*grid%dy/(grid%msftx(i,j)*grid%msfty(i,j))']
def rblock(phase):
 text='! BUDGET_OBSERVER_BEGIN\n     udm_budget_env=""\n     call get_environment_variable("WRF_UDM_BUDGET",udm_budget_env)\n     if(trim(udm_budget_env)=="1" .and. rk_step==1) then\n     do j=jds,jde-1\n     do k=kds,kde-1\n     do i=ids,ide-1\n'
 text+=f'       write(*,\'(a,5(i0,1x),12(es24.16,1x))\') "RF_{phase} ",grid%itimestep,rk_step,i,j,k, &\n'
 text+='        '+', &\n        '.join('real('+x+',8)' for x in rfields)+'\n'
 return text+'     enddo\n     enddo\n     enddo\n     endif\n! BUDGET_OBSERVER_END\n'
anchor='       CALL rk_tendency ( config_flags, rk_step'
assert src.count(anchor)==1;src=src.replace(anchor,rblock('PRE')+anchor)
pos=src.index('BENCH_END(rk_tend_tim)');end=src.rfind('     END DO',0,pos);src=src[:end]+rblock('POST')+src[end:]
assert re.sub(r'! BUDGET_OBSERVER_BEGIN\n.*?! BUDGET_OBSERVER_END\n','',src,flags=re.S)==(root/'WRF/dyn_em/solve_em.F').read_text()
(b/'solve_em.F').write_text(src);(b/'modules').mkdir()
spec=importlib.util.spec_from_file_location('h',root/'WRF/test/rrtmgp/test_netcdf_zz.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);runner=h.Runner(b,240,{**os.environ},5)
flags=(old/'CMakeFiles/WRF_Core.dir/flags.make').read_text();args=[]
for key in ('Fortran_DEFINES','Fortran_INCLUDES','Fortran_FLAGS'):
 value=re.search('^'+key+r' = (.*)$',flags,re.M).group(1);args+=shlex.split(value)
args=[x for x in args if not x.startswith('-J')]+['-J'+str(b/'modules')]
runner.run(['/usr/bin/gfortran',*args,'-ffree-form','-cpp','-O2','-ftree-vectorize','-funroll-loops','-ffree-line-length-none','-fallow-argument-mismatch','-fallow-invalid-boz','-c',b/'solve_em.F','-o',b/'solve_em.F.o'],b,'compile_diagnostic_solve_em')
shutil.copy2(old/'libWRF_Core.a',b/'libWRF_Core.a');runner.run(['ar','r',b/'libWRF_Core.a',b/'solve_em.F.o'],b,'replace_only_diagnostic_member')
# Resolve the original link command without touching its build directory.
args=shlex.split((old/'main/CMakeFiles/wrf.dir/link.txt').read_text());out=[];skip=False
for n,x in enumerate(args):
 if skip:skip=False;continue
 if x.startswith('-Wl,--dependency-file='):continue
 if x=='-o':out+=['-o',str(b/'wrf')];skip=True;continue
 if x=='../libWRF_Core.a':out.append(str(b/'libWRF_Core.a'))
 elif x.endswith(('.a','.o')) and not x.startswith('/'):out.append(str((old/'main'/x).resolve()))
 else:out.append(x)
runner.run(out,b,'link_diagnostic_host');h.write_json(b/'receipt.json',{'status':'BUILT_DIAGNOSTIC_ONLY','base_archive':h.pin(old/'libWRF_Core.a'),'base_executable':h.pin(old/'main/wrf'),'new_archive':h.pin(b/'libWRF_Core.a'),'executable':h.pin(b/'wrf'),'original_source':h.pin(root/'WRF/dyn_em/solve_em.F'),'diagnostic_source':h.pin(b/'solve_em.F'),'fields':fields,'rk_forcing_fields':rfields,'commands':runner.commands,'production_source_changed':False})
print(b)
