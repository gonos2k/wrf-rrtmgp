from pathlib import Path
import os,sys,shutil,json,importlib.util,netCDF4,numpy as np
r=Path.cwd();b=r.parent/'udm37-budget-host-v2';b.mkdir(exist_ok=False);source=r.parent/'udm37-cf0-scm-v3/control';exe=r.parent/'udm37-budget-observer-v1/wrf'
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
sys.path.insert(0,str(r/'WRF/test/rrtmgp'));h=load(r/'WRF/test/rrtmgp/test_netcdf_zz.py','h');setup=load(r/'WRF/test/rrtmgp/test_udm_startup_snow_scm.py','setup');env={**os.environ,'OMP_NUM_THREADS':'1','LD_LIBRARY_PATH':str(r.parent/'deps/netcdf/lib')}
for k in tuple(env):
 if k.startswith(('WRF_RRTMGP_','WRF_UDM_')):env.pop(k)
runner=h.Runner(b,180,env,5);out={'schema':'ACTUAL_POLICY2_HOST_BUDGET','executable':h.pin(exe),'processes':[],'production_accepted':False}
for name,dt,on in [('off_dt10',10,False),('on_dt10',10,True),('on_dt5',5,True)]:
 d=b/name;d.mkdir()
 for p in source.iterdir():
  if p.is_file() and not p.name.startswith(('wrfout','wrfrst','rsl.','udm_')) and p.name not in ('namelist.output','stdout.log'):shutil.copy2(p,d/p.name)
 text=(source/'namelist.input').read_text();text=setup.set_assignment(text,'time_step',str(dt),group='domains');text=setup.set_assignment(text,'restart_interval_s','0',group='time_control');(d/'namelist.input').write_text(text)
 runner.environment['WRF_UDM_BUDGET']='1' if on else '0';p=runner.run([exe],d,'WRF_'+name);out['processes']=runner.commands;h.write_json(b/'receipt.json',out);assert 'SUCCESS COMPLETE WRF' in p.read_text()
with netCDF4.Dataset(next((b/'off_dt10').glob('wrfout*'))) as x, netCDF4.Dataset(next((b/'on_dt10').glob('wrfout*'))) as y, netCDF4.Dataset(next(source.glob('wrfout*'))) as z:
 count=0
 for n in x.variables:
  if 'Time' in x[n].dimensions:
   assert np.asarray(x[n][:]).tobytes()==np.asarray(y[n][:]).tobytes()==np.asarray(z[n][:]).tobytes(),n;count+=1
out.update(status='PASS_SCOPED_OBSERVER_NONINTERFERENCE_AND_DT_CAMPAIGN',all_history_arrays_observer_OFF_ON_PR174_bytes_equal=count);h.write_json(b/'receipt.json',out);print(json.dumps(out))
