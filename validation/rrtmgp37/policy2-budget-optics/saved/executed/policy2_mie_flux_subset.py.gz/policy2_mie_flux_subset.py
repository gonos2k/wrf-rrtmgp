from pathlib import Path
import os,json,importlib.util,shutil
r=Path.cwd();b=r.parent/'udm37-independent-mie-flux-v3';b.mkdir(exist_ok=False);old=r.parent/'udm37-cf0-psd-optics-v6';alt=r.parent/'udm37-independent-mie-scoped-tables-v1';exe=r.parent/'udm37-cf0-psd-optics-v4/build/column'
s=importlib.util.spec_from_file_location('h',r/'WRF/test/rrtmgp/test_netcdf_zz.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);runner=h.Runner(b,90,{**os.environ,'LD_LIBRARY_PATH':str(r.parent/'deps/netcdf/lib')},4)
for ph in ('lw','sw'):
 for mode,data in [('baseline',r/'WRF/run'),('mie_band6',alt)]:
  d=b/(ph+'-'+mode);d.mkdir();(d/'capture').mkdir();shutil.copyfile(r.parent/'udm37-mie-scoped-inputs-v1'/(ph+'.input'),d/'input');runner.environment['WRF_RRTMGP_CAPTURE_DIR']=str(d/'capture');runner.run([exe,data,d/'input'],d,'RTE_'+ph+'_'+mode)
h.write_json(b/'receipt.json',{'status':'PASS_SCOPED_INDEPENDENT_OPTICAL_COEFFICIENT_SENSITIVITY','executable':h.pin(exe),'commands':runner.commands,'fresh_RTE_columns':4,'held_source_time_seconds':50,'spectral_override':'only band6 in each phase; other LUT coefficients unchanged','optical_temperature_K':298.15,'production_accepted':False});print('4 coefficient-controlled RTE columns completed')
