from pathlib import Path
import os,sys,shutil,json,importlib.util,netCDF4,numpy as np
r=Path.cwd();b=r.parent/'udm37-budget-geometry-v1';b.mkdir(exist_ok=False);source=r.parent/'udm37-cf0-scm-v3/control';exe=r.parent/'udm37-budget-observer-v1/wrf'
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
sys.path.insert(0,str(r/'WRF/test/rrtmgp'));h=load(r/'WRF/test/rrtmgp/test_netcdf_zz.py','h');setup=load(r/'WRF/test/rrtmgp/test_udm_startup_snow_scm.py','setup');env={**os.environ,'OMP_NUM_THREADS':'1','LD_LIBRARY_PATH':str(r.parent/'deps/netcdf/lib')}
for k in tuple(env):
 if k.startswith(('WRF_RRTMGP_','WRF_UDM_')):env.pop(k)
runner=h.Runner(b,180,env,5);out={'schema':'ACTUAL_POLICY2_HOST_BUDGET','executable':h.pin(exe),'processes':[],'production_accepted':False}
for name,dt,on in [('on_dt10',10,True),('on_dt5',5,True)]:
 d=b/name;d.mkdir()
 for p in source.iterdir():
  if p.is_file() and not p.name.startswith(('wrfout','wrfrst','rsl.','udm_')) and p.name not in ('namelist.output','stdout.log'):shutil.copy2(p,d/p.name)
 # Separate geometry control: preserve all q/N/T/P/AL, align Phi with stored dry mass and alpha.
 with netCDF4.Dataset(d/'wrfinput_d01','r+') as x:
  md=-(np.asarray(x['MU'][0],float)+x['MUB'][0])[None,:,:]*np.asarray(x['DNW'][0,:],float)[:,None,None]/9.81
  alpha=np.asarray(x['AL'][0],float)+x['ALB'][0];newphi=np.zeros((60,2,2));newphi[0]=np.asarray(x['PH'][0,0],float)+x['PHB'][0,0]
  newphi[1:]=newphi[0]+np.cumsum(md*alpha*9.81,axis=0);x['PH'][0]=newphi-np.asarray(x['PHB'][0],float);ztop=float(np.mean(newphi[-1]/9.81));x['ZETATOP'][:]=ztop
 text=(source/'namelist.input').read_text();text=setup.set_assignment(text,'ztop',str(ztop),group='domains');text=setup.set_assignment(text,'time_step',str(dt),group='domains');text=setup.set_assignment(text,'restart_interval_s','0',group='time_control');(d/'namelist.input').write_text(text)
 runner.environment['WRF_UDM_BUDGET']='1' if on else '0';p=runner.run([exe],d,'WRF_'+name);out['processes']=runner.commands;h.write_json(b/'receipt.json',out);assert 'SUCCESS COMPLETE WRF' in p.read_text()
out.update(status='COMPLETED_SEPARATE_GEOMETRIC_CONTROL',changed_initial_variables=['PH','ZETATOP'],changed_namelist=['time_step','ztop','restart_interval_s'],original_initial_q_N_T_P_alpha_unchanged=True,production_accepted=False);h.write_json(b/'receipt.json',out);print(json.dumps(out))
