from pathlib import Path
import os,sys,json,math,time,hashlib
os.environ['MIEPYTHON_USE_JIT']='1';sys.path.insert(0,str(Path('../deps/miepython-3.2.0').resolve()))
import miepython as mie,numpy as np,scipy.integrate as it,netCDF4
from numpy.polynomial.legendre import leggauss
r=Path.cwd();b=r.parent/'udm37-independent-mie-v2';b.mkdir(exist_ok=False);water=r.parent/'udm37-budget-optics-inputs/Hale.yml';data=[]
for line in water.read_text().splitlines():
 try:
  p=list(map(float,line.split()));
  if len(p)==3:data.append(p)
 except ValueError:pass
a=np.array(data);wl=a[:,0];rn=a[:,1];ik=a[:,2]
# Independent Mie engine published regression (Wiscombe reference, x=2).
q=mie.efficiencies_mx(1.5-.1j,2.);expected=[1.9414784337094506,1.286167973654895,.12792139607594125,.6570830247066466];assert np.allclose(q,expected,rtol=1e-10)
meta={'candidate':'final-liquid-gamma-veff-0p1-v1','water_temperature_K':298.15,'water_source':'Hale-Querry1973; CC0 transcription by refractiveindex.info','water_source_sha256':hashlib.sha256(water.read_bytes()).hexdigest(),'miepython_version':mie.__version__,'complex_index_sign':'n-ik','k':8,'effective_variance':.1,'radius_um':[8.,12.,20.],'bands':[('sw',8),('sw',6),('sw',4),('lw',6)],'band_weightings':['uniform_wavenumber','Planck5780_SW_or298.15_LW'],'predeclared_convergence_relative':.01,'predeclared_LUT_equivalence_screen_relative':.05,'predeclared_LUT_g_absolute_screen':.02,'scope':'independent isothermal spherical optical diagnostic; not measured cloud PSD or unknown publisher band weighting certification','records':[],'production_accepted':False}

def calc(ph,ib,reff,nr,ns):
 with netCDF4.Dataset(r/f'WRF/run/rrtmgp-clouds-{ph}-bnd.nc') as d:bounds=np.array(d['bnd_limits_wavenumber'][:])[ib-1]
 lo,hi=bounds;x,w=leggauss(ns);nu=(lo+hi)/2+(hi-lo)/2*x;lamlight=1e4/nu;m=np.interp(lamlight,wl,rn)-1j*np.exp(np.interp(lamlight,wl,np.log(ik)))
 # Gamma area-weight measure, x=lambda_PSD*r, shape k+2=10.
 gx=np.linspace(0.,60.,nr+1);area=gx**9*np.exp(-gx)/math.gamma(10);area[0]=0.;radius=gx*reff/10.;mom=[]
 for L,M in zip(lamlight,m):
  qe,qs,qb,g=mie.efficiencies_mx(M,2*np.pi*radius[1:]/L);qe=np.r_[0.,qe];qs=np.r_[0.,qs];g=np.r_[0.,g];f=3/(4*1000*reff*1e-6)/1000
  e=f*it.simpson(area*qe,x=gx);s=f*it.simpson(area*qs,x=gx);sg=f*it.simpson(area*qs*g,x=gx);mom.append([e,s,e-s,sg])
 mom=np.array(mom);out={}
 for weighting in ('uniform_wavenumber','Planck'):
  T=5780. if ph=='sw' else 298.15;weights=w if weighting=='uniform_wavenumber' else w*nu**3/np.expm1(1.438776877*nu/T);band=np.sum(mom*weights[:,None],axis=0)/np.sum(weights);out[weighting]={'ext':float(band[0]),'sca':float(band[1]),'abs':float(band[2]),'sca_g':float(band[3]),'g':float(band[3]/band[1])}
 return out
for ph,ib in meta['bands']:
 with netCDF4.Dataset(r/f'WRF/run/rrtmgp-clouds-{ph}-bnd.nc') as d:
  grid=np.linspace(float(d['radliq_lwr'][:]),float(d['radliq_upr'][:]),d['extliq'].shape[-1]);tables={n:np.array(d[n][:]) for n in ('extliq','ssaliq','asyliq')}
 for reff in meta['radius_um']:
  row={'phase':ph,'band':ib,'reff_um':reff,'calculations':{}}
  for nr,ns in ((512,24),(1024,48),(2048,96)):
   z=calc(ph,ib,reff,nr,ns);row['calculations'][f'r{nr}_s{ns}']=z
  ext=float(np.interp(reff,grid,tables['extliq'][ib-1]));ssa=float(np.interp(reff,grid,tables['ssaliq'][ib-1]));g=float(np.interp(reff,grid,tables['asyliq'][ib-1]));row['LUT']={'ext':ext,'sca':ext*ssa,'abs':ext*(1-ssa),'sca_g':ext*ssa*g,'g':g};meta['records'].append(row)
  (b/'result.json').write_text(json.dumps(meta,indent=2)+'\n');print(ph,ib,reff,row['calculations']['r2048_s96']['Planck'],flush=True)
meta['status']='COMPLETED_INDEPENDENT_MIE_DIAGNOSTIC';(b/'result.json').write_text(json.dumps(meta,indent=2)+'\n')
