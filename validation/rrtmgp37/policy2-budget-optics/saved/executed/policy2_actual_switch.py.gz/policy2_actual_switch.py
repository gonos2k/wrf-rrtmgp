from pathlib import Path
import re,json,os,importlib.util,shutil
r=Path.cwd();b=r.parent/'udm37-actual-switch-v1';b.mkdir(exist_ok=False)
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
h=load(r/'WRF/test/rrtmgp/test_netcdf_zz.py','h');old=load(r/'WRF/test/rrtmgp/test_udm_cf0_transition.py','old');raw=(r/'WRF/phys/module_mp_udm.F').read_bytes();s=old.observer(raw).decode();anchor='! Restore states AND tendencies once, before existing grid donor/update limits.\n';assert s.count(anchor)==1
new='! CF0_TEST_BEGIN\n   do k=kts,ktopini\n     call capture("SWITCH_LOCAL",i,k,loop, &\n       [cldf(k),footprint(k),qci(k,i,1),qrs(k,i,1),ncr(k,i,2),ncr(k,i,3), &\n        rslope(k,1),nrcol(k),prevp(k),praut(k),pracw(k),ncaut(k),nraut(k),nccol(k),nracw(k)])\n   enddo\n! CF0_TEST_END\n';s=s.replace(anchor,new+anchor);assert re.sub(r'! CF0_TEST_BEGIN\n.*?! CF0_TEST_END\n','',s,flags=re.S).encode()==raw
(b/'observed.F').write_text(s);(b/'production.F').write_bytes(raw)
f=old.fixture(r/'WRF').decode();a=f.index('  ! Direct production exchange');z=f.index("  print *, 'REPRESENTATION_PROBE_PASS'",a)+len("  print *, 'REPRESENTATION_PROBE_PASS'\n");f=f[:a]+f[z:]
f=f.replace('qc=0.; qr=1.e-4','qc=.95e-6; qr=9.7907372e-3').replace('if(b==2) qc=5.e-7','if(b==2) qc=1.05e-6').replace('qc=5.e-7; qr=0.','qc=2.e-6; qr=9.7907372e-3').replace('nn=2.e8/den; nc=5.e5/den; nr=1.e5/den','nn=2.e8/den; nc=161797.5/den; nr=815809./den')
runner=h.Runner(b,120,{**os.environ},20);fc=shutil.which('gfortran');flags=['-O2','-g','-ffree-form','-ffree-line-length-none','-fcheck=all','-J'+str(b),'-I'+str(b)];oldobj=r.parent/'udm37-cf0-module-v1/O2'
for n in ('module_gfs_machine.mod','module_mp_radar.mod','module_wrf_error.mod'):shutil.copy2(oldobj/n,b/n)
results={}
for dt in ('.01','10.'):
 d=b/dt;d.mkdir();(d/'fixture.f90').write_text(f.replace('call_dt=10.','call_dt='+dt));runner.run([fc,*flags,'-cpp','-DOBSERVER_ONLY','-c',d/'fixture.f90','-o',b/'observer.o'],b,'compile_observer_dependency')
 for variant in ('observed','production'):
  runner.run([fc,*flags,'-c',b/(variant+'.F'),'-o',b/(variant+'.o')],b,'compile_'+variant);exe=d/variant;runner.run([fc,*flags,'-cpp',d/'fixture.f90',b/'observer.o',oldobj/'module_gfs_machine.o',oldobj/'module_mp_radar.o',oldobj/'errors.o',b/(variant+'.o'),'-o',exe],b,'link_'+variant)
  for enabled in (['on','off'] if variant=='observed' else ['off']):
   p=runner.run([exe,'candidate','warm',enabled],b,'UDM_'+dt+'_'+variant+'_'+enabled);data=old.parse(p.read_text());results[dt,variant,enabled]=data
 assert results[dt,'observed','on'][1]==results[dt,'observed','off'][1]==results[dt,'production','off'][1]
rows=[]
for dt in ('.01','10.'):
 obs,_=results[dt,'observed','on']
 for c in range(1,7):
  cf=obs['CF_BEFORE',c,1,1,1];loc=obs['SWITCH_LOCAL',c,1,1,1];pre=obs['BULK_BEFORE',c,1,1,1];post=obs['BULK_AFTER',c,1,1,1];rows.append({'dt_seconds':float(dt),'case':c,'diagnosed_CF':cf[13],'footprint':loc[1],'local_qc':loc[2],'local_qr':loc[3],'local_NC':loc[4],'local_NR':loc[5],'rain_inverse_slope':loc[6],'local_nr_self_collection_rate':loc[7],'grid_nr_self_collection_rate':loc[7]*loc[1],'grid_rain_evaporation_rate':loc[8]*loc[1],'grid_QC_before_bulk':pre[1],'grid_QR_before_bulk':pre[2],'grid_QC_after_bulk':post[1],'grid_QR_after_bulk':post[2],'water_bulk_residual':sum(post[:3])-sum(pre[:3])})
h.write_json(b/'result.json',{'status':'PASS_SCOPED_ACTUAL_CF_BOUNDARY_PROBE','actual_UDM_calls':36,'distinct_initial_states':6,'time_steps':[.01,10.],'CF_forced':False,'observer_preserves_returns':True,'rows':rows,'processes':runner.commands,'production_accepted':False});print(json.dumps(rows))
