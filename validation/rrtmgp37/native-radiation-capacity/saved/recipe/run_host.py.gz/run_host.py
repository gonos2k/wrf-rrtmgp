from pathlib import Path
import os,sys,shutil,netCDF4,numpy as np
r=Path.cwd();b=r.parent/'udm37-native-capacity-host-v1';b.mkdir(exist_ok=False);src=r.parent/'udm37-consistent-warm-v5/on_dt10';exe=r.parent/'udm37-native-capacity-build-v1/wrf';sys.path.insert(0,str(r/'WRF/test/rrtmgp'));import test_netcdf_zz as h;import test_udm_startup_snow_scm as setup
env={**os.environ,'OMP_NUM_THREADS':'1','LD_LIBRARY_PATH':str(r.parent/'deps/netcdf/lib')}
for k in tuple(env):
 if k.startswith(('WRF_UDM_','WRF_RRTMGP_','WRF_RADIATION_ENERGY','WRF_RESEARCH_')):env.pop(k)
runner=h.Runner(b,180,env,5)
# Two heat-only runs keep the prior final input. Positive-cloud baseline/Gamma runs share one new consistent input.
for name,heat,gamma,positive,radt,call in [('legacy',0,0,False,'0','1'),('capacity',1,0,False,'0','1'),('held30s',1,0,False,'0.5','1'),('cloud_native',0,0,True,'0','2'),('cloud_gamma8',0,1,True,'0','2')]:
 d=b/name;d.mkdir()
 for p in src.iterdir():
  if p.is_file() and not p.name.startswith(('wrfout','wrfrst','rsl.','udm_')) and p.name not in ['stdout.log','namelist.output']:shutil.copy2(p,d/p.name)
 if positive:shutil.copy2(r.parent/'udm37-positive-capacity-input-v1/wrfinput_d01',d/'wrfinput_d01')
 (d/'namelist.input').write_text(setup.set_assignment((src/'namelist.input').read_text(),'radt',radt,group='physics'))
 (d/'capture').mkdir();runner.environment.update({'WRF_RESEARCH_HEAT_CAPACITY':str(heat),'WRF_RESEARCH_GAMMA8':str(gamma),'WRF_RADIATION_ENERGY':'1','WRF_RRTMGP_BATCH_SIZE':'1','WRF_RRTMGP_CAPTURE_DIR':str(d/'capture'),'WRF_RRTMGP_CAPTURE_CALL':call})
 runner.run([exe],d,name);h.write_json(b/'receipt.json',{'commands':runner.commands,'executable':h.pin(exe),'inputs':{p.name:h.pin(p/'wrfinput_d01') for p in b.iterdir() if p.is_dir() and (p/'wrfinput_d01').exists()},'production_accepted':False})
with netCDF4.Dataset(next((b/'legacy').glob('wrfout*'))) as a,netCDF4.Dataset(next(src.glob('wrfout*'))) as p:
 names=[n for n in a.variables if 'Time' in a[n].dimensions];assert all(np.asarray(a[n][:]).tobytes()==np.asarray(p[n][:]).tobytes() for n in names)
for n in ['cloud_native','cloud_gamma8']:
 with netCDF4.Dataset(next((b/n).glob('wrfout*'))) as d:print(n, 'QC10',float(np.max(d['QCLOUD'][1])),'QC60',float(np.max(d['QCLOUD'][-1])),flush=True)
h.write_json(b/'passivity.json',{'legacy_all_211_history_arrays_equal_PR176':True,'no_production_files_changed':True})
print('DONE')
