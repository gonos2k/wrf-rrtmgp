from pathlib import Path
import importlib.util
r=Path.cwd();base=(r/'validation/rrtmgp37/consistent-warm-input/make_input.py').read_text()
base=base.replace('active=zc<1500.;qc=np.where(active,1e-5,0.);qr=np.where(active,2e-4,0.);qt=qv+qc+qr', '''active=zc<1500.
    es=610.78*np.exp(17.27*(temp-273.15)/(temp-35.85))
    qv=np.where(active,(rd/rv)*es/(P-es),qv)
    qc=np.where(active,5e-4,0.);qr=np.where(active,2e-4,0.);qt=qv+qc+qr
    theta_m=theta*(1+rv/rd*qv)-300.''')
base=base.replace("('QRAIN',qr)]","('QRAIN',qr),('QVAPOR',qv),('THM',theta_m)]").replace("('QNCLOUD',5e7)","('QNCLOUD',1e8)").replace("d['T_BASE'][0]=s['THM'][:,0,0]","d['T_BASE'][0]=theta_m[:,0,0]")
base=base.replace('warm-SCM-discrete-hydrostatic-liquid-v1','positive-cloud-saturated-seed-Gamma8-probe-v1').replace('qc=1e-5 qr=2e-4','qc=5e-4 qr=2e-4; initial low-level qv from explicit saturation formula')
b=r.parent/'udm37-positive-capacity-input-v1';b.mkdir(exist_ok=False);(b/'producer.py').write_text(base)
s=importlib.util.spec_from_file_location('input',b/'producer.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.generate(r.parent/'udm37-consistent-warm-v3/ideal_unmodified.nc',b/'wrfinput_d01',b/'receipt.json')
