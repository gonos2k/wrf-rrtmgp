from pathlib import Path
import re,os,shlex,shutil,importlib.util
r=Path.cwd();b=r.parent/'udm37-native-capacity-build-v1';b.mkdir(exist_ok=False);(b/'modules').mkdir();old=r.parent/'udm37-cf0-transition-build-v1/producer';prev=r.parent/'udm37-radiation-energy-observer-v2'
mark=lambda s:'! CAPACITY_CANDIDATE_BEGIN\n'+s+'\n! CAPACITY_CANDIDATE_END\n'
s=(prev/'phys/module_ra_rrtmgp.F').read_text();anchor='  REAL(wp), SAVE :: initialized_gravity = 9.80665_wp';assert s.count(anchor)==1
s=s.replace(anchor,mark('PUBLIC :: research_native_column\nREAL(wp),ALLOCATABLE,SAVE :: research_capacity(:,:),research_qv(:,:),research_md(:,:)\nLOGICAL,SAVE :: research_heat=.false.')+anchor)
anchor='CONTAINS\n';assert s.count(anchor)==1
code='''SUBROUTINE research_native_column(phase,md,qv,rho,qc,eta,cf,rel)
 USE module_model_constants, ONLY: wrf_cp=>cp,rvovrd
 CHARACTER(LEN=*),INTENT(IN) :: phase
 REAL,INTENT(IN) :: md(:),qv(:),rho(:),qc(:),eta(:),cf(:)
 REAL,INTENT(INOUT) :: rel(:)
 CHARACTER(LEN=8) :: env,diag
 INTEGER :: k,n
 REAL(wp) :: M0,M3,M2,lambda,reff,f
 n=SIZE(md)
 env="";call get_environment_variable("WRF_RESEARCH_HEAT_CAPACITY",env)
 research_heat=trim(env)=="1"
 if(allocated(research_capacity)) deallocate(research_capacity,research_qv,research_md)
 allocate(research_capacity(1,n),research_qv(1,n),research_md(1,n))
 research_qv(1,:)=real(qv,wp);research_md(1,:)=real(md,wp)
 research_capacity=research_md*real(wrf_cp,wp)*(1._wp+real(rvovrd,wp)*research_qv)
 if(any(research_capacity<=0._wp)) call require('research invalid native heat capacity')
 env="";call get_environment_variable("WRF_RESEARCH_GAMMA8",env)
 diag="";call get_environment_variable("WRF_RADIATION_ENERGY",diag)
 do k=1,n
  if(qc(k)>0..and.eta(k)>0.) then
   f=1._wp;if(cf(k)>0.)f=real(cf(k),wp)
   M0=real(rho(k),wp)*real(eta(k),wp)/f
   M3=3._wp*real(rho(k),wp)*real(qc(k),wp)/(4._wp*acos(-1._wp)*1000._wp*f)
   lambda=(M0*8._wp*9._wp*10._wp/M3)**(1._wp/3._wp)
   M2=M0*8._wp*9._wp/lambda**2
   reff=M3/M2*1.e6_wp
   if(trim(diag)=="1") write(*,'(a,1x,a,1x,i0,1x,10(es25.17,1x))') 'PG',trim(phase),k, &
     real(qc(k),wp),real(eta(k),wp),real(rho(k),wp),f,M0,M2,M3,reff,real(rel(k),wp),real(merge(1,0,trim(env)=="1"),wp)
   if(trim(env)=="1") rel(k)=real(reff)
  endif
 enddo
END SUBROUTINE
SUBROUTINE research_apply_capacity(fu,fd,heat)
 REAL(wp),INTENT(IN) :: fu(:,:),fd(:,:)
 REAL(wp),INTENT(INOUT) :: heat(:,:)
 INTEGER :: n
 if(.not.research_heat)return
 if(.not.allocated(research_capacity))call require('research missing native capacity')
 n=size(research_capacity,2)
 if(size(fu,1)/=1)call require('research scalar columns only')
 heat(:,1:n)=(fd(:,2:n+1)-fu(:,2:n+1)-fd(:,1:n)+fu(:,1:n))/research_capacity
END SUBROUTINE
'''
s=s.replace(anchor,anchor+mark(code));anchor='    CALL require(compute_heating_rate(fu,fd,REAL(plev,wp)*100._wp,heat))';assert s.count(anchor)==4;s=s.replace(anchor,anchor+'\n'+mark('CALL research_apply_capacity(fu,fd,heat)'))
# Snapshot native heat capacity and qv in capture, plus high precision clear/allsky flux/heat.
for ph in ['LW','SW']:
 anchor=f"    IF(trace_active('{ph}')) THEN\n      CALL trace_result('{ph}','UP',up)";assert s.count(anchor)==1
 txt=f"IF(allocated(research_capacity)) THEN\nCALL trace_result('{ph}','NATIVE_CAPACITY_J_M2_K',research_capacity)\nCALL trace_result('{ph}','CAPACITY_QV',research_qv)\nCALL trace_result('{ph}','CAPACITY_DRY_MASS',research_md)\nENDIF\nCALL trace_result('{ph}','UP_WP',fu)\nCALL trace_result('{ph}','DN_WP',fd)\nCALL trace_result('{ph}','HEAT_WP_K_S',heat)"
 s=s.replace(anchor,f"    IF(trace_active('{ph}')) THEN\n"+mark(txt)+f"      CALL trace_result('{ph}','UP',up)")
 # Log heat capacity each native layer for all calls; pairs with EI from predecessor observer.
 anchor=f"    CALL check_finite_wp_output('{ph}','allsky','HEAT_K_PER_DAY',heat*86400._wp,'layer')";assert s.count(anchor)==1
 s=s.replace(anchor,anchor+'\n'+mark(f'''ea_env="";call get_environment_variable("WRF_RADIATION_ENERGY",ea_env)
if(trim(ea_env)=="1".and.allocated(research_capacity)) then
 do ea_c=1,size(research_capacity,1)
 do ea_k=1,size(research_capacity,2)
 write(*,'(a,1x,a,1x,2(i0,1x),3(es25.17,1x))') 'EC', '{ph}',ea_c,ea_k,research_capacity(ea_c,ea_k),research_qv(ea_c,ea_k),research_md(ea_c,ea_k)
 enddo
 enddo
endif'''))
sources={'phys/module_ra_rrtmgp.F':s}
for ph in ['lw','sw']:
 name=f'phys/module_ra_rrtmg_{ph}.F';s=(r/'WRF'/name).read_text();anchor='   USE mo_rte_kind, ONLY: wp';assert s.count(anchor)==1;s=s.replace(anchor,mark('USE module_ra_rrtmgp, ONLY: research_native_column')+anchor)
 anchor='               ! UDM-only: no CAM/P3/other microphysics radius override.';assert s.count(anchor)==1
 txt=f'''if(gp_batch_enabled) call rrtmgp_fatal('research scalar host only','capacity candidate')
if(.not.present(qnc3d)) call rrtmgp_fatal('research number metadata required','capacity candidate')
CALL research_native_column('{ph.upper()}',udm_dry_layer_mass(i,kts:kte,j),qv3d(i,kts:kte,j), &
 udm_dry_density(i,kts:kte,j),qc3d(i,kts:kte,j),qnc3d(i,kts:kte,j),cldfrac(ncol,kts:kte),gp_rel)'''
 s=s.replace(anchor,mark(txt)+anchor);sources[name]=s
for n,s in sources.items():
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
spec=importlib.util.spec_from_file_location('h',r/'WRF/test/rrtmgp/test_netcdf_zz.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);runner=h.Runner(b,240,dict(os.environ),5)
flags=(old/'CMakeFiles/WRF_Core.dir/flags.make').read_text();args=[]
for key in ['Fortran_DEFINES','Fortran_INCLUDES','Fortran_FLAGS']:args+=shlex.split(re.search('^'+key+r' = (.*)$',flags,re.M).group(1))
args=[x for x in args if not x.startswith('-J')];args=['-I'+str(b/'modules'),*args,'-J'+str(b/'modules')]
objs=[]
for n in sources:
 p=b/n;o=b/(Path(n).name+'.o');objs.append(o);runner.run(['/usr/bin/gfortran',*args,'-ffree-form','-cpp','-O2','-ftree-vectorize','-funroll-loops','-ffree-line-length-none','-fallow-argument-mismatch','-fallow-invalid-boz','-c',p,'-o',o],b,'compile_'+Path(n).name)
shutil.copy2(prev/'libWRF_Core.a',b/'libWRF_Core.a');runner.run(['ar','r',b/'libWRF_Core.a',*objs],b,'replace_three_candidate_members')
args=shlex.split((old/'main/CMakeFiles/wrf.dir/link.txt').read_text());out=[];skip=False
for x in args:
 if skip:skip=False;continue
 if x.startswith('-Wl,--dependency-file='):continue
 if x=='-o':out+=['-o',str(b/'wrf')];skip=True
 elif x=='../libWRF_Core.a':out.append(str(b/'libWRF_Core.a'))
 elif x.endswith(('.a','.o')) and not x.startswith('/'):out.append(str((old/'main'/x).resolve()))
 else:out.append(x)
runner.run(out,b,'link_capacity_candidate');h.write_json(b/'receipt.json',{'commands':runner.commands,'executable':h.pin(b/'wrf'),'base_archive':h.pin(prev/'libWRF_Core.a'),'new_archive':h.pin(b/'libWRF_Core.a'),'sources':{n:h.pin(b/n) for n in sources},'production_source_changed':False,'candidate_only':True})
