from pathlib import Path
import importlib.util,os,shutil,json,hashlib,struct
r=Path.cwd();b=r.parent/'udm37-positive-final-psd-v1';b.mkdir(exist_ok=False)
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
h=load(r/'WRF/test/rrtmgp/test_netcdf_zz.py','h');m=load(r/'WRF/test/rrtmgp/test_udm_population_integration.py','m');f=m.fixture(r/'WRF').decode();i=f.index('  ! Direct production exchange');j=f.index("  print *, 'REPRESENTATION_PROBE_PASS'",i)+len("  print *, 'REPRESENTATION_PROBE_PASS'\n");f=f[:i]+f[j:];f=f.replace('  do a=1,2','  do a=1,1').replace('    do b=1,3','    do b=1,1').replace('  if(candidate) pol=1','  if(candidate) pol=2');(b/'fixture.f90').write_text(f)
old=r.parent/'udm37-actual-switch-v1';assert (r/'WRF/phys/module_mp_udm.F').read_bytes()==(old/'production.F').read_bytes()
for p in old.glob('*.mod'):shutil.copy2(p,b/p.name)
runner=h.Runner(b,120,dict(os.environ),2);dep=r.parent/'udm37-cf0-module-v1/O2';exe=b/'column';runner.run(['/usr/bin/gfortran','-O2','-g','-cpp','-ffree-form','-ffree-line-length-none','-fcheck=all','-I'+str(b),b/'fixture.f90',old/'observer.o',old/'production.o',dep/'module_gfs_machine.o',dep/'module_mp_radar.o',dep/'errors.o','-o',exe],b,'link_current_actual_UDM_fixture');out=runner.run([exe,'candidate','warm','off'],b,'one_actual_positive_cloud_UDM');lines=out.read_text().splitlines()
for idx,line in enumerate(lines):
 if line.startswith('RETURN 1 '):a=[struct.unpack('!f',bytes.fromhex(x))[0] for x in lines[idx+1].split()]
rho=struct.unpack('!f',struct.pack('!f',.7))[0];qc=a[8];eta=a[36];assert qc>0 and eta>0
h.write_json(b/'result.json',{'source_sha256':hashlib.sha256((old/'production.F').read_bytes()).hexdigest(),'commands':runner.commands,'executable':h.pin(exe),'final_qc_kg_kg':qc,'final_eta_kg_dry_inverse':eta,'rho_call':rho,'final_temperature_K':a[0],'actual_UDM_calls':1,'occurrence':'diagnostic common footprint1; no CF forced in UDM','producer':'retained integration warm fixture restricted to one density and one initial state, current population2 production object','production_accepted':False});print(qc,eta,rho)
