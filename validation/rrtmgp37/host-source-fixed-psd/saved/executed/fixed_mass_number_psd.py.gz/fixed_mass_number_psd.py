from pathlib import Path
import os,sys,json,math,hashlib,importlib.util,shutil
os.environ['MIEPYTHON_USE_JIT']='1';sys.path.insert(0,str(Path('../deps/miepython-3.2.0').resolve()))
import miepython as mie,numpy as np,netCDF4,scipy.integrate as it
from numpy.polynomial.legendre import leggauss
r=Path.cwd();b=r.parent/'udm37-fixed-M0M3-psd-v1';b.mkdir(exist_ok=False);particle=json.loads((r.parent/'udm37-positive-final-psd-v1/result.json').read_text());q=particle['final_qc_kg_kg'];eta=particle['final_eta_kg_dry_inverse'];rho=particle['rho_call'];M0=rho*eta;M3=3*rho*q/(4*math.pi*1000);water=r.parent/'udm37-matched-optics-inputs/Segelstein.yml';data=[]
for line in water.read_text().splitlines():
 try:
  z=list(map(float,line.split()))
  if len(z)==3:data.append(z)
 except ValueError:pass
a=np.array(data)
meta={'material_temperature_K':298.15,'RI':'Segelstein, log(k) interpolation; fixed for all PSDs','water_sha256':hashlib.sha256(water.read_bytes()).hexdigest(),'q_eta_rho_fixed':particle,'M0':M0,'M3':M3,'optical_path_g_m2':1000*q*rho*100.,'native_fixture_delz_m':100.,'refinements':[[1024,96],[2048,192]],'PSDs':[],'production_accepted':False}
def calc(s,reff,band,nr,ns):
 with netCDF4.Dataset(r/'WRF/run/rrtmgp-clouds-sw-bnd.nc') as d:lo,hi=map(float,d['bnd_limits_wavenumber'][band-1])
 x,w=leggauss(ns);nu=(lo+hi)/2+(hi-lo)/2*x;L=1e4/nu;m=np.interp(L,a[:,0],a[:,1])-1j*np.exp(np.interp(L,a[:,0],np.log(a[:,2])));gx=np.linspace(0,80,nr+1);area=gx**(s+1)*np.exp(-gx)/math.gamma(s+2);rad=gx*reff/(s+2);f=3/(4*1000*reff*1e-6)/1000;mom=[]
 for lam,ri in zip(L,m):
  e,c,_,g=mie.efficiencies_mx(ri,2*np.pi*rad[1:]/lam);e=np.r_[0.,e];c=np.r_[0.,c];g=np.r_[0.,g];E=f*it.simpson(area*e,x=gx);C=f*it.simpson(area*c,x=gx);G=f*it.simpson(area*c*g,x=gx);mom.append([E,C,E-C,G])
 z=np.average(np.array(mom),weights=w*nu**3/np.expm1(1.438776877*nu/5780.),axis=0);return dict(ext=float(z[0]),sca=float(z[1]),abs=float(z[2]),sca_g=float(z[3]),ssa=float(z[1]/z[0]),g=float(z[3]/z[1]))
for shape in [8,16]:
 lam=(M0*shape*(shape+1)*(shape+2)/M3)**(1/3);M2=M0*shape*(shape+1)/lam**2;reff=M3/M2*1e6;row={'shape':shape,'effective_variance':1/(shape+2),'M0':M0,'M3':M3,'lambda':lam,'M2':M2,'reff_um':reff,'bands':{}}
 for band in [8,6]:
  row['bands'][str(band)]={}
  for nr,ns in meta['refinements']:row['bands'][str(band)][f'r{nr}s{ns}']=calc(shape,reff,band,nr,ns)
 meta['PSDs'].append(row);(b/'moments-optics.json').write_text(json.dumps(meta,indent=2)+'\n');print(shape,reff,flush=True)
# Current consistent host's source-time50 gas/boundary state; cloud-free there.
spec=importlib.util.spec_from_file_location('v',r/'validation/rrtmgp37/radiation-occurrence-runtime/verify_saved.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);spec=importlib.util.spec_from_file_location('h',r/'WRF/test/rrtmgp/test_netcdf_zz.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
runner=h.Runner(b,90,{**os.environ,'LD_LIBRARY_PATH':str(r.parent/'deps/netcdf/lib')},6);exe=r.parent/'udm37-cf0-psd-optics-v4/build/column';capture=r.parent/'udm37-host-source-v2/on_dt10/capture';selected=29
for ph in ['lw','sw']:
 header,original=v.trace((capture/(ph+'.input')).read_bytes(),'input');_,raw=v.trace((capture/(ph+'.raw')).read_bytes(),'raw');assert raw['SOURCE_TIME_SECONDS']['values'][0]==50.;assert max(raw['SOURCE_QC']['values'])==0.
 for row in meta['PSDs']:
  shape=row['shape'];inp={n:{'shape':z['shape'],'values':list(z['values'])} for n,z in original.items()};nl=header[2]
  for n in ['LWP','IWP','RWP','SWP','CF','UNIFORM_LWP','UNIFORM_RWP']:
   if n not in inp:inp[n]={'shape':(1,nl),'values':[0.]*nl}
   else:inp[n]['values']=[0.]*nl
  inp['CF']['values'][selected]=1.;inp['LWP']['values'][selected]=meta['optical_path_g_m2'];inp['REL']['values']=[row['reff_um']]*nl
  text='RRTMGP_REPLAY_V12\n'+' '.join(map(str,header))+'\n'
  for n,z in inp.items():text+=n+' '+' '.join(map(str,z['shape']))+'\n'+''.join(f'{x:.17e}\n' for x in z['values'])
  for mode in (['LUT'] if ph=='lw' else ['LUT','NIR_Mie']):
   d=b/f'{ph}-s{shape}-{mode}';d.mkdir();(d/'capture').mkdir();(d/'input').write_text(text);data=r/'WRF/run'
   if mode=='NIR_Mie':
    data=b/f's{shape}-tables';data.mkdir()
    for p in (r/'WRF/run').glob('rrtmgp*.nc'):
     if p.name!='rrtmgp-clouds-sw-bnd.nc':(data/p.name).symlink_to(p.resolve())
    shutil.copy2(r/'WRF/run/rrtmgp-clouds-sw-bnd.nc',data/'rrtmgp-clouds-sw-bnd.nc')
    with netCDF4.Dataset(data/'rrtmgp-clouds-sw-bnd.nc','r+') as nc:
     grid=np.arange(2.5,22,1);idx=int(np.searchsorted(grid,row['reff_um']))
     for band in [8,6]:
      z=row['bands'][str(band)]['r2048s192']
      for field,n in [('extliq','ext'),('ssaliq','ssa'),('asyliq','g')]:nc[field][band-1,idx-1:idx+1]=z[n]
     nc.setncattr('RESEARCH_OVERRIDE','fixed M0 M3 PSD probe at one reff; only SW6/8 independent Mie, other bands use retained LUT')
   runner.environment['WRF_RRTMGP_CAPTURE_DIR']=str(d/'capture');runner.run([exe,data,d/'input'],d,f'PSD_{ph}_s{shape}_{mode}')
h.write_json(b/'receipt.json',{'commands':runner.commands,'executable':h.pin(exe),'source_time_seconds':50,'current_host_liquid_absent':True,'nonzero_particle_state':'separate actual current production UDM final, not added to current WRF forecast','scope':'same q eta rho md path footprint, two Gamma closures; LUT all-band sensitivity plus independent SW6/8 hybrid check','production_accepted':False});print('DONE')
