from pathlib import Path
import os,sys,shutil,json,netCDF4,numpy as np
r=Path.cwd();b=r.parent/'udm37-host-source-v2';b.mkdir(exist_ok=False);src=r.parent/'udm37-consistent-warm-v5/on_dt10';exe=r.parent/'udm37-host-source-observer-v4/wrf';sys.path.insert(0,str(r/'WRF/test/rrtmgp'));import test_netcdf_zz as h;import test_udm_startup_snow_scm as setup
env={**os.environ,'OMP_NUM_THREADS':'1','LD_LIBRARY_PATH':str(r.parent/'deps/netcdf/lib')}
for k in tuple(env):
 if k.startswith(('WRF_UDM_','WRF_RRTMGP_')):env.pop(k)
runner=h.Runner(b,180,env,3)
for name,dt,on in [('off_dt10',10,False),('on_dt10',10,True),('on_dt5',5,True)]:
 d=b/name;d.mkdir()
 for p in src.iterdir():
  if p.is_file() and not p.name.startswith(('wrfout','wrfrst','rsl.','udm_')) and p.name not in ['stdout.log','namelist.output']:shutil.copy2(p,d/p.name)
 (d/'namelist.input').write_text(setup.set_assignment((src/'namelist.input').read_text(),'time_step',str(dt),group='domains'));runner.environment['WRF_UDM_BUDGET']='1' if on else '0'
 if name=='on_dt10':
  (d/'capture').mkdir();runner.environment['WRF_RRTMGP_CAPTURE_DIR']=str(d/'capture');runner.environment['WRF_RRTMGP_CAPTURE_CALL']='6'
 else:
  runner.environment.pop('WRF_RRTMGP_CAPTURE_DIR',None);runner.environment.pop('WRF_RRTMGP_CAPTURE_CALL',None)
 runner.run([exe],d,name);h.write_json(b/'receipt.json',{'commands':runner.commands,'executable':h.pin(exe),'initial_input':h.pin(d/'wrfinput_d01'),'production_accepted':False})
with netCDF4.Dataset(next((b/'off_dt10').glob('wrfout*'))) as a,netCDF4.Dataset(next((b/'on_dt10').glob('wrfout*'))) as c,netCDF4.Dataset(next(src.glob('wrfout*'))) as p:
 names=[n for n in a.variables if 'Time' in a[n].dimensions];assert all(np.asarray(a[n][:]).tobytes()==np.asarray(c[n][:]).tobytes()==np.asarray(p[n][:]).tobytes() for n in names)
print('PASS ARRAY NONINTERFERENCE',len(names))
