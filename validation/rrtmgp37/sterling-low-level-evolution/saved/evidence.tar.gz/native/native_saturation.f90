module native_svp
 implicit none
   integer, parameter                  ::  nxsvp = 7501
   real                     ::  c1xsvp,c2xsvp
   real,  dimension(nxsvp)  ::  tbsvp
   integer, parameter                  ::  nxsvpw = nxsvp
   real                     ::  c1xsvpw,c2xsvpw
   real,  dimension(nxsvpw) ::  tbsvpw
!
   real, parameter :: &
         cliq_ = 4.1900e+3     ,&    !< specific heat of liquid water [jkg-1k-1]
         cice_ = 2.1060e+3     ,&    !< specific heat of ice water    [jkg-1k-1]
         cvap_ = 1.8700e+3     ,&    !< specific heat of vapor water  [jkg-1k-1]
         cpd_  = 1.00464e+3    ,&    !< specific heat of dry air      [jkg-1k-1]
         hvap_ = 2.5010e+6     ,&    !< latent heat for vaporization     [jkg-1]
         hsub_ = 2.8340e+6     ,&    !< latent heat for sublimation      [jkg-1]
         psat_ = 6.1078e+2     ,&    !< saturated vapor pressure at 0c      [pa]
         rd_   = 2.8704e+2     ,&    !< gas constant for dry air      [jkg-1k-1]
         rv_   = 4.6150e+2     ,&    !< gas constant for water vapor  [jkg-1k-1]
         ttp_  = 2.7316e+2           !< temperature at triple point          [k]
  real, parameter :: &
         psatk = psat_,                         &
         dldt  = cvap_-cliq_,                   &
         dldti = cvap_-cice_,                   &
         xa    = -dldt/rv_,                     &
         xb    = xa+hvap_/(rv_*ttp_),           &
         xai   = -dldti/rv_,                    &
         xbi   = xai+hsub_/(rv_*ttp_)

contains
   subroutine udm_funct_svp_setup
!-------------------------------------------------------------------------------
!
!  abstract: compute saturation vapor pressure table for the table lookup
!    function fsvp.exact saturation vapor pressures are calculated in
!    subprogram fsvpx.
!    the current implementation computes a table with a length
!    of 7501 for temperatures ranging from 180. to 330. kelvin.
!
!  history log:
!    1991-05-07 iredell         made into inlinable function
!    1996-02-19 song-you hong   ice effect & increased range and accuracy
!    2009-10-01 jung-eun kim    f90 format with standard physics modules
!    2010-07-01 myung-seo koo   dimension allocatable with namelist input
!    2023-11-27 song-you hong   clean-up and implemented on ufs model
!
!  usage : call funct_svp_setup
!
!  subprograms called :
!    (fsvpx)  - inlinable function to compute saturation vapor pressure
!
!-------------------------------------------------------------------------------
   implicit none
!
   real   , parameter  ::  xmin = 180.0,                                       &
                           xmax = 330.0
   integer             ::  jx
   real                ::  xinc,x,t
!
   xinc = (xmax-xmin)/(nxsvp-1)
   c1xsvp = 1.-xmin/xinc
   c2xsvp = 1./xinc
   c1xsvpw = c1xsvp
   c2xsvpw = c2xsvp
!
   do jx = 1,nxsvp
     x = xmin+(jx-1)*xinc
     t = x
     tbsvp(jx) = fsvpx(t)
     tbsvpw(jx) = fsvpxw(t)
   enddo
!
   return
   end subroutine udm_funct_svp_setup
!-------------------------------------------------------------------------------
   real function fsvpx(t)
!-------------------------------------------------------------------------------
!
!  abstract : exactly compute saturation vapor pressure from temperature.
!    the clausius-clapeyron equation is integrated from the triple point
!    to get the formula
!       svp=psatk*(tr**xa)*exp(xb*(1.-tr))
!    where tr is ttp/t and other values are physical constants
!    this function should be expanded inline in the calling routine.
!
!  usage :   svp=fsvpx(t)
!
!  input :
!    t        - real temperature in kelvin
!
!  output :
!    fsvpx    - real saturation vapor pressure in pascale (pa)
!
!-------------------------------------------------------------------------------
   implicit none
!
! passing variable
!
   real   , intent(in   )  ::  t
!
! local variable
!
   real                    ::  tr
!
   tr = ttp_/t
   if (t >= ttp_) then
     fsvpx = psatk*(tr**xa)*exp(xb*(1.-tr))
   else
     fsvpx = psatk*(tr**xai)*exp(xbi*(1.-tr))
   endif
!
   return
   end function fsvpx
!-------------------------------------------------------------------------------
   real function fsvpxw(t)
!-------------------------------------------------------------------------------
!
!  abstract : same to fxvps but water only
!
!-------------------------------------------------------------------------------
   implicit none
!
   real   , intent(in   )  ::  t
   real                    ::  tr
!
   tr = ttp_/t
   fsvpxw = psatk*(tr**xa)*exp(xb*(1.-tr))
!
   return
   end function fsvpxw
!-------------------------------------------------------------------------------
   real function fsvp(t,p)
!-------------------------------------------------------------------------------
!
!  abstract : compute saturation vapor pressure from the temperature.
!    a linear interpolation is done between values in a lookup table
!    computed in funct_svp_setup.
!
!  usage :   svp=fsvp(t)
!
!  input :
!    t        - real temperature in kelvin
!    p        - real pressure in pa (optional)
!
!  output :
!    fsvp     - real saturation vapor pressure in pascals (pa)
!
!-------------------------------------------------------------------------------
   implicit none
!
   real   , intent(in   )            ::  t
   real   , intent(in   ), optional  ::  p
!
   integer  ::  jx
   real     ::  xj
!
   xj = min(max(c1xsvp+c2xsvp*t,1.),real(nxsvp))
   jx = min(xj,nxsvp-1.)
   fsvp = tbsvp(jx)+(xj-jx)*(tbsvp(jx+1)-tbsvp(jx))
!
   if (present(p)) fsvp = min(fsvp,0.99*p)
!
   return
   end function fsvp
!-------------------------------------------------------------------------------
   real function fsvp_water(t,p)
!-------------------------------------------------------------------------------
!
!  abstract : same to fsvp but water only
!
!-------------------------------------------------------------------------------
   implicit none
!
   real   , intent(in   )            ::  t
   real   , intent(in   ), optional  ::  p
!
   integer  ::  jx1
   real     ::  xj1
!
   xj1 = min(max(c1xsvpw+c2xsvpw*t,1.),real(nxsvpw))
   jx1 = min(xj1,nxsvpw-1.)
   fsvp_water = tbsvpw(jx1)+(xj1-jx1)*(tbsvpw(jx1+1)-tbsvpw(jx1))
!
   if (present(p)) fsvp_water = min(fsvp_water,0.99*p)
!
   return
   end function fsvp_water
!-------------------------------------------------------------------------------
!

end module
program main
 use native_svp
 implicit none
 real::t,p,q,e,qs
 integer::ios
 call udm_funct_svp_setup
 do
 read(*,*,iostat=ios)t,p,q
 if(ios/=0)exit
 e=fsvp_water(t,p)
 qs=(287./461.6)*e/(p-e)
 write(*,'(3(es25.16e3,1x))')e,qs,q/qs
 enddo
end program
