program native_first_ww
 use module_big_step_utilities_em, only: calc_ww_cp
 use module_bc, only: set_physical_bc2d
 use module_configure, only: grid_config_rec_type
 implicit none
 type(grid_config_rec_type)::cfg
 real::u(19:27,1:45,92:100),v(19:27,1:45,92:100)
 real::mc(19:27,92:100),mr(19:27,92:100),mf(19:27,92:100),mb(19:27,92:100)
 real::mx(19:27,92:100),my(19:27,92:100),uy(19:27,92:100),vi(19:27,92:100)
 real::c1(45),c2(45),dn(45),rdx,rdy,wc(45),wr(45)
 real::w(19:27,1:45,92:100),mass
 integer::n,k,unit
 open(newunit=unit,file='inputs.bin',access='stream',form='unformatted',convert='little_endian')
 read(unit)u,v,mc,mr,mb,mx,my,uy,vi,c1,c2,dn,rdx,rdy,wc,wr
 close(unit)
 cfg%specified=.true.;cfg%nested=.false.;cfg%periodic_x=.false.;cfg%periodic_y=.false.
 cfg%symmetric_xs=.false.;cfg%symmetric_xe=.false.;cfg%symmetric_ys=.false.;cfg%symmetric_ye=.false.
 cfg%open_xs=.false.;cfg%open_xe=.false.;cfg%open_ys=.false.;cfg%open_ye=.false.;cfg%polar=.false.
 mf=mc
 call set_physical_bc2d(mf,'t',cfg,1,91,1,100,19,27,92,100,19,27,92,100,23,23,99,99)
 if(any(transfer(mc(:,92:99),[0],72)/=transfer(mf(:,92:99),[0],72)))error stop 'physical mass changed'
 do n=1,3
  if(n==1)mf=mc
  if(n==2)mf=mr
  if(n==3)then
   mf=mc
   call set_physical_bc2d(mf,'t',cfg,1,91,1,100,19,27,92,100,19,27,92,100,23,23,99,99)
  endif
  mass=.5*(mf(23,100)+mb(23,100)+mf(23,99)+mb(23,99))
  call calc_ww_cp(u,v,mf,mb,c1,c2,w,rdx,rdy,mx,my,uy,uy,uy,vi,uy,dn, &
                 1,91,1,100,1,45,19,27,92,100,1,45,23,23,99,99,1,45)
  if(n==1.and.any(transfer(w(23,:,99),[0],45)/=transfer(wc,[0],45)))error stop 'continuous WW replay differs'
  if(n>=2.and.any(transfer(w(23,:,99),[0],45)/=transfer(wr,[0],45)))error stop 'restart/repaired WW replay differs'
  write(*,'(A,I1,1X,Z8.8)')'MUV ',n,transfer(mass,0)
  do k=1,45
   write(*,'(A,2I3,1X,Z8.8)')'WW ',n,k,transfer(w(23,k,99),0)
  enddo
 enddo
 print *,'ACTUAL_FIRST_WW_REPLAY_COMPLETE'
end program
