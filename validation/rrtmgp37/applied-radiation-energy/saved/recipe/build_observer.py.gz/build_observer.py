from pathlib import Path
import re,os,shlex,shutil,importlib.util
r=Path.cwd(); b=r.parent/'udm37-radiation-energy-observer-v2'; b.mkdir(exist_ok=True)
old=r.parent/'udm37-cf0-transition-build-v1/producer'; (b/'modules').mkdir(exist_ok=True)
marker=lambda s:'! ENERGY_OBSERVER_BEGIN\n'+s+'\n! ENERGY_OBSERVER_END\n'
def decl(s,anchor,extra):
 assert s.count(anchor)==1,(anchor,s.count(anchor));return s.replace(anchor,anchor+'\n'+marker(extra))
def enabled(s):return 'ea_env=""\ncall get_environment_variable("WRF_RADIATION_ENERGY",ea_env)\nif(trim(ea_env)=="1") then\n'+s+'\nendif'
def loop(tag,vals,ints='grid%itimestep,rk_step,i,j,k',nint=5):
 return enabled('do j=jds,jde-1\ndo k=kds,kde-1\ndo i=ids,ide-1\n'+f'write(*,\'(a,{nint}(i0,1x),{len(vals)}(es25.17,1x))\') "{tag} ",{ints}, &\n'+', &\n'.join('real('+v+',8)' for v in vals)+'\nenddo\nenddo\nenddo')
sources={}
# Real wp flux/heat before conversion; private read-only output, all calls.
n='phys/module_ra_rrtmgp.F';s=(r/'WRF'/n).read_text()
for phase in ['LW','SW']:
 start=s.index('  RECURSIVE SUBROUTINE rrtmgp_'+phase.lower()+'_column(');stop=s.index('\n  END SUBROUTINE',start)
 q=s[start:stop]
 q=decl(q,'    LOGICAL :: active_uniform','character(len=8) :: ea_env\ninteger :: ea_c,ea_k\ninteger,save :: ea_call=0')
 anchor=f"    CALL check_finite_wp_output('{phase}','allsky','HEAT_K_PER_DAY',heat*86400._wp,'layer')"
 assert q.count(anchor)==1
 vals=['real(plev(ea_c,ea_k),wp)*100._wp','real(plev(ea_c,ea_k+1),wp)*100._wp','fu(ea_c,ea_k)','fu(ea_c,ea_k+1)','fd(ea_c,ea_k)','fd(ea_c,ea_k+1)','heat(ea_c,ea_k)','initialized_gravity','initialized_cp_dry']
 txt=enabled('ea_call=ea_call+1\ndo ea_c=1,size(play,1)\ndo ea_k=1,size(play,2)\n'+f'write(*,\'(a,3(i0,1x),9(es25.17,1x))\') "EI_{phase} ",ea_call,ea_c,ea_k, &\n'+', &\n'.join(vals)+'\nenddo\nenddo')
 q=q.replace(anchor,anchor+'\n'+marker(txt));s=s[:start]+q+s[stop:]
sources[n]=s
# Actual host raw tendencies and coupled radiation held for each RK stage.
n='dyn_em/solve_em.F';s=(r/'WRF'/n).read_text()
s=decl(s,'   INTEGER :: number_of_small_timesteps, rk_step','character(len=8) :: ea_env\nreal :: ea_rad(grid%sm31:grid%em31,grid%sm32:grid%em32,grid%sm33:grid%em33)')
vals=['grid%rthratenlw(i,k,j)','grid%rthratensw(i,k,j)','grid%rthraten(i,k,j)','pi_phy(i,k,j)','grid%c1h(k)*grid%mut(i,j)+grid%c2h(k)','grid%dnw(k)','moist_old(i,k,j,P_QV)','grid%dt','g','cp','r_v/r_d','th_phy(i,k,j)','p8w(i,k,j)','p8w(i,k+1,j)']
anchor='       CALL first_rk_step_part2 (';assert s.count(anchor)==1
store=enabled('do j=jds,jde-1\ndo k=kds,kde-1\ndo i=ids,ide-1\nea_rad(i,k,j)=(1.+r_v/r_d*moist_old(i,k,j,P_QV))* &\n ((grid%c1h(k)*grid%mut(i,j)+grid%c2h(k))*grid%rthraten(i,k,j))\nenddo\nenddo\nenddo')
s=s.replace(anchor,marker(loop('EA_RAW',vals)+'\n'+store)+anchor)
anchor='         CALL advance_mu_t( grid%ww,';assert s.count(anchor)==1
vals=['t_tend(i,k,j)','ea_rad(i,k,j)','grid%rthraten(i,k,j)','dts_rk','grid%msfty(i,j)','grid%t_2(i,k,j)','grid%dt','-grid%dnw(k)/g','pi_phy(i,k,j)','moist_old(i,k,j,P_QV)','grid%c1h(k)*grid%mut(i,j)+grid%c2h(k)']
s=s.replace(anchor,marker(loop('EA_APPLY',vals,'grid%itimestep,rk_step,iteration,i,j,k',6))+anchor)
sources[n]=s
# Actual dry -> moist total tendency input/output; no tendency writes.
n='dyn_em/module_first_rk_step_part2.F';s=(r/'WRF'/n).read_text()
# i,j,k may already local declarations; use separate index names.
s=decl(s,'    IMPLICIT NONE','character(len=8) :: ea_env\ninteger :: ea_i,ea_j,ea_k')
vals=['t_tendf(i,k,j)','moist_tend(i,k,j,P_QV)','moist_old(i,k,j,P_QV)','grid%t_1(i,k,j)','grid%rthraten(i,k,j)','r_v/r_d']
anchor='       IF ( config_flags%use_theta_m .EQ. 1 ) THEN';assert s.count(anchor)==1
logs=loop('EA_DRY',vals).replace('rk_step','rk_step').replace('(i,','(ea_i,').replace(',k,',',ea_k,').replace(',j)',',ea_j)').replace('do j=','do ea_j=').replace('do k=','do ea_k=').replace('do i=','do ea_i=').replace('rk_step,i,j,k','rk_step,ea_i,ea_j,ea_k')
logs=re.sub(r'\b([ijk])\b',lambda m:'ea_'+m.group(1),logs)
s=s.replace(anchor,marker(logs)+anchor)
anchor='       END IF ! use moist theta';assert s.count(anchor)==1
s=s.replace(anchor,anchor+'\n'+marker(logs.replace('EA_DRY','EA_MOIST')));sources[n]=s
# Record actual small-step source add before advection; stage information correlated with EA_APPLY order.
n='dyn_em/module_small_step_em.F';s=(r/'WRF'/n).read_text();start=s.index('SUBROUTINE advance_mu_t(');stop=s.index('END SUBROUTINE advance_mu_t',start);q=s[start:stop]
q=decl(q,'  REAL    :: acc','character(len=8) :: ea_env\nreal :: ea_tpre(its:ite,kts:kte,jts:jte)')
anchor='       t_ave(i,k,j) = t(i,k,j)';assert q.count(anchor)==1
q=q.replace(anchor,marker('ea_env=""\ncall get_environment_variable("WRF_RADIATION_ENERGY",ea_env)\nif(trim(ea_env)=="1") ea_tpre(i,k,j)=t(i,k,j)')+anchor)
anchor='       t   (i,k,j) = t(i,k,j) + msfty(i,j)*dts*ft(i,k,j)';assert q.count(anchor)==1
q=q.replace(anchor,anchor+'\n'+marker('if(trim(ea_env)=="1") then\nwrite(*,\'(a,4(i0,1x),6(es25.17,1x))\') "EA_ADD ",step,i,j,k, &\nreal(ea_tpre(i,k,j),8),real(t(i,k,j),8),real(ft(i,k,j),8),real(msfty(i,j),8),real(dts,8),real(dnw(k),8)\nendif'))
s=s[:start]+q+s[stop:];sources[n]=s
# Real YSU water tridiagonal before destructive solve, solution before REAL32 tendency return.
n='phys/physics_mmm/bl_ysu.F90';s=(r/'WRF'/n).read_text()
anchor='   dt2 = 2.*dtstep';pos=s.index(anchor); # insert declarations before executable region via known declaration
# find actual subroutine containing dt2
p=s.rfind('\nsubroutine ',0,pos);print('YSU routine offset',p)
# uses lower case implicit none inside ysu2d
print(s[p:p+160])
# declaration anchor unique
anchor='   dt2 = 2.*dtstep'
# insert declarations just before local integer declaration (inspect by scanning)
line=re.search(r'^\s*(?:integer|INTEGER).*::.*\bi\b.*\bk\b.*$',s[:pos],re.M)
# use location near this routine: last implicit none before pos
ip=s.lower().rfind('implicit none',0,pos);end=s.index('\n',ip)
s=s[:end+1]+marker('character(len=8) :: ea_env\ninteger,save :: ea_call=0\ninteger :: ea_i,ea_k')+s[end+1:]
anchor='   call tridin_ysu(al,adv,cu,r1,au,f1,its,ite,kts,kte,1)';assert s.count(anchor)==1
vals=['al(ea_i,ea_k)','adv(ea_i,ea_k)','cu(ea_i,ea_k)','r1(ea_i,ea_k)','qvx(ea_i,ea_k)','del(ea_i,ea_k)','dt2','g','qfx(ea_i)','bepswitch','a_q2d(ea_i,ea_k)','b_q2d(ea_i,ea_k)','sfk2d(ea_i,ea_k)','vlk2d(ea_i,ea_k)']
txt=enabled('ea_call=ea_call+1\ndo ea_i=its,ite\ndo ea_k=kts,kte\n'+f'write(*,\'(a,3(i0,1x),{len(vals)}(es25.17,1x))\') "YS_MATRIX ",ea_call,ea_i,ea_k, &\n'+', &\n'.join('real('+v+',8)' for v in vals)+'\nenddo\nenddo')
s=s.replace(anchor,marker(txt)+anchor)
anchor='         qvtnp(i,k) = qtend';assert s.count(anchor)==1
s=s.replace(anchor,anchor+'\n'+marker('if(trim(ea_env)=="1") then\nwrite(*,\'(a,3(i0,1x),3(es25.17,1x))\') "YS_RETURN ",ea_call,i,k, &\nreal(f1(i,k),8),real(qtend,8),real(rdt,8)\nendif'));sources[n]=s
for n,s in sources.items():
 assert [x for x in re.sub(r'! ENERGY_OBSERVER_BEGIN\n.*?! ENERGY_OBSERVER_END\n','',s,flags=re.S).splitlines() if x.strip()]==[x for x in (r/'WRF'/n).read_text().splitlines() if x.strip()],n
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
spec=importlib.util.spec_from_file_location('h',r/'WRF/test/rrtmgp/test_netcdf_zz.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);runner=h.Runner(b,240,dict(os.environ),len(sources)+2)
flags=(old/'CMakeFiles/WRF_Core.dir/flags.make').read_text();args=[]
for key in ['Fortran_DEFINES','Fortran_INCLUDES','Fortran_FLAGS']:args+=shlex.split(re.search('^'+key+r' = (.*)$',flags,re.M).group(1))
args=[x for x in args if not x.startswith('-J')]+['-J'+str(b/'modules')]
objs=[]
for n in sources:
 p=b/n;o=b/(Path(n).name+'.o');objs.append(o)
 runner.run(['/usr/bin/gfortran',*args,'-ffree-form','-cpp','-O2','-ftree-vectorize','-funroll-loops','-ffree-line-length-none','-fallow-argument-mismatch','-fallow-invalid-boz','-c',p,'-o',o],b,'compile_'+Path(n).name)
shutil.copy2(old/'libWRF_Core.a',b/'libWRF_Core.a');runner.run(['ar','r',b/'libWRF_Core.a',*objs],b,'replace_readonly_members')
args=shlex.split((old/'main/CMakeFiles/wrf.dir/link.txt').read_text());out=[];skip=False
for x in args:
 if skip:skip=False;continue
 if x.startswith('-Wl,--dependency-file='):continue
 if x=='-o':out+=['-o',str(b/'wrf')];skip=True
 elif x=='../libWRF_Core.a':out.append(str(b/'libWRF_Core.a'))
 elif x.endswith(('.a','.o')) and not x.startswith('/'):out.append(str((old/'main'/x).resolve()))
 else:out.append(x)
runner.run(out,b,'link_readonly_energy_observer');h.write_json(b/'receipt.json',{'commands':runner.commands,'executable':h.pin(b/'wrf'),'sources':{n:{'original':h.pin(r/'WRF'/n),'observer':h.pin(b/n)} for n in sources},'base_archive':h.pin(old/'libWRF_Core.a'),'new_archive':h.pin(b/'libWRF_Core.a'),'production_source_changed':False})
