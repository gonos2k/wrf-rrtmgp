from pathlib import Path
import importlib.util,json,gzip
r=Path.cwd();spec=importlib.util.spec_from_file_location('trace',r/'validation/rrtmgp37/radiation-occurrence-runtime/verify_saved.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
b=r/'validation/rrtmgp37/host-source-fixed-psd/saved/psd'
x={}
for s in (8,16):
 for mode in ('LUT','NIR_Mie'):
  _,x[s,mode]=t.trace(gzip.decompress((b/f'sw-s{s}-{mode}/sw.result.gz').read_bytes()),'result')
out={}
for field in ('UP','DN','HR'):
 a={k:v[field]['values'] for k,v in x.items()}
 d=[(h16-h8)-(l16-l8) for h16,h8,l16,l8 in zip(a[16,'NIR_Mie'],a[8,'NIR_Mie'],a[16,'LUT'],a[8,'LUT'])]
 i=max(range(len(d)),key=lambda i:abs(d[i]));out[field]={'shape':x[8,'LUT'][field]['shape'],'interaction_signed':d,'max_abs':abs(d[i]),'signed_at_max':d[i],'fortran_flat_index_1based':i+1,'units':'K/day' if field=='HR' else 'W/m2'}
print(json.dumps(out,indent=2))
Path('/tmp/psd_interaction.json').write_text(json.dumps(out,indent=2)+'\n')
