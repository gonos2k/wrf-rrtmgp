from pathlib import Path
import os,sys,shutil,numpy as np,netCDF4
r=Path.cwd();b=r.parent/'udm37-radiation-energy-host-v1';b.mkdir(exist_ok=False);src=r.parent/'udm37-consistent-warm-v5/on_dt10';exe=r.parent/'udm37-radiation-energy-observer-v2/wrf';sys.path.insert(0,str(r/'WRF/test/rrtmgp'));import test_netcdf_zz as h;import test_udm_startup_snow_scm as setup
env={**os.environ,'OMP_NUM_THREADS':'1','LD_LIBRARY_PATH':str(r.parent/'deps/netcdf/lib')}
for k in tuple(env):
 if k.startswith(('WRF_UDM_','WRF_RRTMGP_','WRF_RADIATION_ENERGY')):env.pop(k)
runner=h.Runner(b,180,env,3)
for name,on,radt in [('off',False,'0'),('on',True,'0'),('held30s',True,'0.5')]:
 d=b/name;d.mkdir()
 for p in src.iterdir():
  if p.is_file() and not p.name.startswith(('wrfout','wrfrst','rsl.','udm_')) and p.name not in ['stdout.log','namelist.output']:shutil.copy2(p,d/p.name)
 (d/'namelist.input').write_text(setup.set_assignment((src/'namelist.input').read_text(),'radt',radt,group='physics'))
 runner.environment['WRF_RADIATION_ENERGY']='1' if on else '0'
 runner.run([exe],d,name);h.write_json(b/'receipt.json',{'commands':runner.commands,'executable':h.pin(exe),'initial_input':h.pin(d/'wrfinput_d01'),'production_accepted':False})
with netCDF4.Dataset(next((b/'off').glob('wrfout*'))) as a,netCDF4.Dataset(next((b/'on').glob('wrfout*'))) as c,netCDF4.Dataset(next(src.glob('wrfout*'))) as p:
 names=[n for n in a.variables if 'Time' in a[n].dimensions];assert all(np.asarray(a[n][:]).tobytes()==np.asarray(c[n][:]).tobytes()==np.asarray(p[n][:]).tobytes() for n in names)
h.write_json(b/'passivity.json',{'time_variables':len(names),'times':7,'off_on_PR176_all_bytes_equal':True})
print('PASS PASSIVITY',len(names))
