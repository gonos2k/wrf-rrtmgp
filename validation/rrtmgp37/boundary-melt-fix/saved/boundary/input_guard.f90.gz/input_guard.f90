program guard_probe
implicit none
type config
 integer::udm_number_policy,mp_physics,ra_lw_physics,ra_sw_physics,scalar_adv_opt,max_dom
 logical::specified,nested,periodic_x,periodic_y
end type
type domain
 integer::id
end type
type(config)::config_flags
type(domain)::grid
integer,parameter::UDMSCHEME=27,RRTMGP_LWSCHEME=37,RRTMGP_SWSCHEME=37
integer::c
character(8)::arg
call get_command_argument(1,arg)
read(arg,*) c
config_flags=config(1,27,37,37,0,1,.false.,.false.,.true.,.true.)
grid%id=1
select case(c)
case(1)
 config_flags%specified=.true.
case(2)
 config_flags%nested=.true.
case(3)
 config_flags%max_dom=2
case(4)
 grid%id=2
case(5)
 config_flags%periodic_x=.false.
case(6)
 config_flags%periodic_y=.false.
case(7)
 config_flags%udm_number_policy=0
 config_flags%specified=.true.
 config_flags%nested=.true.
 config_flags%max_dom=2
 config_flags%periodic_x=.false.
 config_flags%periodic_y=.false.
end select
        IF (config_flags%udm_number_policy == 1) THEN
          ! No eta producer/transform exists for lateral or nested boundaries.
          ! Reject on input, before a correctly tagged file can enter that path.
          IF (config_flags%specified .OR. config_flags%nested .OR. &
              config_flags%max_dom /= 1 .OR. grid%id /= 1 .OR. &
              .NOT. config_flags%periodic_x .OR. .NOT. config_flags%periodic_y) &
            CALL wrf_error_fatal("dry-number-grid-v1 requires one periodic domain; specified/nested boundaries unsupported")
          IF (config_flags%mp_physics /= UDMSCHEME .OR. &
              config_flags%ra_lw_physics /= RRTMGP_LWSCHEME .OR. &
              config_flags%ra_sw_physics /= RRTMGP_SWSCHEME .OR. &
              config_flags%scalar_adv_opt /= 0) &
            CALL wrf_error_fatal("dry-number-grid-v1 supports UDM27/LW37/SW37 with scalar_adv_opt=0")
        ENDIF
print *, 'GUARD_ACCEPTED'
end program
subroutine wrf_error_fatal(text)
character(*),intent(in)::text
print *, 'FATAL CALLED ',text
! Deliberately RC0, matching serial WRF STOP semantics.
stop
end subroutine
