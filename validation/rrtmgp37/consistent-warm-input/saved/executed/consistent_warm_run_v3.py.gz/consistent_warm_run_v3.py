from pathlib import Path
import os,sys,shutil,json,importlib.util,hashlib
import netCDF4,numpy as np
r=Path.cwd();b=r.parent/'udm37-consistent-warm-v3';b.mkdir(exist_ok=False);source=r.parent/'udm37-cf0-scm-v3/control';base=r.parent/'udm37-cf0-transition-build-v1/producer'
sys.path.insert(0,str(r/'WRF/test/rrtmgp'));import test_netcdf_zz as h;import test_udm_startup_snow_scm as setup
env={**os.environ,'OMP_NUM_THREADS':'1','LD_LIBRARY_PATH':str(r.parent/'deps/netcdf/lib')}
for k in tuple(env):
 if k.startswith(('WRF_UDM_','WRF_RRTMGP_')):env.pop(k)
runner=h.Runner(b,180,env,5);d=b/'producer';d.mkdir()
for p in source.iterdir():
 if p.is_file() and not p.name.startswith(('wrfout','wrfrst','rsl.','udm_')) and p.name not in ('namelist.output','stdout.log','wrfinput_d01'):shutil.copy2(p,d/p.name)
text=(source/'namelist.input').read_text()
for key,value,group in [('udm_number_policy','0','physics'),('udm_population_policy','0','physics'),('ztop','12000.','domains'),('restart_interval_s','0','time_control')]:text=setup.set_assignment(text,key,value,group=group)
(d/'namelist.input').write_text(text)
T=293.;qv=.009;g=9.81;rd=287.;cp=1004.5;rv=461.6
lines=[f'0 0 0 {T} {qv} 100000']
for z in range(0,20001,100):
 p=1.e5*np.exp(-g*z*(1+qv)/(rd*T*(1+rv/rd*qv)));theta=T*(p/1e5)**(-rd/cp);lines.append(f'{z} 0 0 {theta:.12g} {qv}')
(d/'input_sounding').write_text('\n'.join(lines)+'\n');runner.run([base/'main/ideal'],d,'canonical_ideal_warm')
assert (d/'wrfinput_d01').exists()
shutil.copy2(d/'wrfinput_d01',b/'ideal_unmodified.nc')
with netCDF4.Dataset(d/'wrfinput_d01','r+') as x:
 rho=1./(np.asarray(x['AL'][0],float)+x['ALB'][0]);md=-(x['MU'][0]+x['MUB'][0])[None,:,:]*np.asarray(x['DNW'][0],float)[:,None,None]/np.float32(9.81);dz=np.diff(np.asarray(x['PH'][0],float)+x['PHB'][0],axis=0)/np.float32(9.81)
 ratio=rho*dz/md;temp=(np.asarray(x['T'][0],float)+300)*((x['P'][0]+x['PB'][0])/1e5)**(rd/cp)
 print('INITIAL',ratio.min(),ratio.max(),'T',temp.min(),temp.max(),flush=True)
 # Declared finite condensate perturbation, retaining canonical EOS/geometry/base state.
 # Population input is constructed explicitly, not a reinterpretation of legacy raw numbers.
 z=(np.asarray(x['PH'][0],float)+x['PHB'][0])/np.float32(9.81);zc=(z[1:]+z[:-1])/2;active=zc<1500
 x['QCLOUD'][0]=np.where(active,1e-5,0);x['QRAIN'][0]=np.where(active,2e-4,0)
 for name,nvol in [('QNCCN',1e8),('QNCLOUD',5e7),('QNRAIN',2e4)]:x[name][0]=np.where(active,nvol/rho,0) if name!='QNCCN' else nvol/rho
 x.setncattr('UDM_NUMBER_POLICY',np.int32(1));x.setncattr('UDM_POPULATION_POLICY',np.int32(2));x.setncattr('RESEARCH_INPUT_DEFINITION','canonical warm SCM sounding; explicit dry-number-grid-v1 finite condensate perturbation')
for name,dt in [('on_dt10',10),('on_dt5',5)]:
 c=b/name;shutil.copytree(d,c);t=setup.set_assignment(text,'udm_number_policy','1');t=setup.set_assignment(t,'udm_population_policy','2');t=setup.set_assignment(t,'time_step',str(dt),group='domains');(c/'namelist.input').write_text(t)
 runner.environment['WRF_UDM_BUDGET']='1';runner.run([r.parent/'udm37-budget-observer-v2/wrf'],c,name)
 h.write_json(b/'receipt.json',{'processes':runner.commands,'source_ideal':h.pin(base/'main/ideal'),'source_wrf':h.pin(r.parent/'udm37-budget-observer-v2/wrf'),'production_accepted':False})
print('DONE',flush=True)
