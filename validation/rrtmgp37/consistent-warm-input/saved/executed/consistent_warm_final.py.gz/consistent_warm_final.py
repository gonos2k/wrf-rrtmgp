from pathlib import Path
import os,sys,shutil,json,netCDF4,numpy as np
r=Path.cwd();b=r.parent/'udm37-consistent-warm-v5';b.mkdir(exist_ok=False);source=r.parent/'udm37-consistent-warm-v3/producer';sys.path.insert(0,str(r/'WRF/test/rrtmgp'));import test_netcdf_zz as h;import test_udm_startup_snow_scm as setup
env={**os.environ,'OMP_NUM_THREADS':'1','LD_LIBRARY_PATH':str(r.parent/'deps/netcdf/lib')}
for k in tuple(env):
 if k.startswith(('WRF_UDM_','WRF_RRTMGP_')):env.pop(k)
runner=h.Runner(b,180,env,5)
d=b/'producer';shutil.copytree(source,d)
shutil.copy2(r.parent/'udm37-consistent-hydrostatic-v2.nc',d/'wrfinput_d01')
text=(d/'namelist.input').read_text();text=setup.set_assignment(text,'udm_number_policy','1');text=setup.set_assignment(text,'udm_population_policy','2')
for name,dt,on in [('off_dt10',10,False),('on_dt10',10,True),('on_dt5',5,True)]:
 c=b/name;shutil.copytree(d,c);(c/'namelist.input').write_text(setup.set_assignment(text,'time_step',str(dt),group='domains'));runner.environment['WRF_UDM_BUDGET']='1' if on else '0';runner.run([r.parent/'udm37-budget-observer-v2/wrf'],c,name)
 h.write_json(b/'receipt.json',{'processes':runner.commands,'executable':h.pin(r.parent/'udm37-budget-observer-v2/wrf'),'production_accepted':False})
with netCDF4.Dataset(next((b/'off_dt10').glob('wrfout*'))) as x,netCDF4.Dataset(next((b/'on_dt10').glob('wrfout*'))) as y:
 names=[n for n in x.variables if 'Time' in x[n].dimensions];assert all(np.asarray(x[n][:]).tobytes()==np.asarray(y[n][:]).tobytes() for n in names)
print('DONE OFF_ON',len(names),flush=True)
