from pathlib import Path
import os,sys,shutil,json,importlib.util
import netCDF4,numpy as np
r=Path.cwd();b=r.parent/'udm37-two-band-thin-flux-v1';b.mkdir(exist_ok=False);sys.path.insert(0,str(r/'WRF/test/rrtmgp'));import test_netcdf_zz as h
s=importlib.util.spec_from_file_location('p',r/'validation/rrtmgp37/radiation-occurrence-runtime/verify_saved.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
header,inp=v.trace((r.parent/'udm37-independent-mie-flux-v3/sw-baseline/input').read_bytes(),'input');nl=header[2];selected=29
with netCDF4.Dataset(r/'WRF/run/rrtmgp-clouds-sw-bnd.nc') as x:ext=float(np.interp(12,np.arange(2.5,22,1),x['extliq'][5]))
path=1/ext
for n in ['LWP','IWP','RWP','SWP','UNIFORM_LWP','UNIFORM_RWP','CF']:
 if n in inp:inp[n]['values']=[0.]*nl
inp['CF']['values'][selected]=1.;inp['LWP']['values'][selected]=path;inp['REL']['values']=[12.]*nl
text='RRTMGP_REPLAY_V12\n'+' '.join(map(str,header))+'\n'
for n,z in inp.items():text+=n+' '+' '.join(map(str,z['shape']))+'\n'+''.join(f'{a:.17e}\n' for a in z['values'])
(b/'input').write_text(text);opt=json.loads((r.parent/'udm37-matched-two-band-v1/result.json').read_text());exe=r.parent/'udm37-cf0-psd-optics-v4/build/column';runner=h.Runner(b,90,{**os.environ,'LD_LIBRARY_PATH':str(r.parent/'deps/netcdf/lib')},3)
for mode in ['LUT','Hale','Segelstein']:
 data=r/'WRF/run'
 if mode!='LUT':
  data=b/(mode+'-tables');data.mkdir()
  for f in ['rrtmgp-gas-sw-g224.nc','rrtmgp-gas-lw-g256.nc','rrtmgp-clouds-lw-bnd.nc']:
   q=r/'WRF/run'/f
   if q.exists():(data/f).symlink_to(q.resolve())
  # Preserve all untouched tables including gas filenames actually requested.
  for q in (r/'WRF/run').glob('rrtmgp*.nc'):
   if q.name!='rrtmgp-clouds-sw-bnd.nc' and not (data/q.name).exists():(data/q.name).symlink_to(q.resolve())
  shutil.copy2(r/'WRF/run/rrtmgp-clouds-sw-bnd.nc',data/'rrtmgp-clouds-sw-bnd.nc')
  with netCDF4.Dataset(data/'rrtmgp-clouds-sw-bnd.nc','r+') as d:
   for band in [8,6]:
    row=next(z for z in opt['records'] if z['band']==band and z['case']==('baseline' if mode=='Hale' else 'RI_Segelstein_same_25C'));z=row['calculations']['r2048s192']['Planck5780']
    for n,value in [('extliq',z['ext']),('ssaliq',z['ssa']),('asyliq',z['g'])]:d[n][band-1,9:11]=value
   d.setncattr('RESEARCH_OVERRIDE','only reff12 query; adjacent nodes identical Mie12; bands6/8; no production changes')
 d=b/mode;d.mkdir();(d/'capture').mkdir();shutil.copy2(b/'input',d/'input');runner.environment['WRF_RRTMGP_CAPTURE_DIR']=str(d/'capture');runner.run([exe,data,d/'input'],d,'thin_SW_'+mode)
h.write_json(b/'receipt.json',{'executable':h.pin(exe),'commands':runner.commands,'changed_input':'one liquid layer with cloud fraction1, reff12, band6 raw tau1; other hydrometeors zero','selected_native_level':30,'LWP_g_m2':path,'production_accepted':False});print('DONE')
