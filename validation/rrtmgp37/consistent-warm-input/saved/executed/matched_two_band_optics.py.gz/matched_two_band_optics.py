from pathlib import Path
import os,sys,json,math,time,hashlib
os.environ['MIEPYTHON_USE_JIT']='1';sys.path.insert(0,str(Path('../deps/miepython-3.2.0').resolve()))
import miepython as mie,numpy as np,scipy.integrate as it,netCDF4
from numpy.polynomial.legendre import leggauss
r=Path.cwd();b=r.parent/'udm37-matched-two-band-v1';b.mkdir(exist_ok=False);sources={'Hale':r.parent/'udm37-budget-optics-inputs/Hale.yml','Segelstein':r.parent/'udm37-matched-optics-inputs/Segelstein.yml'}
def data(p):
 a=[]
 for l in p.read_text().splitlines():
  try:
   w=list(map(float,l.split()))
   if len(w)==3:a.append(w)
  except ValueError:pass
 return np.array(a)
datafiles={n:data(p) for n,p in sources.items()}
meta={'engine':mie.__version__,'temperature_K':298.15,'reff_um':12.,'changes_are_one_factor_at_a_time':True,'LUT_original_temperature_PSD_RI_weighting_known':False,'production_accepted':False,'reference_sources':{n:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in sources.items()},'records':[]}
def calc(band,source,k,linear_k,nr,ns):
 with netCDF4.Dataset(r/'WRF/run/rrtmgp-clouds-sw-bnd.nc') as d:lo,hi=map(float,d['bnd_limits_wavenumber'][band-1])
 a=datafiles[source];x,w=leggauss(ns);nu=(lo+hi)/2+(hi-lo)/2*x;wav=1e4/nu;n=np.interp(wav,a[:,0],a[:,1]);kap=np.interp(wav,a[:,0],a[:,2]) if linear_k else np.exp(np.interp(wav,a[:,0],np.log(a[:,2])));m=n-1j*kap
 gx=np.linspace(0,80,nr+1);area=gx**(k+1)*np.exp(-gx)/math.gamma(k+2);rad=gx*12/(k+2);f=3/(4*1000*12e-6)/1000;mom=[]
 for L,M in zip(wav,m):
  qe,qs,qb,g=mie.efficiencies_mx(M,2*np.pi*rad[1:]/L);qe=np.r_[0.,qe];qs=np.r_[0.,qs];g=np.r_[0.,g];z=[f*it.simpson(area*qe,x=gx),f*it.simpson(area*qs,x=gx),f*it.simpson(area*qs*g,x=gx)];mom.append(z)
 mom=np.array(mom);out={}
 for weighting in ['uniform_wavenumber','Planck5780']:
  wt=w if weighting=='uniform_wavenumber' else w*nu**3/np.expm1(1.438776877*nu/5780);z=np.average(mom,weights=wt,axis=0);ext,sca,sg=map(float,z);ssa=sca/ext;g=sg/sca
  out[weighting]={'ext':ext,'sca':sca,'abs':ext-sca,'sca_g':sg,'ssa':ssa,'g':g,'delta_ext':ext*(1-ssa*g*g),'delta_ssa':ssa*(1-g*g)/(1-ssa*g*g),'delta_g':g/(1+g)}
 return out
for band in [8,6]:
 for name,src,k,lk in [('baseline','Hale',8,False),('k_interpolation_linear','Hale',8,True),('RI_Segelstein_same_25C','Segelstein',8,False),('PSD_k16_same_reff','Hale',16,False)]:
  row={'band':band,'case':name,'RI':src,'Gamma_k':k,'effective_variance':1/(k+2),'k_interpolation':'linear' if lk else 'log_linear','calculations':{}}
  for nr,ns in [(1024,96),(2048,192)]:row['calculations'][f'r{nr}s{ns}']=calc(band,src,k,lk,nr,ns)
  with netCDF4.Dataset(r/'WRF/run/rrtmgp-clouds-sw-bnd.nc') as d:
   re=np.linspace(float(d['radliq_lwr'][:]),float(d['radliq_upr'][:]),20);e=float(np.interp(12,re,d['extliq'][band-1]));ssa=float(np.interp(12,re,d['ssaliq'][band-1]));g=float(np.interp(12,re,d['asyliq'][band-1]));row['LUT_raw']={'ext':e,'sca':e*ssa,'abs':e*(1-ssa),'g':g,'sca_g':e*ssa*g}
  meta['records'].append(row);(b/'result.json').write_text(json.dumps(meta,indent=2)+'\n');print(band,name,row['calculations']['r2048s192']['Planck5780']['abs']/row['LUT_raw']['abs'],flush=True)
meta['status']='ACTUAL_INDEPENDENT_ONE_FACTOR_DIAGNOSTIC_COMPLETE';(b/'result.json').write_text(json.dumps(meta,indent=2)+'\n')
