SUBROUTINE RDLIN
!
   USE struct_types

   IMPLICIT REAL*8           (V)
!
!     SUBROUTINE RDLIN INPUTS LINE DATA FROM FILE LINFIL

!
   CHARACTER*8      HLINID,BMOLID,HID1
   CHARACTER*1 CNEGEPP(8)

   integer *4 molcnt,mcntlc,                                         &
   &           mcntnl,linmol,                                         &
   &           lincnt,ilinlc,ilinnl,irec,irectl
   real *4 sumstr,flinlo,flinhi
!
   COMMON /LINHDR/ HLINID(10),BMOLID(64),MOLCNT(64),MCNTLC(64),      &
   &                MCNTNL(64),SUMSTR(64),LINMOL,FLINLO,FLINHI,       &
   &                LINCNT,ILINLC,ILINNL,IREC,IRECTL,HID1(2),LSTWDL

   COMMON VNU(NLINEREC),SP(NLINEREC),ALFA0(NLINEREC),EPP(NLINEREC),MOL(NLINEREC),HWHMS(NLINEREC),  &
   &       TMPALF(NLINEREC),PSHIFT(NLINEREC),IFLG(NLINEREC),SPPSP(NLINEREC),RECALF(NLINEREC),  &
   &       ZETAI(NLINEREC),IZETA(NLINEREC)

   common /brdmoldat/ brd_mol_flg(mxbrdmol,NLINEREC),               &
   &     brd_mol_hw(mxbrdmol,NLINEREC),brd_mol_tmp(mxbrdmol,NLINEREC),               &
   &     brd_mol_shft(mxbrdmol,NLINEREC),sdep(nlinerec)

   dimension    amol(NLINEREC)

   integer *4 nrec,nwds,lnfl,leof,npnlhd


   real *4 str,hw_f,e_low,xmol,hw_s,hw_T,shft
   integer *4 mol_id,jflg,i_1,brd_mol_flg

   COMMON /XSUB/ VBOT,VTOP,VFT,LIMIN,ILO,IHI,IEOF,IPANEL,ISTOP,IDATA
   COMMON /IFIL/ IRD,IPR,IPU,NOPR,NFHDRF,NPHDRF,NFHDRL,NPHDRL,       &
   &              NLNGTH,KFILE,KPANEL,LINFIL,NFILE,IAFIL,IEXFIL,      &
   &              NLTEFL,LNFIL4,LNGTH4
   COMMON /IOU/ IOUT(250)
   common /eppinfo/ negepp_flag
   common /bufid2/ n_negepp(64),n_resetepp(64),xspace(4096),lstwdl2
   integer *4 negepp_flag,n_negepp,n_resetepp
   real *4 xspace

   type(input_header) :: rdlnpnl
   type(input_block)  :: rdlnbuf, dumbuf
!

!***********************************************************************
!
   data i_1/ 1/, npnlhd/ 6/


   lnfl = linfil
!
!     THERE ARE (LIMIN * 9) QUANTITIES READ IN:
!     VNU,SP,ALFA0,EPP,MOL,HWHMS,TMPALF,PSHIFT,IFLG
!
   ILNGTH = NLNGTH*LIMIN
   IDATA = 0
!
!     BUFFER PAST FILE HEADER if necessary
!
   IF (ILO.LE.0) THEN
      REWIND LNFL
      read (lnfl) HLINID
      READ (HLINID(7),950) CNEGEPP
      IF (CNEGEPP(8).eq.'^') THEN
         read (lnfl) n_negepp,n_resetepp,xspace
      endif
   ENDIF
!
   !print *,'will read pnlhd'
10 CALL BUFIN_sgl(Lnfl,LEOF,rdlnpnl,npnlhd)
   !print *,'leof,vmax ',leof,rdlnpnl%vmax
   IF (LEOF.EQ.0) THEN
      !print *,'leof eq 0',dumbuf%vnu(1:5)
      IF (NOPR.EQ.0) WRITE (IPR,900)
      IEOF = 1
      RETURN
   ENDIF
!
   IF (rdlnpnl%nrec.GT.LIMIN) STOP 'RDLIN; NREC GT LIMIN'
!
   !print *,'will read to advance'
   !print *,'lnfl =',lnfl
   !print *,'vbot,vmax ',vbot,rdlnpnl%vmax
   IF (rdlnpnl%VMAX.LT.VBOT) THEN
      CALL BUFIN_sgl(Lnfl,LEOF,dumbuf,i_1)
      GO TO 10
   ENDIF
!
   !print *,'will read panel '
   !print *,'lnfl =',lnfl
   !print *,'nwds ',rdlnpnl%nwds
   CALL BUFIN_sgl(Lnfl,LEOF,rdlnbuf,rdlnpnl%NWDS)
!
!     precision conversion occurs here:
!     incoming on right: vlin is real*8, others real*4 and integer*4
!
   do 15 i=1,rdlnpnl%nrec

      IFLG(i) = rdlnbuf%iflg(i)
      VNU(i) = rdlnbuf%vnu(i)
      SP(i) = rdlnbuf%sp(i)
      ALFA0(i) = rdlnbuf%alfa(i)
      EPP(i) = rdlnbuf%epp(i)

      if (iflg(i) .ge. 0) then
         MOL(i) = rdlnbuf%mol(i) ! int*4 to int*8 (if compiled as r8)
      else
         xmol = transfer(rdlnbuf%mol(i),xmol) !int*4 to real*4)
         amol(i) = xmol   ! real*4 to real*8 (if compiled as r8)
         mol(i) = transfer (amol(i), mol(i))  ! real*8 to int*8  (if compiled as r8)
      endif

      HWHMS(i) = rdlnbuf%hwhm(i)
      TMPALF(i)= rdlnbuf%tmpalf(i)
      PSHIFT(i)= rdlnbuf%pshift(i)

      do j=1,mxbrdmol
         brd_mol_flg(j,i)=rdlnbuf%brd_mol_flg_in(j,i)
      end do
      j = 1
      do j1 = 1,mxbrdmol
         brd_mol_hw(j1,i) = rdlnbuf%brd_mol_dat(j,i)
         brd_mol_tmp(j1,i) = rdlnbuf%brd_mol_dat(j+1,i)
         brd_mol_shft(j1,i) = rdlnbuf%brd_mol_dat(j+2,i)
         j = j+3
      end do
      sdep(i) = rdlnbuf%speed_dep(i)


!  MJA 20140909
!  HITRAN provides widths for broadening by air; LBLRTM and MONORTM have always treated these widths as foreign
!  This assumption is valid for most species, but not for N2 or O2. We now adjust the HITRAN widths to obtain
!  true foreign widths. Similar ajdustment is applied if self shift information is available.
      M = MOD(MOL(I),100)
      !WRITE(*,*) M
      if (M.eq.7 .AND. IFLG(i).ge.0) then
         !WRITE(*,*) M, ALFA0(i),HWHMS(i)
         rvmr = 0.21
         ALFA0(i) = ( ALFA0(i)-rvmr*HWHMS(i))/(1.0-rvmr)
         if (brd_mol_flg(m,i).gt.0) then
            pshift(i) = (pshift(i)-rvmr*brd_mol_shft(m,i))/(1.0-rvmr)
         endif
         !WRITE(*,*) M, ALFA0(i),HWHMS(i)
      endif
      if (M.eq.22 .AND. IFLG(i).ge.0) then
         rvmr = 0.79
         ALFA0(i) = ( ALFA0(i)-rvmr*HWHMS(i))/(1.0-rvmr)
! Currently SBS broadening is only code for the first seven HITRAN species
! When it becomes available for N2, the next three lines should become executable
         !if (brd_mol_flg(m,i).gt.0) then
         !   pshift(i) = (pshift(i)-rvmr*brd_mol_shft(m,i))/(1.0-rvmr)
         !endif
      endif

15 continue

   IF ((ILO.EQ.0).AND.(VMIN.GT.VBOT)) WRITE (IPR,905)
   ILO = 1
!
   IJ = 0
   DO 20 I = 1, rdlnpnl%NREC
      IF (IFLG(I).GE.0) THEN
         IJ = IJ+1
         IOUT(IJ) = I
      ENDIF
20 END DO
!
   DO 30 I = IJ+1, 250
      IOUT(I) = rdlnpnl%NREC
30 END DO
!
   IF (VMIN.LT.VBOT) THEN
      DO 40 J = 1, IJ
         I = IOUT(J)
         ILO = J
         IF (VNU(I).GE.VBOT) GO TO 50
40    CONTINUE
   ENDIF
!
50 CONTINUE
   DO 60 J = ILO, IJ
      I = IOUT(J)
      IF (MOL(I).GT.0) THEN
         IHI = J
         IF (VNU(I).GT.VTOP) GO TO 70
      ENDIF
60 END DO

!     the following test is to see if more data is required
!     idata = 1 means data requirements have been met

70 IF (IHI.LT.IJ) IDATA = 1
!
   RETURN
!
900 FORMAT ('  EOF ON LINFIL (MORE LINES MAY BE REQUIRED) ')
905 FORMAT (                                                          &
   &   ' FIRST LINE ON LINFIL USED (MORE LINES MAY BE REQUIRED) ')
950 FORMAT (8a1)
!
