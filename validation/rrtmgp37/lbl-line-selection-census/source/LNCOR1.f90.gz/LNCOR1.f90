SUBROUTINE LNCOR1 (NLNCR,IHI,ILO,MEFDP)
!
   USE lblparams, ONLY: MXMOL, MXISOTPL
   USE phys_consts, ONLY: radcn2
   USE struct_types, ONLY: mxbrdmol, nlinerec
   IMPLICIT REAL*8           (V)
!
   CHARACTER*1 FREJ(nlinerec),HREJ,HNOREJ
   COMMON /RCNTRL/ ILNFLG
   COMMON VNU(nlinerec),S(nlinerec),ALFA0(nlinerec),EPP(nlinerec),MOL(nlinerec),HWHMS(nlinerec),   &
   &       TMPALF(nlinerec),PSHIFT(nlinerec),IFLG(nlinerec),SPPSP(nlinerec),RECALF(nlinerec),  &
   &       ZETAI(nlinerec),IZETA(nlinerec)
   common /brdmoldat/ brd_mol_flg(mxbrdmol,nlinerec),       &
   &     brd_mol_hw(mxbrdmol,nlinerec),brd_mol_tmp(MXBRDMOL,nlinerec),    &
   &     brd_mol_shft(mxbrdmol,nlinerec),sdep(nlinerec)
   integer*4 brd_mol_flg

   DIMENSION TMPCOR_ARR(MXBRDMOL),ALFA_TMP(MXBRDMOL)
   Real*8 ALFSUM


   COMMON /IOU/ IOUT(nlinerec)
   COMMON /MANE/ P0,TEMP0,NLAYRS,DVXM,H2OSLF,WTOT,ALBAR,ADBAR,AVBAR, &
   &              AVFIX,LAYRFX,SECNT0,SAMPLE,DVSET,ALFAL0,AVMASS,     &
   &              DPTMIN,DPTFAC,ALTAV,AVTRAT,TDIFF1,TDIFF2,ALTD1,     &
   &              ALTD2,ANGLE,IANT,LTGNT,LH1,LH2,IPFLAG,PLAY,TLAY,    &
   &              EXTID(10)
   CHARACTER*8  EXTID
!
   CHARACTER*8      XID,       HMOLID,      YID
   Real*8               SECANT,       XALTZ
!
   COMMON /FILHDR/ XID(10),SECANT,PAVE,TAVE,HMOLID(60),XALTZ(4),     &
   &                WK(60),PZL,PZU,TZL,TZU,WBROAD,DV ,V1 ,V2 ,TBOUND, &
   &                EMISIV,FSCDID(17),NMOL,LAYER ,YI1,YID(10),LSTWDF
   COMMON /IFIL/   IRD,IPR,IPU,NOPR,NFHDRF,NPHDRF,NFHDRL,NPHDRL,     &
   &                NLNGTH,KFILE,KPANEL,LINFIL,NFILE,IAFIL,IEXFIL,    &
   &                NLTEFL,LNFIL4,LNGTH4,IBRD
   COMMON /XSUB/   VBOT,VTOP,VFT,DUM(7)
   COMMON /LAMCHN/ ONEPL,ONEMI,EXPMIN,ARGMIN
   COMMON /LBLF/ V1R4,V2R4,DVR4,NPTR4,BOUND4,R4(2502),RR4(2502)
   COMMON /CMSHAP/ HWF1,DXF1,NX1,N1MAX,HWF2,DXF2,NX2,N2MAX,          &
   &                HWF3,DXF3,NX3,N3MAX
   COMMON /VOICOM/ AVRAT(102),CGAUSS(102),CF1(102),CF2(102),         &
   &                CF3(102),CER(102)
!
   COMMON /ISVECT/ ISO_MAX(MXMOL),SMASSI(mxmol,10)
!
   COMMON /LNC1/ RHOSLF(mxmol),ALFD1(42,10),SCOR(42,10),ALFMAX,      &
   &              BETACR,DELTMP,DPTFC,DPTMN,XKT,NMINUS,NPLUS,NLIN,    &
   &              LINCNT,NCHNG,SUMALF,SUMZET,TRATIO,RHORAT,PAVP0,     &
   &              PAVP2,RECTLC,TMPDIF,ILC
   DIMENSION MEFDP(64),FILHDR(2),AMOL(250),SP(250)
   DIMENSION A(4),B(4),TEMPLC(4)
!
   COMMON /PATH_ISOTPL/ ISOTPL,NISOTPL,                              &
   &                     ISOTPL_FLAG(MXMOL,MXISOTPL),                 &
   &                     ISOTPL_MAIN_FLAG(MXMOL),                     &
   &                     MOLNUM(MXMOL*MXISOTPL),                      &
   &                     ISOTPLNUM(MXMOL*MXISOTPL),                   &
   &                     WKI(MXMOL,MXISOTPL)
!
   EQUIVALENCE (MOL(1),AMOL(1)) , (S(1),SP(1))
   EQUIVALENCE (IHIRAC,FSCDID(1)) , (ILBLF4,FSCDID(2)),              &
   &            (IXSCNT,FSCDID(3)) , (IAERSL,FSCDID(4)),              &
   &            (JRAD,FSCDID(9)) , (XID(1),FILHDR(1))
!
   character*8 h_lncor1
!
   data h_lncor1/' lncor1 '/
!
!     TEMPERATURES FOR LINE COUPLING COEFFICIENTS
!
   DATA TEMPLC / 200.0,250.0,296.0,340.0 /
   DATA HREJ /'0'/,HNOREJ /'1'/
   DATA NWDTH /0/
!
   DATA I_1/1/, I_100/100/, I_1000/1000/
!
   NLNCR = NLNCR+1
   IF (NLNCR.EQ.1) THEN
!
      XKT0 = TEMP0/RADCN2
      XKT = TAVE/RADCN2
      DELTMP = ABS(TAVE-TEMP0)
      BETACR = (1./XKT)-(1./XKT0)
      CALL MOLEC (2,SCOR,RHOSLF,ALFD1)
!
      TRATIO = TAVE/TEMP0
      RHORAT = (PAVE/P0)*(TEMP0/TAVE)
!
      PAVP0 = PAVE/P0
      PAVP2 = PAVP0*PAVP0
!
!     FIND CORRECT TEMPERATURE AND INTERPOLATE FOR Y AND G
!
      DO 10 IL = 1, 3
         ILC = IL
         IF (TAVE.LT.TEMPLC(ILC+1)) GO TO 20
10    CONTINUE
20    IF (ILC.EQ.4) ILC = 3
!
      RECTLC = 1.0/(TEMPLC(ILC+1)-TEMPLC(ILC))
      TMPDIF = TAVE-TEMPLC(ILC)
!
   ENDIF
!
   IF (ILNFLG.EQ.2) READ(15)(FREJ(J),J=ILO,IHI)
!
   DO 30 J = ILO, IHI
      YI = 0.
      GI = 0.
      GAMMA1 = 0.
      GAMMA2 = 0.
      I = IOUT(J)
      IFLAG = IFLG(I)
      M = MOD(MOL(I),I_100)
!
!     ISO=(MOD(MOL(I),1000)-M)/100   IS PROGRAMMED AS:
!
      ISO = MOD(MOL(I),I_1000)/100
!
!     check if lines are within allowed molecular and isotopic limits
!
      if (m.gt.mxmol .or. m.lt. 1) then
         call line_exception (1,ipr,h_lncor1,m,nmol,iso,iso_max)
         go to 25
      else if (iso .gt. iso_max(m)) then
         call line_exception (2,ipr,h_lncor1,m,nmol,iso,iso_max)
         go to 25
      endif
!
      MOL(I) = M
!
      IF (ISOTPL_FLAG(M,ISO).EQ.0) THEN
         SUI = S(I)*WK(M)
      ELSE
         SUI = S(I)*WKI(M,ISO)
      ENDIF
!
!MJA, 20150821 - using the VNU(I) approximation for the radiation term
!                can cause issues for wavenumbers around 1000 cm-1,
!                so use the full rad term instead
!         IF (JRAD.EQ.1) SUI = SUI*VNU(I)
      IF (JRAD.EQ.1) SUI = SUI*RADFN(VNU(I),XKT)
!
      IF (SUI.EQ.0.) GO TO 25
!
      NLIN = NLIN+1
!
!     Y'S AND G'S ARE STORED IN I+1 POSTION OF VNU,S,ALFA0,EPP...
!       A(1-4),  B(1-4) CORRESPOND TO TEMPERATURES TEMPLC(1-4) ABOVE
!
      IF (IFLAG.EQ.1.OR.IFLAG.EQ.3) THEN
         A(1) = VNU(I+1)
         B(1) = S(I+1)
         A(2) = ALFA0(I+1)
         B(2) = EPP(I+1)
         A(3) = AMOL(I+1)
         B(3) = HWHMS(I+1)
         A(4) = TMPALF(I+1)
         B(4) = PSHIFT(I+1)
!
!     CALCULATE SLOPE AND EVALUATE
!
         SLOPEA = (A(ILC+1)-A(ILC))*RECTLC
         SLOPEB = (B(ILC+1)-B(ILC))*RECTLC
!
         IF (IFLAG.EQ.1) THEN
            YI = A(ILC)+SLOPEA*TMPDIF
            GI = B(ILC)+SLOPEB*TMPDIF
         ELSE
            GAMMA1 = A(ILC)+SLOPEA*TMPDIF
            GAMMA2 = B(ILC)+SLOPEB*TMPDIF
         ENDIF
      ENDIF
!
!     IFLAG = 2 IS RESERVED FOR LINE COUPLING COEFFICIENTS ASSOCIATED
!               WITH AN EXACT TREATMENT (NUMERICAL DIAGONALIZATION)
!
!     IFLAG = 3 TREATS LINE COUPLING IN TERMS OF REDUCED WIDTHS
!
      VNU(I) = VNU(I)+RHORAT*PSHIFT(I)
      if(sum(brd_mol_flg(:,i)).gt.0.AND.ibrd.gt.0) then
         vnu(i) = vnu(i)+sum(rhoslf(1:mxbrdmol)*brd_mol_flg(:,i)* &
         &           (brd_mol_shft(:,i)-pshift(i)))
      endif

!
!     TEMPERATURE CORRECTION OF THE HALFWIDTH
!     SELF TEMP DEPENDENCE TAKEN THE SAME AS FOREIGN
!
      TMPCOR = TRATIO**TMPALF(I)
      ALFA0I = ALFA0(I)*TMPCOR
      HWHMSI = HWHMS(I)*TMPCOR
      ALFL = ALFA0I*(RHORAT-RHOSLF(m))+HWHMSI*RHOSLF(m)

      if(sum(brd_mol_flg(:,i)).gt.0.AND.ibrd.gt.0) then
         tmpcor_arr = tratio**brd_mol_tmp(:,i)
         alfa_tmp = brd_mol_hw(:,i)*tmpcor_arr
         alfsum = sum(rhoslf(1:mxbrdmol)*brd_mol_flg(:,i)*alfa_tmp)
         alfl = (rhorat-sum(rhoslf(1:mxbrdmol)*brd_mol_flg(:,i))) &
         &           *alfa0i + alfsum
         if(brd_mol_flg(m,i).eq.0)   &
         &           alfl = alfl + rhoslf(m)*(hwhmsi-alfa0i)
      end if

! mji - Revise code to skip broadening for incoming lines with flag = -1
      if(brd_mol_flg(m,i).eq.-1.and.ibrd.gt.0) then
            alfl = hwhmsi
         end if
      !
      IF (IFLAG.EQ.3) ALFL = ALFL*(1.0-GAMMA1*PAVP0-GAMMA2*PAVP2)
!
      ALFAD = VNU(I)*ALFD1(m,iso)
      ZETA = ALFL/(ALFL+ALFAD)
      ZETAI(I) = ZETA
      FZETA = 100.*ZETA
      IZ = FZETA + ONEPL
      IZETA(I) = IZ
      ZETDIF = FZETA - REAL(IZ-1)
      ALFV = (AVRAT(IZ)+ZETDIF*(AVRAT(IZ+1)-AVRAT(IZ)))*(ALFL+ALFAD)
      IF (ALFV.LT.DV) THEN
         ALFV = DV
         NMINAD = 1
      ELSE
         NMINAD = 0
      ENDIF
      IF (ALFV.GT.ALFMAX) THEN
         ALFV = ALFMAX
         NPLSAD = 1
      ELSE
         NPLSAD = 0
      ENDIF
!
      IF (HWF3*ALFV+VNU(I) .LT. VFT) GO TO 25
!
      RECALF(I) = 1./ALFV
!
!     TREAT TRANSITIONS WITH negative EPP AS SPECIAL CASE
!
!>>   an epp value between -0.9999 and 0.  cm-1 is taken as valid
!
!>>   an epp value of -1. is assumed set by hitran indicating an unknown
!     value: no temperature correction is performed
!
!>>   for an epp value of less than -1., it is assumed that value has
!     been provided as a reasonable value to be used for purposes of
!     temperature correction.  epp is set positive
!
      if (epp(i).le.-1.001) epp(i) = abs(epp(i))

      if (epp(i).le.-0.999) MEFDP(M) = MEFDP(M)+1

!     temperature correction:

      if (epp(i) .gt. -0.999) then
         SUI = SUI*SCOR(m,iso)* EXP(-EPP(I)*BETACR)*(1.+EXP(-VNU(I)/XKT)&
            )
      endif
!
      SP(I) = SUI*(1.+GI*PAVP2)
      SPPI = SUI*YI*PAVP0
      SPPSP(I) = SPPI/SP(I)
!
!     SPEAK is used for line rejection (no LCPL lines (sppsp ne 1) are r

      IF (IFLAG.EQ.0) THEN
         IF (ILNFLG.LE.1) THEN
            FREJ(J) = HNOREJ
            SPEAK = SUI*RECALF(I)
            IF (DVR4.LE.0.) THEN
               IF (SPEAK.LE.DPTMN) THEN
                  FREJ(J) = HREJ
                  GO TO 25
               ENDIF
            ELSE
               JJ = (VNU(I)-V1R4)/DVR4+1.
               JJ = MAX(JJ,I_1)
               JJ = MIN(JJ,NPTR4)
               IF (SPEAK.LE.(DPTMN+DPTFC*R4(JJ)) .and. sppsp(i)      &
                  .eq.0.) THEN
                  FREJ(J) = HREJ
                  GO TO 25
               ENDIF
            ENDIF
         ELSE
!      "ELSE" IS TRUE WHEN "ILNFLG" EQUALS 2
!
            IF (FREJ(J).EQ.HREJ) GO TO 25
         ENDIF
      ENDIF
!
      NMINUS = NMINUS+NMINAD
      NPLUS = NPLUS+NPLSAD
      SUMALF = SUMALF+ALFV
      SUMZET = SUMZET+ZETA
      LINCNT = LINCNT+1
!
      GO TO 30
!
25    SP(I) = 0.
      SPPSP(I) = 0.
!
30 END DO
!
   NCHNG = NMINUS+NPLUS
   IF (ILNFLG.EQ.1) WRITE(15)(FREJ(J),J=ILO,IHI)
!
   RETURN
!
end subroutine LNCOR1
