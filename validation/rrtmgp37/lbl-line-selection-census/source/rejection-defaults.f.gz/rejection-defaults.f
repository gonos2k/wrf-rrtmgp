C                THIS GIVES:  S(M) = 1.E-5/W(M)                          LN19540
C                                                                        LN19550
C                NOTE: NO PROFILES ARE CURRENTLY AVAILABLE FOR           LN19560
C                      MOLECULES 29 THROUGH 39 SO DEFAULT                LN19570
C                      REJECTIONS ARE CURRENTLY SET TO ZERO.             LN19580
C                                                                        LN19590
C                    H2O        CO2         O3        N2O         CO     LN19600
      DATA SRD / 6.667E-31, 1.873E-29, 3.817E-26, 1.984E-26, 4.785E-26,  LN19610
C                                                                        LN19620
C                    CH4         O2         NO        SO2        NO2     LN19630
     *           3.745E-27, 2.959E-32, 1.898E-23, 3.077E-23, 6.098E-23,  LN19640
C                                                                        LN19650
C                    NH3       HNO3         OH         HF        HCL     LN19660
     *           1.799E-23, 2.950E-23, 6.944E-21, 1.541E-21, 1.100E-23,  LN19670
C                                                                        LN19680
C                    HBR         HI        CLO        OCS       H2CO     LN19690
     *           3.623E-21, 2.062E-21, 3.436E-21, 1.110E-23, 7.246E-24,  LN19700
C                                                                        LN19710
C                   HOCL         N2        HCN      CH3CL       H2O2     LN19720
     *           5.650E-22, 7.937E-33, 3.802E-23, 9.804E-24, 3.731E-23,  LN19730
C                                                                        LN19740
C                   C2H2       C2H6        PH3       COF2        SF6     LN19750
     *           4.717E-23, 3.401E-24, 6.173E-13, 0.000E+00, 0.000E+00,  LN19760
C                                                                        LN19770
C                    H2S      HCOOH   
     *           0.000E+00, 0.000E+00,
C
C                   HO2, O, ClONO2, NO+,HOBr,C2H4,CH3OH
     *           32*0.0 /
C                                                                        LN19800
      DATA SR / 64*0.0 /                                                 LN19810
      DATA CHID10 / '       I'/                                          LN19820
      DATA IRD,IPR,IPU / 5,66,7 /                                        LN19830
      DATA SUMSTR / 64*0. /,MCNTLC / 64*0 /,ILINLC / 0 /,IREC / 0 /,     LN19840
     *     IRECTL / 0 /                                                  LN19850
      DATA MOLIND / 64*0 /,MIND1 / 64*0 /,MIND2 / 64*0 /                 LN19860
