      SUBROUTINE RDFIL1 (LINBCD,I1,N1,IEOF)                              LN09910
C     PLNFL Updates to read self-line coupling paramaters for CO2
C     Matt Alvarado, (malvarad@aer.com) 01-19-2012
C     
C     To inlcude self-line coupling, we want to:
C     (a) read in 3 ASCII lines for every spectral line with a "-5" line
C         coupling flag - main (HITRAN F100) line, foreign line 
C         coupling line,and self line coupling line.
C     (b) Place self-line coupling paramaters in the position, strength,
C         etc. arrays right after the foregin paramaters.
C     
C     To do this, I made these changes:
C     (a) Inceased max array and loop indices to 52 (in case block ends 
C         on the main line with a "-5" flag.
C     (b) set code to read in self-line coupling parameters if IFLAG
C         is "-5" and add them to the arrays
C                                                                        LN09920
      IMPLICIT REAL*8           (V)                                     !LN09930
C                                                                        LN09940
      COMMON /BUFID/ HID(10),HMOL(64),MOLIND(64),MCNTLC(64),MCNTNL(64),  LN09950
     *               SUMSTR(64),NMOL,FLINLO,FLINHI,ILIN,ILINLC,ILINNL,   LN09960
     *               IREC,IRECTL,HID1(2),LSTWD                           LN09970
c
      common /bufid2/ n_negepp(64),n_resetepp(64),xspace(4096),lstwd2
C                                                                        LN09980
      CHARACTER*8      HID,HID1,HMOL                                    &LN09990
      REAL*8           STRSV
C                                                                        LN10000
      COMMON /SREJ/ SR(64),SRD(64),TALF(64)                              LN10010
      COMMON /CONTRL/ VMIN,VMAX,VLO,VHI,LINES,NWDS,LSTW1                 LN10020
      COMMON /HBLOCK/ INBLK1,INBLK2,I86T1,I86T2
      COMMON /IFIL/ IRD,IPR,IPU,NWDR,LRC,ILNGTH,INLTE,IER,IPUOUT         LN10040
      COMMON /UNITS/ PI,PLANCK,BOLTZ,CLIGHT,AVOGAD,RADCN1,RADCN2           LN10050
      COMMON /IC1/ ILIN3                                                 LN10060
C      COMMON /MANE/ VNU1(51),STR1(51),ALF1(51),EPP1(51),MOL1(51),        LN10070
C     *              HWHM1(51),TMPAL1(51),PSHIF1(51),IFG1(51),            LN10080
C     *              MIND1(64),IOUT(51)                                   LN10090
C      COMMON /QUANT/ QUANT1(51),QUANTC(51)                               LN10100
C      COMMON /LCHAR/ ALIN1(51),ALIN2(40),ALINC(51),ALINE(250)            LN10110
C     MJA, 01-19-2012 new array sizes
      COMMON /MANE/ VNU1(52),STR1(52),ALF1(52),EPP1(52),MOL1(52),        LN10070
     *              HWHM1(52),TMPAL1(52),PSHIF1(52),IFG1(52),            LN10080
     *              MIND1(64),IOUT(52)                                   LN10090
      COMMON /QUANT/ QUANT1(52),QUANTC(52)                               LN10100
      COMMON /LCHAR/ ALIN1(52),ALIN2(40),ALINC(52),ALINE(250)            LN10110
c 
      parameter (mol_max=47)
c
      COMMON /ISVECT/ ISO_MAX(MOL_MAX)
      common /eppinfo/ negflag
c
      character*8 h_rdlin1
      character*1 h_alin_70,h_alin_73,h_blnk
c
      data h_rdlin1/' tape1 '/, h_blnk/' '/,
     *     h_alin_70/' '/, h_alin_73/' '/
C                                                                        LN10120
C      CHARACTER*100 ALIN1,ALIN2,ALINC,ALINE,ALIN(51)                     LN10130
C     MJA, 01-19-2012 new array sizes
      CHARACTER*100 ALIN1,ALIN2,ALINC,ALINE,ALIN(52)
      CHARACTER*50 ZEROFL                                                LN10140
      CHARACTER*27 QUANT1,QUANTC                                         LN10150
      CHARACTER*9 CUP,CLO
      CHARACTER*7 HOL                                                    LN10160
      CHARACTER*1 CFLAG,CBLNK,CMINUS,a_1,h_1,h_2,CFLAG2
      character*2 TFLAG
C      DIMENSION AMOL1(51)                                                LN10180
C     MJA, 01-19-2012 new array sizes
      DIMENSION AMOL1(52)
C                                                                        LN10190
      EQUIVALENCE (MOL1(1),AMOL1(1))                                     LN10200
C                                                                        LN10210
      DATA TEMP0 / 296. /                                                LN10220
      DATA ZEROFL /                                                      LN10230
     *           '00000000000000000000000000000000000000000000000000'/   LN10240
      DATA CBLNK / ' '/,CMINUS / '-'/, n_hdr/0/, h_1/'>'/, h_2/'%'/
C                                                                        LN10260
      BETA0 = RADCN2/TEMP0                                               LN10270
      IER = 0                                                            LN10280
      IEOF = 0                                                           LN10290
      I1 = 1                                                             LN10300
      N1 = 0                                                             LN10310
      ILIN3 = 0                                                          LN10320
C                                                                        LN10330
   10 CONTINUE                                                           LN10340
      IF (IEOF.EQ.1) GO TO 60                                            LN10350
      IEOF = 1                                                           LN10360
      IBLK = 51                                                          LN10370
      IF (INBLK1.EQ.0) THEN                                              LN10380
         READ (LINBCD,900,END=60) ALIN                                   LN10390
      ELSE                                                               LN10400
         IBLK = 50                                                       LN10410
         DO 20 I = 1, IBLK                                               LN10420
            READ (LINBCD,900,END=30) ALIN(I)                             LN10430
   20    CONTINUE                                                        LN10440
c     skip over header records:
         READ (ALIN(IBLK),913) a_1
         if (a_1.eq.h_1 .or. a_1.eq.h_2) then
             IBLK = 50
         else         


C        RLP implementing F160 Bug Fix into F100 code:
C        MJA 01-19-2012 IFLAG format code is off...
         READ (ALIN(IBLK),805) CFLAG, TFLAG
         READ (ALIN(IBLK-1),805) CFLAG2,TFLAG2

         IF (TFLAG.EQ.'-1'.OR.TFLAG.EQ.'-3'.OR.TFLAG.EQ.'-5') THEN !Line coupling
          READ (ALIN(IBLK),905) CFLAG,IFLAG               
          READ (ALIN(IBLK-1),905) CFLAG2,IFLAG2    
				  IF (IFLAG.NE.-5) THEN !Foreign line coupling only
				     IF(CFLAG.NE.CBLNK.AND.CFLAG.NE.CMINUS) THEN !Main line
					   IBLK = 51                                               
					   READ (LINBCD,900,END=30) ALIN(IBLK)  
				     ELSE !Foreign line coupling line
					   IBLK = 50    
				     ENDIF
				  ELSE !Foreign and self line coupling (IFLAG = -5)
				     IF(CFLAG.NE.CBLNK.AND.CFLAG.NE.CMINUS) THEN !Main line
					    IBLK = 52                                                 
					    READ (LINBCD,900,END=30) ALIN(IBLK-1) 
					    READ (LINBCD,900,END=30) ALIN(IBLK) 
				     ELSEIF(CFLAG2.NE.CBLNK.AND.CFLAG2.NE.CMINUS) THEN !Foreign line coupling line
					    IBLK = 51                                              
					    READ (LINBCD,900,END=30) ALIN(IBLK)        
				     ELSE !Self line coupling line
					    IBLK = 50 
				     ENDIF
				  ENDIF
			   ENDIF
		    endif
        ENDIF
C         IF (IFLAG.LT.0.AND.CFLAG.NE.CBLNK.AND.CFLAG.NE.CMINUS) THEN     LN10460
C           MJA 01-19-2012 Read 52 lines if IFLAG = -5
C            IF(IFLAG.EQ.-5) THEN
C              IBLK = 52                                                 
C              READ (LINBCD,900,END=30) ALIN(IBLK-1) 
C              READ (LINBCD,900,END=30) ALIN(IBLK) 
C            ELSE
C              IBLK = 51                                                  LN10470
C              READ (LINBCD,900,END=30) ALIN(IBLK)                        LN10480
C            ENDIF
C         ENDIF                                                           LN10490
C      ENDIF                                                              LN10500
C                                                                        LN10510
C      do I = 1, IBLK
C        write(*,*) I, ALIN(I)
C      enddo
      IEOF = 0                                                           LN10520
      GO TO 40                                                           LN10530
   30 IBLK = I-1                                                         LN10540

      IF (IBLK.LE.0) GO TO 60                                            LN10550
   40 IFLGM1 = 0                                                         LN10560
C      MJA 01-19-2012 Self line coupling fix
C      DO 50 I = 1, 51                                                    LN10570
      DO 50 I = 1, 52                                                    LN10570
C         WRITE(*,*) I, IFLGM1
         IF (I.GT.IBLK) WRITE (ALIN(I),910) ZEROFL,ZEROFL                LN10580
c
c     skip over header records:
         READ (ALIN(I),913) a_1
         if (a_1.eq.h_1 .or. a_1.eq.h_2) then
            n_hdr = n_hdr+1
            if (n_hdr.eq. 1) Write (*,914)     
            if (ipuout.eq.1) Write(ipu,902) alin(i)
 902        format (a100) 
            go to 50
         endif
c
c     test for invalid molecule number:
         READ (ALIN(I),915) MOL                                          LN10590
         IF (MOL.le.0) GO TO 50                                          LN10600
         M = MOL                                                         LN10610
         IF (MIND1(M).EQ.0) GO TO 50                                     LN10620

C        MJA, 01-19-2012
C        IF IFLGM1 <= 0, main HITRAN F100 line, read normally
C        ELSE IF IFLGM1 = 5, both foreign and self line coupling (new!)
C        ELSE (IFLGM1 = 1 or 3) just read foreign line coupling
C         WRITE(*,*) IFLGM1
         IF (IFLGM1.LE.0) THEN                                           LN10630
c
c     check vibrational data 


            read (alin(i),918) h_alin_70, h_alin_73   
 918        format(69x,a1,2x,a1)
            if (h_alin_70.eq.h_blnk .or. h_alin_73.eq.h_blnk) then
               write (*,919) 
 919           format
     *             ('***  vibrational quantum numbers invalid  ***',/,
     *              '***  check format specification of TAPE1  ***')
               stop '***        invalid TAPE1                  ***'
            endif
C           MJA 01-23-2012 debugging 
C            write(*,*) alin(I), IFLGM1

            READ (ALIN(I),920) ISO,VNU,STRSV,TRANS,HWHMF,HWHMS,ENERGY,   LN10640
     *                         TDEP,SHIFT,IVUP,IVLO,CUP,CLO,HOL,IFLGSV   LN10650
            IFLAG = IFLGSV                                               LN10660
C          write(*,*)  IFLAG, IFLGSV  
c
c     check that molecule and isotope are within proper range
c
            if (m   .lt. 1) then
                write(*,*) ALIN(I) 
                stop ' molecule value is less than 1 '
            endif
            if (iso .lt. 0) then
                write(*,*) ALIN(I) 
                stop '  isotope value is less than 0 '
            endif
c
c   the TIPS program in lblrtm is currently limited to molecules up to 38
c
c   However, partition sum temperature dependence for molecule 39 (c3hoh)
c   is being handled by using the analytical expression
c
            if (m .gt. nmol) then
               call line_exception (1,ipr,h_rdlin1,m,nmol,iso,iso_max)
               go to 50
            else if (iso .gt. iso_max(m)) then
               call line_exception (2,ipr,h_rdlin1,m,nmol,iso,iso_max)
               go to 50
            endif
c
            MOL = MOL+100*ISO                                            LN10670
C           MJA 01-19-2012
C           If line coupling (IFLAG < 0) take absolute value of IFLAG
C           and place in IFLAGM1
            IF (IFLAG.LT.0) THEN                                         LN10680
               IFLAG = IABS(IFLAG)                                       LN10690
            ELSE                                                         LN10700
               IFLAG = 0                                                 LN10710
            ENDIF                                                        LN10720
            IFLGM1 = IFLAG
            VNUS = VNU                                                   LN10730
C            write(*,*) IFLGM1
C
C           SKIP OVER UNEEDED WAVENUMBERS
C
            IF (VNUS.LT.VMIN) GO TO 50                                   LN12380
            IF (VNUS.GT.VMAX) RETURN                                     LN12390
C
            STR = STRSV/(VNU*(1.0-EXP(-BETA0*VNU)))                      LN10760
            IF (STR.LT.SR(M)) GO TO 50                                   LN10770
            IF (INLTE.EQ.1) CALL VIBQ1 (MOL,IVUP,IVLO)                   LN10780
            ILIN3 = ILIN3+1                                              LN10790
            ILINS = ILIN3                                                LN10795
            WRITE (QUANT1(ILIN3),930) M,ISO,IVUP,IVLO,CUP,CLO            LN10800
C                                                                        LN10810
C           NOTE: SHIFT VARIABLE MAY CONTAIN COUPLING INFORMATION        LN10820
C            - NO PRESSURE SHIFT INFORMATION CURRENTLY PROVIDED,         LN10830
C                  AND COUPLING INFORMATION DELETED -                    LN10840
C                                                                        LN10850
            IF (I86T1.EQ.1) SHIFT = 0.                                   LN10860
C                                                                        LN10870
C           HWHMS = 0. IN HITRAN 86.  CHECK FOR ZERO; IF ZERO            LN10880
C           AND NOT WATER, SET TO HWHMF.  IF WATER, SET TO 5. * HWHMF    LN10890
C                                                                        LN10900
            IF (HWHMS.EQ.0.) THEN                                        LN10910
               HWHMS = HWHMF                                             LN10920
               IF (M.EQ.1) HWHMS = 5.*HWHMF                              LN10930
            ENDIF                                                        LN10940
c
            if (hwhms.le.0.9999)  then
               WRITE (ALIN1(ILIN3),921) M,ISO,VNU,STRSV,TRANS,HWHMF,        LN10950
     *                              HWHMS,ENERGY,TDEP,SHIFT,IVUP,        LN10960
     *                              IVLO,CUP,CLO,HOL,IFLGSV              LN10970
            else
               WRITE (ALIN1(ILIN3),922) M,ISO,VNU,STRSV,TRANS,HWHMF,        LN10950
     *                              HWHMS,ENERGY,TDEP,SHIFT,IVUP,        LN10960
     *                              IVLO,CUP,CLO,HOL,IFLGSV              LN10970
            endif
c
            VNU1(ILIN3)   = VNU                                          LN10980
            STR1(ILIN3)   = STR                                          LN10990
            ALF1(ILIN3)   = HWHMF                                        LN11000
            EPP1(ILIN3)   = ENERGY                                       LN11010
            MOL1(ILIN3)   = MOL                                          LN11020
            HWHM1(ILIN3)  = HWHMS                                        LN11025
            TMPAL1(ILIN3) = 1.-TDEP                                      LN11030
            PSHIF1(ILIN3) = SHIFT                                        LN11040
            IFG1(ILIN3)   = IFLAG                                        LN11060
            N1 = N1+1                                                    LN11070
C
C           SET FLAG FOR O2 0.0 CM-1 BAND CASE
C
            IOUT(N1) = ILINS                                             LN11090

C            write(*,*) IFLGM1

C        MJA, 01-19-2012
C        New case for IFLAG = "-5" in TAPE1 to read foreign and self
C        line coupling coefficients
         ELSEIF (IFLGM1.EQ.5) THEN                                      
C         write(*,*) "Foreign and self"
C
C           FOREIGN LINE COUPLING INFORMATION READ IN
C
            READ (ALIN(I),925) Y1,G1,Y2,G2,Y3,G3,Y4,G4,IFLAG             
C
C
C           SKIP OVER UNEEDED WAVENUMBERS
C
            IF (VNUS.LT.VMIN) GO TO 50
            ILIN3 = ILIN3 + 1                                            
            ALIN1(ILIN3)  = ALIN(I)                                      
            VNU1(ILIN3)   = Y1                                           
            STR1(ILIN3)   = G1                                           
            ALF1(ILIN3)   = Y2                                           
            EPP1(ILIN3)   = G2                                           
            AMOL1(ILIN3)  = Y3                                           
            HWHM1(ILIN3)  = G3                                           
            TMPAL1(ILIN3) = Y4                                           
            PSHIF1(ILIN3) = G4                                           
            IFG1(ILIN3)   = IFLAG                                        

C           SET IFLGM1 TO ONE TO ENSURE THE NEXT PASS READS THE 
C           SELF LINE COUPLING INFORMATION USING the else
C           statement below (MJA, 01-20-2012)
C
            IFLGM1 = 1                                                   LN11120

         ELSE                                                            LN11100
C
C           LINE COUPLING INFORMATION READ IN
C
            READ (ALIN(I),925) Y1,G1,Y2,G2,Y3,G3,Y4,G4,IFLAG             LN11110
C
C           SET IFLGM1 TO ZERO TO ENSURE THE NEXT PASS USES 
C           REGULAR FORMAT FOR READING LINE INFORMATION
C
            IFLGM1 = 0                                                   LN11120
C
C           SKIP STRENGTH REJECTED COUPLED LINES (MJA, 11-16-2010)
C
C            WRITE(*,*) STR
            IF (STR.LT.SR(M)) GO TO 50                                   LN10770

C           SKIP OVER UNEEDED WAVENUMBERS
C
            IF (VNUS.LT.VMIN) GO TO 50
            ILIN3 = ILIN3 + 1                                            LN11130
            ALIN1(ILIN3)  = ALIN(I)                                      LN11140
            VNU1(ILIN3)   = Y1                                           LN11150
            STR1(ILIN3)   = G1                                           LN11160
            ALF1(ILIN3)   = Y2                                           LN11170
            EPP1(ILIN3)   = G2                                           LN11180
            AMOL1(ILIN3)  = Y3                                           LN11190
            HWHM1(ILIN3)  = G3                                           LN11200
            TMPAL1(ILIN3) = Y4                                           LN11210
            PSHIF1(ILIN3) = G4                                           LN11220
            IFG1(ILIN3)   = IFLAG                                        LN11230
         ENDIF                                                           LN11240
C
   50 CONTINUE                                                           LN11250
C                                                                        LN11260
      IF (ILIN3.LT.1.AND.IBLK.LT.50) GO TO 60                            LN11290
      IF (ILIN3.LT.1) GO TO 10                                           LN11300
C                                                                        LN11310
      RETURN                                                             LN11320
C                                                                        LN11330
   60 CONTINUE                                                           LN11340
C                                                                        LN11350
      PRINT 940                                                          LN11360

      RETURN                                                             LN11410
C                                                                        LN11420
C 900  FORMAT (51(A100))                                                  LN11430
C MJA 01-19-2012 Increase array sizes for self line coupling
 900  FORMAT (52(A100))
 905  FORMAT (2X,A1,95X,I2)                                              LN11440
 805  FORMAT (2X,A1,95X,A2) 
 910  FORMAT (2A50)                                                      LN11450
 913  format (a1)
 914  format ( ' skipping over header records on TAPE1')
 915  FORMAT (I2)                                                        LN11460
 920  FORMAT (2X,I1,F12.6,D10.3,E10.3,2F5.4,F10.4,F4.2,F8.6,2I3,2A9,
     *        A7,I2)                                                     LN11470
 921  FORMAT (I2,I1,F12.6,1P,D10.3,E10.3,0P,2F5.4,F10.4,F4.2,F8.6,2I3,
     *        2A9,A7,I2)
 922  FORMAT (I2,I1,F12.6,1P,D10.3,E10.3,0P,2F5.3,F10.4,F4.2,F8.6,2I3,
     *        2A9,A7,I2)
 925  FORMAT (2X,4(E13.6,E11.4),I2)                                      LN11480
 930  FORMAT (I2,I1,2I3,2A9)                                             LN11490
 940  FORMAT (' TAPE1 IS AT A EOF ')
C                                                                        LN11550
      END                                                                LN11560
      SUBROUTINE RDFIL2 (LINBCD,I2,N2,IEOF)                              LN11570
C     PLNFL Updates to read self-line coupling paramaters for CO2
C     Matt Alvarado, (malvarad@aer.com) 01-19-2012
C     
C     To inlcude self-line coupling, we want to:
