      SUBROUTINE MOVE (LINMRG,I,VNU2,STR2,ALF2,EPP2,MOL2,AMOL2,HWHM2,    LN08580
     *                 TMPAL2,PSHIF2,IFG2,MOLCNT,ALIN2)                  LN08590
C                                                                        LN08600
      IMPLICIT REAL*8           (V)                                     !LN08610
C                                                                        LN08620
      COMMON /BUFID/ HID(10),HMOL(64),MOLIND(64),MCNTLC(64),MCNTNL(64),  LN08630
     *               SUMSTR(64),NMOL,FLINLO,FLINHI,ILIN,ILINLC,ILINNL,   LN08640
     *               IREC,IRECTL,HID1(2),LSTWD                           LN08650

      common /bufid2/ n_negepp(64),n_resetepp(64),xspace(4096),lstwd2
      common /eppinfo/ negflag

      COMMON VNU3(250),STR3(250),ALF3(250),EPP3(250),MOL3(250),          LN08660
     *       HWHMS(250),TMPALF(250),PSHIFT(250),IFLG(250),
     *       ADDFLAG(7,250),ADDDATA(21,250),SDEP_DATA(250),LSTW3
      REAL*4 ADDDATA
      INTEGER*4 ADDFLAG
C                                                                        LN08680
      CHARACTER*8      HID,HID1,HMOL                                    &LN08690
C                                                                        LN08700
      DIMENSION VNU2(*),STR2(*),ALF2(*),EPP2(*),MOL2(*),AMOL2(*),        LN08710
     *          HWHM2(*),TMPAL2(*),PSHIF2(*),IFG2(*),ALIN2(*)            LN08720
      DIMENSION MOLCNT(*)                                                LN08730
      COMMON /ICN/ ILIN3,NMAX,NBLOCK,inocpl
      COMMON /CONTRL/ VMIN,VMAX,VLO,VHI,LINES,NWDS,LSTW1                 LN08750
C     MJA, 01-19-2012 Increase array sizes for self-line coupling
C      COMMON /LCHAR/ ALIN1(51),ALINE(40),ALINC(51),ALIN(250)             LN08760
      COMMON /LCHAR/ ALIN1(52),ALINE(40),ALINC(52),ALIN(250)             LN08760
C                                                                        LN08770
      CHARACTER*100 ALIN1,ALIN2,ALINC,ALIN,ALINE                         LN08780
      DIMENSION AMOL3(250)                                               LN08790
C                                                                        LN08800
      EQUIVALENCE (AMOL3(1),MOL3(1))                                     LN08810
C                                                                        LN08820
      M = MOD(MOL2(I),100)                                               LN08830
      ILIN3 = ILIN3+1                                                    LN08840
      NWDS = NWDS+9                                                      LN08850
      VNU3(ILIN3) = VNU2(I)                                              LN08860
      STR3(ILIN3) = STR2(I)                                              LN08870
      ALF3(ILIN3) = ALF2(I)                                              LN08880
      EPP3(ILIN3) = EPP2(I)                                              LN08890
      MOL3(ILIN3) = MOL2(I)                                              LN08900
      HWHMS(ILIN3) = HWHM2(I)                                            LN08910
      TMPALF(ILIN3) = TMPAL2(I)                                          LN08920
      PSHIFT(ILIN3) = PSHIF2(I)                                          LN08930
      if (inocpl .eq.1 ) ifg2(i) = 0
      IFLG(ILIN3) = IFG2(I)                                              LN08940
      ALIN(ILIN3) = ALIN2(I)                                             LN08950
      ILIN = ILIN+1                                                      LN08960
      SUMSTR(M) = SUMSTR(M)+STR2(I)                                      LN08970
      MOLCNT(M) = MOLCNT(M)+1                                            LN08980

c     Check for negative ENERGY values
c     If ENERGY = -1., then set ENERGY to 300.
c     If ENERGY = -n, then set ENERGY to n

      if (iflg(ilin3).eq.0 .and. epp3(ilin3) .lt. -0.99) then
         negflag = 1
         n_negepp(m) = n_negepp(m)+1
      endif

      IF (IFG2(I).GE.1) THEN                                             LN08990
         NWDS = NWDS+9                                                   LN09000
         ILIN3 = ILIN3+1                                                 LN09010
         VNU3(ILIN3) = VNU2(I+1)                                         LN09020
         STR3(ILIN3) = STR2(I+1)                                         LN09030
         ALF3(ILIN3) = ALF2(I+1)                                         LN09040
         EPP3(ILIN3) = EPP2(I+1)                                         LN09050
         AMOL3(ILIN3) = AMOL2(I+1)                                       LN09060
         HWHMS(ILIN3) = HWHM2(I+1)                                       LN09070
         TMPALF(ILIN3) = TMPAL2(I+1)                                     LN09080
         PSHIFT(ILIN3) = PSHIF2(I+1)                                     LN09090
         IFLG(ILIN3) = IFG2(I+1)                                         LN09100
         ALIN(ILIN3) = ALIN2(I+1)                                        LN09110
         MCNTLC(M) = MCNTLC(M)+1                                         LN09120
         ILINLC = ILINLC+1                                               LN09130
      ENDIF                                                              LN09140
C     MJA 01-19-2012 Allow 5 flag to do self-line coupling
      IF (IFG2(I).EQ.5) THEN                                             
         NWDS = NWDS+9                                                   
         ILIN3 = ILIN3+1                                                 
         VNU3(ILIN3) = VNU2(I+2)                                         
         STR3(ILIN3) = STR2(I+2)                                         
         ALF3(ILIN3) = ALF2(I+2)                                         
         EPP3(ILIN3) = EPP2(I+2)                                         
         AMOL3(ILIN3) = AMOL2(I+2)                                       
         HWHMS(ILIN3) = HWHM2(I+2)                                       
         TMPALF(ILIN3) = TMPAL2(I+2)                                     
         PSHIFT(ILIN3) = PSHIF2(I+2)                                     
         IFLG(ILIN3) = IFG2(I+2)                                         
         ALIN(ILIN3) = ALIN2(I+2)                                        
C         MCNTLC(M) = MCNTLC(M)+1   Don't double count coupled lines MJA                                
         ILINLC = ILINLC+1                                               
      ENDIF                                                              
c
      MIS = MOD(MOL2(I),1000)                                            LN09143
      IF (MIS.NE.MOL2(I)) THEN                                           LN09146
         MCNTNL(M) = MCNTNL(M)+1                                         LN09150
         ILINNL = ILINNL+1                                               LN09160
      ENDIF                                                              LN09165
C      IF (ILIN3.GE.NMAX-1) CALL BLKOUT (LINMRG)                          LN09170
C     MJA 01-23-2012 Account for self line coupling in NMAX
C      IF (ILIN3.GE.NMAX-2) WRITE(*,*) "IN MOVE"
      IF (ILIN3.GE.NMAX-2) CALL BLKOUT (LINMRG) 
C                                                                        LN09180
