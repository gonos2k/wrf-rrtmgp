from pathlib import Path
import json,gzip,hashlib,shutil,netCDF4,numpy as np,subprocess
r=Path.cwd();b=r/'validation/rrtmgp37/research-radiation-integration';host=r.parent/'udm37-radiation-options-host-v3';build=r.parent/'udm37-radiation-options-build-v1'
sha=lambda x:hashlib.sha256(x).hexdigest()
def save(n,x):
 p=b/'saved'/(n+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(x,mtime=0))
def file(n,p):save(n,Path(p).read_bytes())
def js(n,x):save(n,(json.dumps(x,indent=2)+'\n').encode())
def packet(n,path,checkpoint=False):
 data=bytearray();rows=[]
 with netCDF4.Dataset(path) as d:
  attrs={n:int(d.getncattr(n)) for n in ['UDM_NUMBER_POLICY','UDM_POPULATION_POLICY','RRTMGP_CAPACITY_POLICY','RRTMGP_LIQUID_SIZE_POLICY']}
  for name,v in d.variables.items():
   if 'Time' not in v.dimensions:continue
   a=np.asarray(v[:]);x=a.tobytes();rows.append({'variable':name,'dtype':a.dtype.str,'shape':list(a.shape),'offset':len(data),'bytes':len(x),'sha256':sha(x),'units':getattr(v,'units','')});data.extend(x)
 js('host/'+n+'.json',{'source_NetCDF_sha256':sha(Path(path).read_bytes()),'attrs':attrs,'records':rows,'payload_sha256':sha(data)});save('host/'+n+'.bin',data)
rec=json.loads((host/'receipt.json').read_text())
for p in host.glob('command-*'):file('host/'+p.name,p)
file('host/receipt.json',host/'receipt.json')
inputs={}
for d in sorted(host.iterdir()):
 if not d.is_dir():continue
 name=d.name;file('host/'+name+'.namelist.input',d/'namelist.input');file('input/'+name+'.nc',d/'wrfinput_d01')
 with netCDF4.Dataset(d/'wrfinput_d01') as nc:
  inputs[name]={'file_sha256':sha((d/'wrfinput_d01').read_bytes()),'physical_arrays':{n:sha(np.asarray(v[:]).tobytes()) for n,v in nc.variables.items()},'attrs':{n:int(nc.getncattr(n)) if n in nc.ncattrs() and isinstance(nc.getncattr(n),(int,np.integer)) else (str(nc.getncattr(n)) if n in nc.ncattrs() else None) for n in ['RRTMGP_CAPACITY_POLICY','RRTMGP_LIQUID_SIZE_POLICY']}}
 for p in (d/'capture').iterdir():file('host/'+name+'/capture/'+p.name,p)
 if (d/'audit/same_state.csv').exists():file('host/'+name+'/audit/same_state.csv',d/'audit/same_state.csv')
 if list(d.glob('wrfout*')):packet(name,next(d.glob('wrfout*')))
 if name=='held_11':packet('checkpoint20',d/'wrfrst_d01_1999-10-22_19:00:20',True)
js('input/identity.json',inputs)
for n in ['configure.log','configure-final.log','build.log','build-final.log','build-integrated.log','build-release.log','build-pinned.log','build-diagnostic-forwarding.log','campaign.log','campaign-final.log','campaign-release.log']:
 if (build/n).exists():file('build/'+n,build/n)
for n in ['CMakeCache.txt','CMakeFiles/WRF_Core.dir/flags.make','main/CMakeFiles/wrf.dir/link.txt']:
 file('build/'+n,build/'producer'/n)
# Keep prior failed initialization as a failed attempt, outside qualified results.
for p in (r.parent/'udm37-radiation-options-host-v1').glob('command-*'):file('attempts/initial-endian/'+p.name,p)
file('attempts/initial-endian/receipt.json',r.parent/'udm37-radiation-options-host-v1/receipt.json')
file('recipe/pack.py',__file__)
file('recipe/finish_harness.py','/tmp/finish_radiation_options_suite.py')
file('attempts/harness-before-correction.json',r.parent/'udm37-radiation-options-host-v2/harness-before-correction.json')
file('attempts/prior-build-qualified-receipt.json',r.parent/'udm37-radiation-options-host-v2/receipt.json')
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();sources=[n for n in changed if n.startswith('WRF/') and n.endswith(('.F','.F90','.EM_COMMON'))]
sources+=['WRF/phys/module_mp_udm.F','WRF/share/module_model_constants.F']
for n in sources:file('source/'+n,r/n)
file('source/config/registration37.json',r/'config/registration37.json')
# Reuse exact retained LUT exports, with original coefficient SHAs in those records.
for ph in ['lw','sw']:
 p=r/f'validation/rrtmgp37/native-radiation-capacity/saved/coefficients/{ph}.json.gz';save('coefficients/'+ph+'.json',gzip.decompress(p.read_bytes()))
files={n:sha((r/n).read_bytes()) for n in sources}
ident={'base_main':'3485400c30b54c853787a4a4f9d54a3baea90424','base_tree':'09be7f16a821e6fbd4cf807e42db59ba223cbe18','production_source_changed':True,'defaults':[0,0],'production_accepted':False,'science_gates_closed':False,'source_files':files,'qualified_WRF_processes':len(rec['processes']),'new_standalone_UDM_RTE_Mie_ideal_runs':0,'execution':rec['executable'],'model_scope':'serial single periodic domain, all-warm, number1 population2 theta_m1; conditional research integration only','build_failures':'Two initial compile attempts had a stale module interface while source editing. One initialization failed before radiation due to missing big-endian build flags; retained separately. Final full normal build uses pinned prior flags.','prior_PR179_arrays_equal':{k:rec[k] for k in ['historical_arrays_equal','capacity_prior_arrays_equal','omitted_defaults_prior_arrays_equal','audit_passivity_arrays_equal']},'libraries':[]}
import shlex
for x in shlex.split((build/'producer/main/CMakeFiles/wrf.dir/link.txt').read_text()):
 if x.endswith('.a'):
  p=Path(x) if x.startswith('/') else (build/'producer/main'/x).resolve()
  if p.exists():ident['libraries'].append({'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
(b/'identity.json').write_text(json.dumps(ident,indent=2)+'\n')
print('PACKED',len(rec['processes']))
