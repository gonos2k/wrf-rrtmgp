from pathlib import Path
import json,shutil,os,importlib.util,numpy as np,netCDF4
r=Path.cwd();b=r.parent/'udm37-radiation-options-host-v2'
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
h=load(r/'WRF/test/rrtmgp/test_netcdf_zz.py','runner');setup=load(r/'WRF/test/rrtmgp/test_udm_startup_snow_scm.py','setup')
rec=json.loads((b/'receipt.json').read_text());shutil.copy2(b/'receipt.json',b/'harness-before-correction.json')
text=(b/'command-12.stdout').read_text();assert 'Malformed RRTMGP research metadata' in text and 'SUCCESS COMPLETE WRF' not in text and not list((b/'bad_tag').glob('wrfout*'))
d=b/'unsupported_theta';d.mkdir()
for p in (b/'bad_tag').iterdir():
 if p.is_file() and p.name not in ('namelist.output',):shutil.copy2(p,d/p.name)
(d/'capture').mkdir()
with netCDF4.Dataset(d/'wrfinput_d01','r+') as nc:nc.setncattr('RRTMGP_CAPACITY_POLICY',np.int32(1))
(d/'namelist.input').write_text(setup.set_assignment((d/'namelist.input').read_text(),'use_theta_m','0',group='dynamics'))
env=dict(os.environ,OMP_NUM_THREADS='1',WRF_RRTMGP_BATCH_SIZE='1',WRF_RRTMGP_CAPTURE_CALL='1',WRF_RRTMGP_CAPTURE_DIR=str(d/'capture'))
runner=h.Runner(b,180,env,16);runner.commands=rec['processes'];runner.attempts=len(runner.commands)
p=runner.run([rec['executable']['path']],d,'unsupported_theta');text=p.read_text();assert 'RRTMGP research policies require' in text and 'SUCCESS COMPLETE WRF' not in text and not list(d.glob('wrfout*'))
rec['processes']=runner.commands;rec['status']='PASS_SCOPED_INTEGRATED_RESEARCH';rec.pop('error',None);rec['harness_correction']='Bad string metadata was correctly rejected as malformed. Original harness expected generic policy mismatch. Checked retained rejection and continued with final unsupported-theta case; no prior scientific run repeated.'
h.write_json(b/'receipt.json',rec);print('COMPLETE',len(runner.commands))
