from pathlib import Path
import os,json,importlib.util,netCDF4,numpy as np,math
r=Path.cwd();b=r.parent/'udm37-cf0-liquid-optics-v3';b.mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
v=load(r/'validation/rrtmgp37/radiation-occurrence-runtime/verify_saved.py','v');h=load(r/'WRF/test/rrtmgp/test_netcdf_zz.py','h');runner=h.Runner(b,60,{**os.environ,'LD_LIBRARY_PATH':str(r.parent/'deps/netcdf/lib')},2);rows=[]
for ph in ('lw','sw'):
 d=b/ph;d.mkdir();head,a=v.trace((r.parent/f'udm37-cf0-psd-optics-v6/{ph}-native/input').read_bytes(),'input');nl=head[2];k=next(i for i,f in enumerate(a['CF']['values']) if f==0. and a['UNIFORM_RWP']['values'][i]>0.);assert a['CF']['values'][k]==0.;a['REL']['values'][k]=10.;a['UNIFORM_LWP']['values'][k]=.2
 text='RRTMGP_REPLAY_V12\n'+' '.join(map(str,head))+'\n'
 for name,row in a.items():text+=name+' '+' '.join(map(str,row['shape']))+'\n'+''.join(f'{z:.17e}\n' for z in row['values'])
 (d/'input').write_text(text);(d/'capture').mkdir();runner.environment['WRF_RRTMGP_CAPTURE_DIR']=str(d/'capture');runner.run([r.parent/'udm37-cf0-psd-optics-v4/build/column',r/'WRF/run',d/'input'],d,'RTE_CF0_liquid_'+ph)
 _,cur=v.trace((d/'capture'/f'{ph}.result').read_bytes(),'result');_,old=v.trace((r.parent/f'udm37-cf0-psd-optics-v6/{ph}-native/capture/{ph}.result').read_bytes(),'result')
 with netCDF4.Dataset(r/f'WRF/run/rrtmgp-clouds-{ph}-bnd.nc') as x:
  grid=np.linspace(float(x['radliq_lwr'][:]),float(x['radliq_upr'][:]),x['extliq'].shape[-1]);ext=[float(np.interp(10.,grid,z)) for z in x['extliq'][:]];ssa=[float(np.interp(10.,grid,z)) for z in x['ssaliq'][:]];asy=[float(np.interp(10.,grid,z)) for z in x['asyliq'][:]]
 with netCDF4.Dataset(r/f'WRF/run/rrtmgp-gas-{ph}-g{128 if ph=="lw" else 112}.nc') as x:limits=x['bnd_limits_gpt'][:]
 checks=[]
 for ib,(lo,hi) in enumerate(limits):
  expected=.2*ext[ib]*((1-ssa[ib]) if ph=='lw' else (1-ssa[ib]*asy[ib]**2))
  for g in range(int(lo)-1,int(hi)):
   ix=k+nl*ib;delta=cur['UNIFORM_CF0_TAU']['values'][ix]-old['UNIFORM_CF0_TAU']['values'][ix];assert math.isclose(delta,expected,rel_tol=8e-6,abs_tol=2e-8),(ph,ib,delta,expected);gi=k+nl*g;assert math.isclose(cur['TOTAL_TAU']['values'][gi]-old['TOTAL_TAU']['values'][gi],expected,rel_tol=8e-6,abs_tol=2e-8);checks.append({'gpoint':g+1,'band':ib+1,'observed_tau_increment':delta,'coefficient_formula_tau_increment':expected})
 assert cur['MASK']==old['MASK'];rows.append({'phase':ph,'native_level':k+1,'explicit_added_uniform_lwp_g_m2':.2,'explicit_radius_um':10.,'cloud_CF_and_existing_mask_unchanged':True,'checks':checks})
h.write_json(b/'result.json',{'status':'PASS_EXPLICIT_CF0_LIQUID_SCALING','manufactured_optical_probe_not_actual_added_liquid':True,'checks':rows,'processes':runner.commands,'production_accepted':False})
print('LW absorption and SW once-scaled extinction checked at all gpoints')
