PROGRAM rrtmgp_reference_column
  USE, INTRINSIC :: iso_fortran_env, ONLY: real64,iostat_end
  USE mo_rte_kind, ONLY: wp,i8
  USE, INTRINSIC :: ieee_arithmetic, ONLY: ieee_is_finite
  USE mo_gas_concentrations, ONLY: ty_gas_concs
  USE mo_gas_optics_rrtmgp, ONLY: ty_gas_optics_rrtmgp,get_col_dry
  USE mo_cloud_optics_rrtmgp, ONLY: ty_cloud_optics_rrtmgp
  USE mo_optical_props, ONLY: ty_optical_props_1scl,ty_optical_props_2str
  USE mo_source_functions, ONLY: ty_source_func_lw
  USE mo_fluxes, ONLY: ty_fluxes_broadband
  USE mo_fluxes_byband, ONLY: ty_fluxes_byband
  USE mo_rte_lw, ONLY: rte_lw
  USE mo_rte_sw, ONLY: rte_sw
  USE mo_heating_rates, ONLY: compute_heating_rate
  USE mo_gas_optics_constants, ONLY: init_constants,avogad,m_dry
  USE mo_cloud_sampling, ONLY: draw_samples
  USE mo_load_coefficients, ONLY: load_and_init
  USE mo_load_cloud_coefficients, ONLY: load_cld_lutcoeff
  USE module_ra_rrtmgp_hash, ONLY: rrtmgp_file_sha256
  USE module_ra_rrtmgp_frozen, ONLY: initialize_frozen=>initialize, query_sw, query_lw, &
                                    frozen_table_sha256, FROZEN_GRAUPEL, FROZEN_HAIL
  IMPLICIT NONE

  CHARACTER(LEN=512) :: data_dir,input_path,output_path,override_path,audit_sidecar_path
  CHARACTER(LEN=1024) :: frozen_table_env,frozen_message
  CHARACTER(LEN=64) :: frozen_sha_recorded,frozen_sha_raw
  CHARACTER(LEN=32) :: magic,phase,policy_arg,next_section
  CHARACTER(LEN=32) :: lw_transport_arg,n2_override_arg
  INTEGER :: nc,nl,overlap,seed,iceflag,u_in,u_out,ios,nemis,sw_policy
  INTEGER :: lw_transport_policy,arg_status
  INTEGER :: audit_native_n,audit_sidecar_species,audit_expected_native
  INTEGER :: c,k,g,b,i,ngpt,nbnd,n_native,frozen_status,env_status
  INTEGER :: override_ncol,override_nlay,override_nband,override_unit,override_ios
  REAL(wp) :: solar,roughness_value,partition_value,precip_mode,visible_weight,raw_direct_tau,audit_occurrence
  REAL(wp) :: frozen_mode_value,frozen_occurrence
  REAL(wp) :: metadata_gravity,metadata_cp_dry,metadata_mol_weight_dry
  LOGICAL :: use_precip,has_native_mass,frozen_enabled,sw_direct_enabled,cu_population_enabled,cu_active
  LOGICAL :: audit_sidecar_present,audit_precip_active
  LOGICAL :: lw_transport_requested
  LOGICAL :: n2_override_requested
  REAL(wp) :: cu_policy_value
  REAL(wp) :: n2_override_vmr
  INTEGER :: ice_roughness
  REAL(wp), ALLOCATABLE :: play(:,:),plev(:,:),tlay(:,:),tlev(:,:),tsfc(:,:)
  REAL(wp), ALLOCATABLE :: h2o(:,:),co2(:,:),o3(:,:),n2o(:,:),ch4(:,:),o2(:,:)
  REAL(wp), ALLOCATABLE :: vmr_cfc11(:,:),vmr_cfc12(:,:),vmr_cfc22(:,:),vmr_ccl4(:,:)
  REAL(wp), ALLOCATABLE :: vmr_n2(:,:)
  REAL(wp), ALLOCATABLE :: col_dry(:,:),native_dry_mass(:,:)
  REAL(wp), ALLOCATABLE :: gwp(:,:),hwp(:,:),lambda_g(:,:),lambda_h(:,:),frozen_hash_bytes(:,:)
  REAL(real64), ALLOCATABLE :: frozen_gt(:,:,:),frozen_ht(:,:,:),frozen_gw(:,:,:),frozen_hw(:,:,:)
  REAL(real64), ALLOCATABLE :: frozen_gmg(:,:,:),frozen_hmg(:,:,:)
  REAL(wp), ALLOCATABLE :: frozen_tau(:,:,:),frozen_ssa(:,:,:),frozen_g(:,:,:)
  REAL(wp), ALLOCATABLE :: emis_in(:,:),cf(:,:),lwp(:,:),iwp(:,:),swp(:,:)
  REAL(wp), ALLOCATABLE :: cu_lwp(:,:),cu_iwp(:,:),cu_rel(:,:),cu_rei(:,:)
  REAL(wp), ALLOCATABLE :: native_cu_tau(:,:,:),native_cu_ssa(:,:,:),native_cu_g(:,:,:)
  REAL(wp), ALLOCATABLE :: cu_tau(:,:,:),cu_ssa(:,:,:),cu_g(:,:,:),cu_rl_used(:,:),cu_di_used(:,:)
  REAL(wp), ALLOCATABLE :: rel(:,:),rei(:,:),res(:,:),avdir_in(:,:),avdif_in(:,:)
  REAL(wp), ALLOCATABLE :: andir_in(:,:),andif_in(:,:),mu0_in(:,:)
  REAL(wp), ALLOCATABLE :: emissivity(:,:),avdir(:),avdif(:),andir(:),andif(:),mu0(:),albdir(:,:),albdif(:,:)
  REAL(wp), ALLOCATABLE :: zero(:,:),rl(:,:),di(:,:),ds(:,:),toa(:,:)
  REAL(wp), ALLOCATABLE :: gas_tau(:,:,:),gas_ssa(:,:,:),gas_g(:,:,:)
  REAL(wp), ALLOCATABLE :: rwp(:,:),precip_tau(:,:,:),precip_ssa(:,:,:),precip_g(:,:,:)
  REAL(wp), ALLOCATABLE :: audit_rwp(:,:),audit_swp(:,:),audit_tau(:,:,:),audit_ssa(:,:,:),audit_g(:,:,:)
  REAL(wp), ALLOCATABLE :: audit_tau_raw(:,:,:),audit_direct(:,:),audit_direct_gpt(:,:,:)
  REAL(wp), ALLOCATABLE :: mask_values(:,:,:)
  REAL(wp), ALLOCATABLE :: cloud_tau(:,:,:),cloud_ssa(:,:,:),cloud_g(:,:,:)
  REAL(wp), ALLOCATABLE :: prepared_tau(:,:,:),prepared_ssa(:,:,:),prepared_g(:,:,:)
  LOGICAL, ALLOCATABLE :: mask(:,:,:)
  REAL(wp), ALLOCATABLE :: randoms(:,:,:),local_random(:)
  REAL(wp), ALLOCATABLE, TARGET :: fu(:,:),fd(:,:),fdir(:,:)
  REAL(wp), ALLOCATABLE :: heat(:,:)
  REAL(wp), ALLOCATABLE :: lw_ds_field(:,:)
  REAL(wp), ALLOCATABLE :: up_all(:,:),dn_all(:,:),hr_all(:,:)
  REAL(wp), ALLOCATABLE :: up_clear(:,:),dn_clear(:,:),hr_clear(:,:)
  REAL(wp), ALLOCATABLE :: direct_all(:,:),diffuse_all(:,:),direct_clear(:,:)
  REAL(wp), ALLOCATABLE :: visdir(:,:),visdif(:,:),nirdir(:,:),nirdif(:,:)
  REAL(wp), ALLOCATABLE :: bands(:,:)
  REAL(wp), ALLOCATABLE :: v9_toa(:,:),v9_gas_tau(:,:,:),v9_mask(:,:,:)
  REAL(wp), ALLOCATABLE :: v9_cloud_tau(:,:,:),v9_precip_tau(:,:,:),v9_graupel_tau(:,:,:),v9_hail_tau(:,:,:)
  REAL(wp), ALLOCATABLE :: v11_native_cloud_tau(:,:,:),v11_cu_cloud_tau(:,:,:)
  REAL(wp), ALLOCATABLE :: v9_band_limits(:,:),v9_wavenumbers(:,:),v9_visible(:,:)
  REAL(wp), ALLOCATABLE :: raw_cloud_tau_check(:,:,:),raw_precip_tau_check(:,:,:)
  REAL(wp), ALLOCATABLE :: direct_predelta(:,:),directc_predelta(:,:),visdir_predelta(:,:),nirdir_predelta(:,:)
  REAL(wp), ALLOCATABLE :: direct_predelta_gpt(:,:,:),direct_predelta_band(:,:,:)
  INTEGER, ALLOCATABLE :: gpoint_bands(:),band_limits_gpt(:,:)
  REAL(wp), ALLOCATABLE :: visible_weights(:)
  REAL(wp), ALLOCATABLE :: override_bands(:,:),override_tau(:,:,:),override_ssa(:,:,:),override_asym(:,:,:)
  REAL(wp), ALLOCATABLE, TARGET :: flux_band_dn(:,:,:),flux_band_dir(:,:,:)
  INTEGER(i8) :: rng_state
  TYPE(ty_gas_concs) :: gases_lw,gases_sw
  TYPE(ty_gas_optics_rrtmgp) :: gas_lw,gas_sw
  TYPE(ty_cloud_optics_rrtmgp) :: cloud_lw,cloud_sw
  TYPE(ty_optical_props_1scl) :: lw_atmos,lw_cloud,lw_snow,lw_precip,lw_sampled
  TYPE(ty_optical_props_1scl) :: lw_cu
  TYPE(ty_optical_props_2str) :: sw_atmos,sw_cloud,sw_snow,sw_precip,sw_sampled
  TYPE(ty_optical_props_2str) :: sw_cu
  TYPE(ty_optical_props_1scl) :: lw_frozen,lw_audit_precip
  TYPE(ty_optical_props_2str) :: sw_frozen,sw_audit_precip
  TYPE(ty_source_func_lw) :: lw_source
  TYPE(ty_fluxes_broadband) :: lw_flux
  TYPE(ty_fluxes_byband) :: sw_flux
  CHARACTER(LEN=128) :: err
  CHARACTER(LEN=256) :: section_line
  CHARACTER(LEN=3), PARAMETER :: gas_names_sw(6)=['h2o','co2','o3 ','n2o','ch4','o2 ']
  CHARACTER(LEN=5), PARAMETER :: gas_names_lw(10)=['h2o  ','co2  ','o3   ','n2o  ','ch4  ', &
                                                    'o2   ','cfc11','cfc12','cfc22','ccl4 ']
  CHARACTER(LEN=5), PARAMETER :: gas_names_lw_with_n2(11)=['h2o  ','co2  ','o3   ','n2o  ','ch4  ', &
                                                            'o2   ','cfc11','cfc12','cfc22','ccl4 ','n2   ']

  CALL get_command_argument(1,data_dir)
  CALL get_command_argument(2,input_path)
  CALL get_command_argument(3,output_path)
  policy_arg=''
  CALL get_command_argument(4,policy_arg)
  override_path=''
  CALL get_command_argument(5,override_path)
  audit_sidecar_path=''
  CALL get_command_argument(6,audit_sidecar_path)
  lw_transport_arg=''
  CALL get_command_argument(7,lw_transport_arg,STATUS=arg_status)
  IF(arg_status/=0) ERROR STOP 'LW_TRANSPORT_POLICY argument is too long'
  lw_transport_requested=LEN_TRIM(lw_transport_arg)>0
  lw_transport_policy=1
  IF(lw_transport_requested) THEN
    SELECT CASE(TRIM(lw_transport_arg))
    CASE('1'); lw_transport_policy=1
    CASE('2'); lw_transport_policy=2
    CASE('3'); lw_transport_policy=3
    CASE DEFAULT; ERROR STOP 'LW_TRANSPORT_POLICY must be exactly 1, 2, or 3'
    END SELECT
  END IF
  n2_override_arg=''; n2_override_vmr=0._wp
  n2_override_requested=COMMAND_ARGUMENT_COUNT()>=8
  IF(n2_override_requested) THEN
    CALL get_command_argument(8,n2_override_arg,STATUS=arg_status)
    IF(arg_status/=0) ERROR STOP 'N2_OVERRIDE argument is too long'
    n2_override_arg=ADJUSTL(n2_override_arg)
    IF(LEN_TRIM(n2_override_arg)==0) ERROR STOP 'N2_OVERRIDE must be one numeric value'
    IF(INDEX(TRIM(n2_override_arg),' ')/=0.OR. &
       VERIFY(TRIM(n2_override_arg),'0123456789.+-eEdD')/=0.OR. &
       SCAN(TRIM(n2_override_arg),'0123456789')==0) ERROR STOP 'N2_OVERRIDE must be one numeric value'
    READ(n2_override_arg,*,IOSTAT=ios) n2_override_vmr
    IF(ios/=0) ERROR STOP 'N2_OVERRIDE must be one numeric value'
    IF(.NOT.ieee_is_finite(n2_override_vmr).OR.n2_override_vmr<0._wp.OR.n2_override_vmr>1._wp) &
      ERROR STOP 'N2_OVERRIDE must be finite and in [0,1]'
    IF(.NOT.lw_transport_requested) ERROR STOP 'N2_OVERRIDE requires explicit LW_TRANSPORT_POLICY argument 7'
  END IF
  IF(LEN_TRIM(data_dir)==0 .OR. LEN_TRIM(input_path)==0 .OR. LEN_TRIM(output_path)==0) &
    ERROR STOP 'usage: reference_column DATA_DIR INPUT_FILE OUTPUT_FILE [SW_POLICY 1|2|3] [SW_OPTICS_OVERRIDE_FILE] [CF0_AUDIT_SIDECAR]'
  sw_policy=1
  IF(LEN_TRIM(policy_arg)>0) THEN
    READ(policy_arg,*,IOSTAT=ios) sw_policy
    IF(ios/=0.OR.sw_policy<1.OR.sw_policy>3) ERROR STOP 'SW_POLICY must be 1, 2, or 3'
  END IF
  OPEN(NEWUNIT=u_in,FILE=TRIM(input_path),STATUS='OLD',ACTION='READ',IOSTAT=ios)
  IF(ios/=0) ERROR STOP 'could not open reference input file'
  READ(u_in,*,IOSTAT=ios) magic
  IF(ios/=0) ERROR STOP 'invalid replay input magic'
  IF(TRIM(magic)/='RRTMGP_REPLAY_V1'.AND.TRIM(magic)/='RRTMGP_REPLAY_V2'.AND. &
     TRIM(magic)/='RRTMGP_REPLAY_V3'.AND.TRIM(magic)/='RRTMGP_REPLAY_V4'.AND. &
     TRIM(magic)/='RRTMGP_REPLAY_V5'.AND.TRIM(magic)/='RRTMGP_REPLAY_V6'.AND. &
     TRIM(magic)/='RRTMGP_REPLAY_V7'.AND.TRIM(magic)/='RRTMGP_REPLAY_V8'.AND. &
     TRIM(magic)/='RRTMGP_REPLAY_V9'.AND.TRIM(magic)/='RRTMGP_REPLAY_V10'.AND. &
     TRIM(magic)/='RRTMGP_REPLAY_V11') &
    ERROR STOP 'invalid replay input magic'
  READ(u_in,*,IOSTAT=ios) phase,nc,nl,overlap,seed,iceflag
  IF(ios/=0 .OR. (TRIM(phase)/='LW' .AND. TRIM(phase)/='SW')) ERROR STOP 'invalid replay header'
  IF(TRIM(phase)=='SW'.AND.lw_transport_requested.AND.lw_transport_policy/=1) &
    ERROR STOP 'LW_TRANSPORT_POLICY other than 1 is only valid for LW'
  IF(TRIM(phase)=='SW'.AND.n2_override_requested) ERROR STOP 'N2_OVERRIDE is only valid for LW'
  sw_direct_enabled=.FALSE.
  cu_population_enabled=.FALSE.; cu_active=.FALSE.
  IF((TRIM(magic)=='RRTMGP_REPLAY_V8'.OR.TRIM(magic)=='RRTMGP_REPLAY_V10').AND.TRIM(phase)/='LW') &
    ERROR STOP 'V8/V10 are only valid for LW'
  IF((TRIM(magic)=='RRTMGP_REPLAY_V9'.OR.TRIM(magic)=='RRTMGP_REPLAY_V11').AND.TRIM(phase)/='SW') &
    ERROR STOP 'V9/V11 are only valid for SW'
  IF(nc<1 .OR. nl<1) ERROR STOP 'replay dimensions must be positive'

  ALLOCATE(play(nc,nl),plev(nc,nl+1),tlay(nc,nl),tlev(nc,nl+1),tsfc(nc,1))
  ALLOCATE(h2o(nc,nl),co2(nc,nl),o3(nc,nl),n2o(nc,nl),ch4(nc,nl),o2(nc,nl))
  ALLOCATE(emis_in(nc,16),cf(nc,nl),lwp(nc,nl),iwp(nc,nl),swp(nc,nl))
  ALLOCATE(rel(nc,nl),rei(nc,nl),res(nc,nl),avdir_in(nc,1),avdif_in(nc,1))
  ALLOCATE(andir_in(nc,1),andif_in(nc,1),mu0_in(nc,1))
  CALL read_scalar_section(u_in,'SOLAR',solar)
  CALL read_section(u_in,'PLAY',play)
  CALL read_section(u_in,'PLEV',plev)
  CALL read_section(u_in,'TLAY',tlay)
  CALL read_section(u_in,'TLEV',tlev)
  CALL read_section(u_in,'TSFC',tsfc)
  CALL read_section(u_in,'H2O',h2o)
  CALL read_section(u_in,'CO2',co2)
  CALL read_section(u_in,'O3',o3)
  CALL read_section(u_in,'N2O',n2o)
  CALL read_section(u_in,'CH4',ch4)
  CALL read_section(u_in,'O2',o2)
  IF(TRIM(magic)=='RRTMGP_REPLAY_V8'.OR.TRIM(magic)=='RRTMGP_REPLAY_V10') THEN
    ALLOCATE(vmr_cfc11(nc,nl),vmr_cfc12(nc,nl),vmr_cfc22(nc,nl),vmr_ccl4(nc,nl))
    CALL read_section(u_in,'VMR_CFC11',vmr_cfc11)
    CALL read_section(u_in,'VMR_CFC12',vmr_cfc12)
    CALL read_section(u_in,'VMR_CFC22',vmr_cfc22)
    CALL read_section(u_in,'VMR_CCL4',vmr_ccl4)
    IF(ANY(.NOT.ieee_is_finite(vmr_cfc11)).OR.ANY(vmr_cfc11<0._wp)) &
      ERROR STOP 'V8 VMR_CFC11 must be finite/nonnegative'
    IF(ANY(.NOT.ieee_is_finite(vmr_cfc12)).OR.ANY(vmr_cfc12<0._wp)) &
      ERROR STOP 'V8 VMR_CFC12 must be finite/nonnegative'
    IF(ANY(.NOT.ieee_is_finite(vmr_cfc22)).OR.ANY(vmr_cfc22<0._wp)) &
      ERROR STOP 'V8 VMR_CFC22 must be finite/nonnegative'
    IF(ANY(.NOT.ieee_is_finite(vmr_ccl4)).OR.ANY(vmr_ccl4<0._wp)) &
      ERROR STOP 'V8 VMR_CCL4 must be finite/nonnegative'
  END IF
  CALL read_section_flexible(u_in,'EMIS',emis_in,nemis)
  CALL read_section(u_in,'AVDIR',avdir_in)
  CALL read_section(u_in,'AVDIF',avdif_in)
  CALL read_section(u_in,'ANDIR',andir_in)
  CALL read_section(u_in,'ANDIF',andif_in)
  CALL read_section(u_in,'MU0',mu0_in)
  CALL read_section(u_in,'CF',cf)
  CALL read_section(u_in,'LWP',lwp)
  CALL read_section(u_in,'IWP',iwp)
  CALL read_section(u_in,'SWP',swp)
  CALL read_section(u_in,'REL',rel)
  CALL read_section(u_in,'REI',rei)
  CALL read_section(u_in,'RES',res)
  IF(TRIM(magic)=='RRTMGP_REPLAY_V10'.OR.TRIM(magic)=='RRTMGP_REPLAY_V11') THEN
    cu_population_enabled=.TRUE.
    CALL read_scalar_section(u_in,'CU_POPULATION_POLICY',cu_policy_value)
    IF(.NOT.ieee_is_finite(cu_policy_value).OR.cu_policy_value/=1._wp) &
      ERROR STOP 'V10/V11 CU_POPULATION_POLICY must equal one'
    CALL read_scalar_section(u_in,'CU_RADIUS_POLICY',cu_policy_value)
    IF(.NOT.ieee_is_finite(cu_policy_value).OR.cu_policy_value/=1._wp) &
      ERROR STOP 'V10/V11 CU_RADIUS_POLICY must equal one'
    CALL read_scalar_section(u_in,'CU_OCCURRENCE_POLICY',cu_policy_value)
    IF(.NOT.ieee_is_finite(cu_policy_value).OR.cu_policy_value/=1._wp) &
      ERROR STOP 'V10/V11 CU_OCCURRENCE_POLICY must equal one'
    ALLOCATE(cu_lwp(nc,nl),cu_iwp(nc,nl),cu_rel(nc,nl),cu_rei(nc,nl))
    CALL read_section(u_in,'CU_LWP',cu_lwp); CALL read_section(u_in,'CU_IWP',cu_iwp)
    CALL read_section(u_in,'CU_REL',cu_rel); CALL read_section(u_in,'CU_REI',cu_rei)
    IF(ANY(.NOT.ieee_is_finite(cu_lwp)).OR.ANY(cu_lwp<0._wp)) &
      ERROR STOP 'V10/V11 CU_LWP must be finite/nonnegative'
    IF(ANY(.NOT.ieee_is_finite(cu_iwp)).OR.ANY(cu_iwp<0._wp)) &
      ERROR STOP 'V10/V11 CU_IWP must be finite/nonnegative'
    IF(ANY(.NOT.ieee_is_finite(cu_rel)).OR.ANY(cu_rel<=0._wp)) &
      ERROR STOP 'V10/V11 CU_REL must be finite/positive'
    IF(ANY(.NOT.ieee_is_finite(cu_rei)).OR.ANY(cu_rei<=0._wp)) &
      ERROR STOP 'V10/V11 CU_REI must be finite/positive'
    cu_active=ANY(cu_lwp>0._wp).OR.ANY(cu_iwp>0._wp)
  END IF
  ice_roughness=1
  IF(TRIM(magic)/='RRTMGP_REPLAY_V1') THEN
    CALL read_scalar_section(u_in,'ICE_ROUGHNESS',roughness_value)
    IF(.NOT.ieee_is_finite(roughness_value)) ERROR STOP 'non-finite ice roughness'
    IF(roughness_value<1._wp.OR.roughness_value>3._wp) ERROR STOP 'invalid ice roughness'
    ice_roughness=INT(roughness_value)
    IF(REAL(ice_roughness,wp)/=roughness_value) ERROR STOP 'ice roughness must be integer'
  END IF
  IF((TRIM(magic)=='RRTMGP_REPLAY_V3'.OR.TRIM(magic)=='RRTMGP_REPLAY_V4'.OR. &
      TRIM(magic)=='RRTMGP_REPLAY_V5'.OR.TRIM(magic)=='RRTMGP_REPLAY_V6'.OR. &
      TRIM(magic)=='RRTMGP_REPLAY_V7'.OR.TRIM(magic)=='RRTMGP_REPLAY_V8'.OR. &
      TRIM(magic)=='RRTMGP_REPLAY_V9'.OR.TRIM(magic)=='RRTMGP_REPLAY_V10'.OR. &
      TRIM(magic)=='RRTMGP_REPLAY_V11').AND. &
     TRIM(phase)=='SW') THEN
    CALL read_scalar_section(u_in,'SW_BAND_PARTITION',partition_value)
    IF(.NOT.ieee_is_finite(partition_value)) ERROR STOP 'non-finite SW band partition'
    IF(partition_value/=1._wp) THEN
      IF(TRIM(magic)=='RRTMGP_REPLAY_V3') &
        ERROR STOP 'V3 requires SW_BAND_PARTITION=1 (CCPP transition)'
      ERROR STOP 'V4-V7 require SW_BAND_PARTITION=1 (CCPP transition)'
    END IF
  END IF
  use_precip=.FALSE.
  IF(TRIM(magic)=='RRTMGP_REPLAY_V4') THEN
    CALL read_scalar_section(u_in,'PRECIPITATION_OPTICS',precip_mode)
    IF(.NOT.ieee_is_finite(precip_mode)) ERROR STOP 'V4 PRECIPITATION_OPTICS must be finite'
    IF(precip_mode/=1._wp) ERROR STOP 'V4 requires PRECIPITATION_OPTICS=1'
    ALLOCATE(rwp(nc,nl))
    CALL read_section(u_in,'RWP',rwp)
    IF(ANY(.NOT.ieee_is_finite(rwp))) ERROR STOP 'V4 RWP must be finite'
    IF(ANY(rwp<0._wp)) ERROR STOP 'V4 RWP must be nonnegative'
    use_precip=.TRUE.
  ELSE IF(TRIM(magic)=='RRTMGP_REPLAY_V5'.OR.TRIM(magic)=='RRTMGP_REPLAY_V6') THEN
    READ(u_in,'(A)',IOSTAT=ios) section_line
    IF(ios/=0) ERROR STOP 'V5 input ended before constants metadata'
    READ(section_line,*,IOSTAT=ios) next_section
    IF(ios/=0) ERROR STOP 'V5 invalid optional precipitation/constants section'
    BACKSPACE(u_in)
    IF(TRIM(next_section)=='PRECIPITATION_OPTICS') THEN
      CALL read_scalar_section(u_in,'PRECIPITATION_OPTICS',precip_mode)
      IF(.NOT.ieee_is_finite(precip_mode)) ERROR STOP 'V5/V6 PRECIPITATION_OPTICS must be finite'
      IF(precip_mode/=1._wp) ERROR STOP 'V5/V6 PRECIPITATION_OPTICS must equal one when present'
      ALLOCATE(rwp(nc,nl))
      CALL read_section(u_in,'RWP',rwp)
      IF(ANY(.NOT.ieee_is_finite(rwp))) ERROR STOP 'V5/V6 RWP must be finite'
      IF(ANY(rwp<0._wp)) ERROR STOP 'V5/V6 RWP must be nonnegative'
      use_precip=.TRUE.
    ELSE IF(TRIM(next_section)/='GRAVITY'.AND. &
            (TRIM(magic)/='RRTMGP_REPLAY_V6'.OR.TRIM(next_section)/='NATIVE_DRY_LAYER_MASS_KG_M2')) THEN
      ERROR STOP 'V5/V6 expected optional precipitation or mass/constants metadata'
    END IF
  END IF
  has_native_mass=TRIM(magic)=='RRTMGP_REPLAY_V6'
  IF(TRIM(magic)=='RRTMGP_REPLAY_V6') THEN
    ALLOCATE(native_dry_mass(nc,nl))
    CALL read_section_flexible(u_in,'NATIVE_DRY_LAYER_MASS_KG_M2',native_dry_mass,n_native)
    IF(n_native<1.OR.n_native>nl) ERROR STOP 'V6 native dry mass layer count must be within 1:nl'
    IF(ANY(.NOT.ieee_is_finite(native_dry_mass(:,1:n_native)))) &
      ERROR STOP 'V6 native dry layer mass must be finite and positive'
    IF(ANY(native_dry_mass(:,1:n_native)<=0._wp)) &
      ERROR STOP 'V6 native dry layer mass must be finite and positive'
  END IF
  frozen_enabled=.FALSE.
  IF(TRIM(magic)=='RRTMGP_REPLAY_V8'.OR.TRIM(magic)=='RRTMGP_REPLAY_V10') THEN
    ! V8 adds four recorded LW gas VMR profiles before any optional frozen
    ! optics profile and the host constants appended by trace_input_end.
    DO i=1,2
      READ(u_in,'(A)',IOSTAT=ios) section_line
      IF(ios/=0) ERROR STOP 'V8 ended before LW trace-gas inputs'
      READ(section_line,*,IOSTAT=ios) next_section
      IF(ios/=0) ERROR STOP 'V8 invalid optional precipitation/mass section'
      BACKSPACE(u_in)
      IF(TRIM(next_section)=='PRECIPITATION_OPTICS') THEN
        IF(use_precip) ERROR STOP 'V8 duplicate precipitation metadata'
        CALL read_scalar_section(u_in,'PRECIPITATION_OPTICS',precip_mode)
        IF(.NOT.ieee_is_finite(precip_mode).OR.precip_mode/=1._wp) &
          ERROR STOP 'V8 PRECIPITATION_OPTICS must equal one'
        ALLOCATE(rwp(nc,nl))
        CALL read_section(u_in,'RWP',rwp)
        IF(ANY(.NOT.ieee_is_finite(rwp)).OR.ANY(rwp<0._wp)) ERROR STOP 'V8 RWP must be finite/nonnegative'
        use_precip=.TRUE.
      ELSE IF(TRIM(next_section)=='NATIVE_DRY_LAYER_MASS_KG_M2') THEN
        IF(has_native_mass) ERROR STOP 'V8 duplicate native dry mass metadata'
        ALLOCATE(native_dry_mass(nc,nl))
        CALL read_section_flexible(u_in,'NATIVE_DRY_LAYER_MASS_KG_M2',native_dry_mass,n_native)
        IF(n_native<1.OR.n_native>nl) ERROR STOP 'V8 native dry mass layer count must be within 1:nl'
        IF(ANY(.NOT.ieee_is_finite(native_dry_mass(:,1:n_native))).OR. &
           ANY(native_dry_mass(:,1:n_native)<=0._wp)) ERROR STOP 'V8 native dry layer mass must be finite/positive'
        has_native_mass=.TRUE.
      ELSE
        EXIT
      END IF
    END DO
    READ(u_in,'(A)',IOSTAT=ios) section_line
    IF(ios/=0) ERROR STOP 'V8 ended before constants metadata'
    READ(section_line,*,IOSTAT=ios) next_section
    IF(ios/=0) ERROR STOP 'V8 invalid constants/frozen section header'
    BACKSPACE(u_in)
    IF(TRIM(next_section)=='GWP') THEN
      ALLOCATE(gwp(nc,nl),hwp(nc,nl),lambda_g(nc,nl),lambda_h(nc,nl))
      CALL read_section(u_in,'GWP',gwp)
      CALL read_section(u_in,'HWP',hwp)
      CALL read_section(u_in,'LAMBDA_G',lambda_g)
      CALL read_section(u_in,'LAMBDA_H',lambda_h)
      IF(ANY(.NOT.ieee_is_finite(gwp)).OR.ANY(gwp<0._wp)) ERROR STOP 'V8 GWP must be finite/nonnegative'
      IF(ANY(.NOT.ieee_is_finite(hwp)).OR.ANY(hwp<0._wp)) ERROR STOP 'V8 HWP must be finite/nonnegative'
      IF(ANY(.NOT.ieee_is_finite(lambda_g)).OR.ANY(lambda_g<=0._wp)) ERROR STOP 'V8 LAMBDA_G must be finite/positive'
      IF(ANY(.NOT.ieee_is_finite(lambda_h)).OR.ANY(lambda_h<=0._wp)) ERROR STOP 'V8 LAMBDA_H must be finite/positive'
      frozen_enabled=.TRUE.
    END IF
    CALL read_scalar_section(u_in,'GRAVITY',metadata_gravity)
    CALL read_scalar_section(u_in,'CP_DRY',metadata_cp_dry)
    CALL read_scalar_section(u_in,'MOL_WEIGHT_DRY',metadata_mol_weight_dry)
    IF(.NOT.ieee_is_finite(metadata_gravity).OR.metadata_gravity<=0._wp) ERROR STOP 'V8 GRAVITY must be finite/positive'
    IF(.NOT.ieee_is_finite(metadata_cp_dry).OR.metadata_cp_dry<=0._wp) ERROR STOP 'V8 CP_DRY must be finite/positive'
    IF(.NOT.ieee_is_finite(metadata_mol_weight_dry).OR.metadata_mol_weight_dry<=0._wp) &
      ERROR STOP 'V8 MOL_WEIGHT_DRY must be finite/positive'
    CALL init_constants(gravity=metadata_gravity,heat_capacity_dry_air=metadata_cp_dry, &
                        mol_weight_dry_air=metadata_mol_weight_dry)
    IF(frozen_enabled) THEN
      ALLOCATE(frozen_hash_bytes(64,1))
      CALL read_scalar_section(u_in,'FROZEN_MODE',frozen_mode_value)
      IF(.NOT.ieee_is_finite(frozen_mode_value).OR.frozen_mode_value/=1._wp) &
        ERROR STOP 'V8 FROZEN_MODE must equal one when frozen records are present'
      CALL read_scalar_section(u_in,'FROZEN_OCCURRENCE',frozen_occurrence)
      IF(.NOT.ieee_is_finite(frozen_occurrence).OR.frozen_occurrence/=1._wp) &
        ERROR STOP 'V8 FROZEN_OCCURRENCE must equal one'
      CALL read_section(u_in,'FROZEN_TABLE_SHA256_BYTES',frozen_hash_bytes)
      IF(ANY(.NOT.ieee_is_finite(frozen_hash_bytes))) ERROR STOP 'V8 frozen table SHA bytes must be finite'
      frozen_sha_recorded=''
      DO i=1,64
        IF(frozen_hash_bytes(i,1)<0._wp.OR.frozen_hash_bytes(i,1)>127._wp) &
          ERROR STOP 'V8 frozen table SHA bytes must be integer ASCII'
        IF(frozen_hash_bytes(i,1)/=REAL(NINT(frozen_hash_bytes(i,1)),wp)) &
          ERROR STOP 'V8 frozen table SHA bytes must be integer ASCII'
        frozen_sha_recorded(i:i)=ACHAR(NINT(frozen_hash_bytes(i,1)))
        IF(.NOT.((frozen_sha_recorded(i:i)>='0'.AND.frozen_sha_recorded(i:i)<='9').OR. &
                 (frozen_sha_recorded(i:i)>='a'.AND.frozen_sha_recorded(i:i)<='f'))) &
          ERROR STOP 'V8 frozen table SHA must be lowercase hexadecimal'
      END DO
      frozen_table_env=''
      CALL GET_ENVIRONMENT_VARIABLE('WRF_RRTMGP_FROZEN_TABLE',frozen_table_env,STATUS=env_status)
      IF(env_status/=0.OR.LEN_TRIM(frozen_table_env)==0) ERROR STOP 'V8 requires WRF_RRTMGP_FROZEN_TABLE'
      CALL rrtmgp_file_sha256(TRIM(frozen_table_env),frozen_sha_raw,frozen_status,frozen_message)
      IF(frozen_status/=0) THEN
        WRITE(*,'(A)') TRIM(frozen_message)
        ERROR STOP 'V8 frozen table file cannot be hashed'
      END IF
      IF(frozen_sha_raw/=frozen_sha_recorded) ERROR STOP 'V8 frozen table SHA256 does not match input'
      CALL initialize_frozen(TRIM(frozen_table_env),frozen_status,frozen_message)
      IF(frozen_status/=0) THEN
        WRITE(*,'(A)') TRIM(frozen_message)
        ERROR STOP 'V8 frozen table initialization failed'
      END IF
      IF(frozen_table_sha256()/=frozen_sha_recorded) ERROR STOP 'V8 loaded table identity differs from input'
    END IF
    READ(u_in,'(A)',IOSTAT=ios) section_line
    IF(ios>=0) ERROR STOP 'V8/V10 contains trailing or unsupported records'
  END IF
  IF(TRIM(magic)=='RRTMGP_REPLAY_V9'.OR.TRIM(magic)=='RRTMGP_REPLAY_V11') THEN
    use_precip=.FALSE.; frozen_enabled=.FALSE.; has_native_mass=.FALSE.
    DO i=1,2
      READ(u_in,'(A)',IOSTAT=ios) section_line
      IF(ios/=0) ERROR STOP 'V9 ended before direct-diagnostic inputs'
      READ(section_line,*,IOSTAT=ios) next_section
      IF(ios/=0) ERROR STOP 'V9 invalid optional precipitation/mass/frozen header'
      BACKSPACE(u_in)
      IF(TRIM(next_section)=='PRECIPITATION_OPTICS') THEN
        IF(use_precip) ERROR STOP 'V9 duplicate precipitation metadata'
        CALL read_scalar_section(u_in,'PRECIPITATION_OPTICS',precip_mode)
        IF(.NOT.ieee_is_finite(precip_mode)) ERROR STOP 'V9 PRECIPITATION_OPTICS must be finite'
        IF(precip_mode/=1._wp) ERROR STOP 'V9 PRECIPITATION_OPTICS must equal one'
        ALLOCATE(rwp(nc,nl)); CALL read_section(u_in,'RWP',rwp)
        IF(ANY(.NOT.ieee_is_finite(rwp))) ERROR STOP 'V9 RWP must be finite'
        IF(ANY(rwp<0._wp)) ERROR STOP 'V9 RWP must be nonnegative'
        use_precip=.TRUE.
      ELSE IF(TRIM(next_section)=='NATIVE_DRY_LAYER_MASS_KG_M2') THEN
        IF(has_native_mass) ERROR STOP 'V9 duplicate native dry mass'
        ALLOCATE(native_dry_mass(nc,nl))
        CALL read_section_flexible(u_in,'NATIVE_DRY_LAYER_MASS_KG_M2',native_dry_mass,n_native)
        IF(n_native<1.OR.n_native>nl) ERROR STOP 'V9 native dry mass layer count out of range'
        IF(ANY(.NOT.ieee_is_finite(native_dry_mass(:,1:n_native)))) ERROR STOP 'V9 native mass must be finite'
        IF(ANY(native_dry_mass(:,1:n_native)<=0._wp)) ERROR STOP 'V9 native mass must be positive'
        has_native_mass=.TRUE.
      ELSE
        EXIT
      END IF
    END DO
    READ(u_in,'(A)',IOSTAT=ios) section_line
    IF(ios/=0) ERROR STOP 'V9 ended before constants/frozen metadata'
    READ(section_line,*,IOSTAT=ios) next_section
    IF(ios/=0) ERROR STOP 'V9 invalid constants/frozen metadata header'
    BACKSPACE(u_in)
    IF(TRIM(next_section)=='GWP') THEN
      ALLOCATE(gwp(nc,nl),hwp(nc,nl),lambda_g(nc,nl),lambda_h(nc,nl))
      CALL read_section(u_in,'GWP',gwp); CALL read_section(u_in,'HWP',hwp)
      CALL read_section(u_in,'LAMBDA_G',lambda_g); CALL read_section(u_in,'LAMBDA_H',lambda_h)
      IF(ANY(.NOT.ieee_is_finite(gwp))) ERROR STOP 'V9 GWP must be finite'
      IF(ANY(gwp<0._wp)) ERROR STOP 'V9 GWP must be nonnegative'
      IF(ANY(.NOT.ieee_is_finite(hwp))) ERROR STOP 'V9 HWP must be finite'
      IF(ANY(hwp<0._wp)) ERROR STOP 'V9 HWP must be nonnegative'
      IF(ANY(.NOT.ieee_is_finite(lambda_g))) ERROR STOP 'V9 LAMBDA_G must be finite'
      IF(ANY(lambda_g<=0._wp)) ERROR STOP 'V9 LAMBDA_G must be positive'
      IF(ANY(.NOT.ieee_is_finite(lambda_h))) ERROR STOP 'V9 LAMBDA_H must be finite'
      IF(ANY(lambda_h<=0._wp)) ERROR STOP 'V9 LAMBDA_H must be positive'
      frozen_enabled=.TRUE.
    END IF
    CALL read_scalar_section(u_in,'GRAVITY',metadata_gravity)
    CALL read_scalar_section(u_in,'CP_DRY',metadata_cp_dry)
    CALL read_scalar_section(u_in,'MOL_WEIGHT_DRY',metadata_mol_weight_dry)
    IF(.NOT.ieee_is_finite(metadata_gravity)) ERROR STOP 'V9 GRAVITY must be finite'
    IF(metadata_gravity<=0._wp) ERROR STOP 'V9 GRAVITY must be positive'
    IF(.NOT.ieee_is_finite(metadata_cp_dry)) ERROR STOP 'V9 CP_DRY must be finite'
    IF(metadata_cp_dry<=0._wp) ERROR STOP 'V9 CP_DRY must be positive'
    IF(.NOT.ieee_is_finite(metadata_mol_weight_dry)) ERROR STOP 'V9 MOL_WEIGHT_DRY must be finite'
    IF(metadata_mol_weight_dry<=0._wp) ERROR STOP 'V9 MOL_WEIGHT_DRY must be positive'
    CALL init_constants(gravity=metadata_gravity,heat_capacity_dry_air=metadata_cp_dry, &
                        mol_weight_dry_air=metadata_mol_weight_dry)
    IF(frozen_enabled) THEN
      ALLOCATE(frozen_hash_bytes(64,1))
      CALL read_scalar_section(u_in,'FROZEN_MODE',frozen_mode_value)
      IF(.NOT.ieee_is_finite(frozen_mode_value)) ERROR STOP 'V9 FROZEN_MODE must be finite'
      IF(frozen_mode_value/=1._wp) ERROR STOP 'V9 FROZEN_MODE must equal one'
      CALL read_scalar_section(u_in,'FROZEN_OCCURRENCE',frozen_occurrence)
      IF(.NOT.ieee_is_finite(frozen_occurrence)) ERROR STOP 'V9 FROZEN_OCCURRENCE must be finite'
      IF(frozen_occurrence/=1._wp) ERROR STOP 'V9 FROZEN_OCCURRENCE must equal one'
      CALL read_section(u_in,'FROZEN_TABLE_SHA256_BYTES',frozen_hash_bytes)
      IF(ANY(.NOT.ieee_is_finite(frozen_hash_bytes))) ERROR STOP 'V9 frozen SHA bytes must be finite'
      frozen_sha_recorded=''
      DO i=1,64
        IF(frozen_hash_bytes(i,1)<0._wp.OR.frozen_hash_bytes(i,1)>127._wp) ERROR STOP 'V9 invalid SHA byte'
        IF(frozen_hash_bytes(i,1)/=REAL(NINT(frozen_hash_bytes(i,1)),wp)) ERROR STOP 'V9 SHA byte is not integer'
        frozen_sha_recorded(i:i)=ACHAR(NINT(frozen_hash_bytes(i,1)))
        IF(.NOT.((frozen_sha_recorded(i:i)>='0'.AND.frozen_sha_recorded(i:i)<='9').OR. &
                 (frozen_sha_recorded(i:i)>='a'.AND.frozen_sha_recorded(i:i)<='f'))) ERROR STOP 'V9 invalid SHA hex'
      END DO
      frozen_table_env=''
      CALL GET_ENVIRONMENT_VARIABLE('WRF_RRTMGP_FROZEN_TABLE',frozen_table_env,STATUS=env_status)
      IF(env_status/=0.OR.LEN_TRIM(frozen_table_env)==0) ERROR STOP 'V9 frozen mode requires WRF_RRTMGP_FROZEN_TABLE'
      CALL rrtmgp_file_sha256(TRIM(frozen_table_env),frozen_sha_raw,frozen_status,frozen_message)
      IF(frozen_status/=0) ERROR STOP 'V9 frozen table could not be hashed'
      IF(frozen_sha_raw/=frozen_sha_recorded) ERROR STOP 'V9 frozen table hash differs from input'
      CALL initialize_frozen(TRIM(frozen_table_env),frozen_status,frozen_message)
      IF(frozen_status/=0) ERROR STOP 'V9 frozen table initialization failed'
      IF(frozen_table_sha256()/=frozen_sha_recorded) ERROR STOP 'V9 loaded frozen table hash differs'
    END IF
    CALL read_scalar_section(u_in,'SW_DIRECT_PREDELTA_POLICY',partition_value)
    IF(.NOT.ieee_is_finite(partition_value)) ERROR STOP 'V9 direct policy must be finite'
    IF(partition_value/=1._wp) ERROR STOP 'V9 direct policy must equal one'
    CALL read_section2_alloc(u_in,'TOA_GPOINT',v9_toa)
    CALL read_section3_alloc(u_in,'RAW_GAS_TAU',v9_gas_tau)
    CALL read_section3_alloc(u_in,'MCICA_MASK',v9_mask)
    CALL read_section3_alloc(u_in,'RAW_CLOUD_TAU',v9_cloud_tau)
    IF(TRIM(magic)=='RRTMGP_REPLAY_V11') THEN
      CALL read_section3_alloc(u_in,'RAW_NATIVE_CLOUD_TAU',v11_native_cloud_tau)
      CALL read_section3_alloc(u_in,'RAW_CU_CLOUD_TAU',v11_cu_cloud_tau)
    END IF
    CALL read_section3_alloc(u_in,'RAW_PRECIP_TAU',v9_precip_tau)
    CALL read_section3_alloc(u_in,'RAW_GRAUPEL_TAU_EXT',v9_graupel_tau)
    CALL read_section3_alloc(u_in,'RAW_HAIL_TAU_EXT',v9_hail_tau)
    CALL read_section2_alloc(u_in,'BAND_LIMS_GPOINT',v9_band_limits)
    CALL read_section2_alloc(u_in,'BAND_LIMS_WAVENUMBER',v9_wavenumbers)
    CALL read_section2_alloc(u_in,'VISIBLE_WEIGHT',v9_visible)
    READ(u_in,'(A)',IOSTAT=ios) section_line
    IF(ios>=0) ERROR STOP 'V9/V11 contains trailing or unsupported records'
    sw_direct_enabled=.TRUE.
  END IF
  IF(TRIM(magic)=='RRTMGP_REPLAY_V7') THEN
    frozen_enabled=.TRUE.
    ! V7 keeps optional V5/V6 extras before the four immutable-optics inputs.
    DO i=1,2
      READ(u_in,'(A)',IOSTAT=ios) section_line
      IF(ios/=0) ERROR STOP 'V7 ended before frozen optics inputs'
      READ(section_line,*,IOSTAT=ios) next_section
      IF(ios/=0) ERROR STOP 'V7 invalid optional section header'
      BACKSPACE(u_in)
      IF(TRIM(next_section)=='PRECIPITATION_OPTICS') THEN
        IF(use_precip) ERROR STOP 'V7 duplicate precipitation metadata'
        CALL read_scalar_section(u_in,'PRECIPITATION_OPTICS',precip_mode)
        IF(.NOT.ieee_is_finite(precip_mode).OR.precip_mode/=1._wp) &
          ERROR STOP 'V7 PRECIPITATION_OPTICS must equal one'
        ALLOCATE(rwp(nc,nl))
        CALL read_section(u_in,'RWP',rwp)
        IF(ANY(.NOT.ieee_is_finite(rwp)).OR.ANY(rwp<0._wp)) ERROR STOP 'V7 RWP must be finite/nonnegative'
        use_precip=.TRUE.
      ELSE IF(TRIM(next_section)=='NATIVE_DRY_LAYER_MASS_KG_M2') THEN
        IF(has_native_mass) ERROR STOP 'V7 duplicate native dry mass metadata'
        ALLOCATE(native_dry_mass(nc,nl))
        CALL read_section_flexible(u_in,'NATIVE_DRY_LAYER_MASS_KG_M2',native_dry_mass,n_native)
        IF(n_native<1.OR.n_native>nl) ERROR STOP 'V7 native dry mass layer count must be within 1:nl'
        IF(ANY(.NOT.ieee_is_finite(native_dry_mass(:,1:n_native))).OR. &
           ANY(native_dry_mass(:,1:n_native)<=0._wp)) ERROR STOP 'V7 native dry layer mass must be finite/positive'
        has_native_mass=.TRUE.
      ELSE
        EXIT
      END IF
    END DO
    ALLOCATE(gwp(nc,nl),hwp(nc,nl),lambda_g(nc,nl),lambda_h(nc,nl),frozen_hash_bytes(64,1))
    CALL read_section(u_in,'GWP',gwp)
    CALL read_section(u_in,'HWP',hwp)
    CALL read_section(u_in,'LAMBDA_G',lambda_g)
    CALL read_section(u_in,'LAMBDA_H',lambda_h)
    IF(ANY(.NOT.ieee_is_finite(gwp)).OR.ANY(gwp<0._wp)) ERROR STOP 'V7 GWP must be finite/nonnegative'
    IF(ANY(.NOT.ieee_is_finite(hwp)).OR.ANY(hwp<0._wp)) ERROR STOP 'V7 HWP must be finite/nonnegative'
    IF(ANY(.NOT.ieee_is_finite(lambda_g)).OR.ANY(lambda_g<=0._wp)) ERROR STOP 'V7 LAMBDA_G must be finite/positive'
    IF(ANY(.NOT.ieee_is_finite(lambda_h)).OR.ANY(lambda_h<=0._wp)) ERROR STOP 'V7 LAMBDA_H must be finite/positive'
    CALL read_scalar_section(u_in,'GRAVITY',metadata_gravity)
    CALL read_scalar_section(u_in,'CP_DRY',metadata_cp_dry)
    CALL read_scalar_section(u_in,'MOL_WEIGHT_DRY',metadata_mol_weight_dry)
    IF(.NOT.ieee_is_finite(metadata_gravity).OR.metadata_gravity<=0._wp) ERROR STOP 'V7 GRAVITY must be finite/positive'
    IF(.NOT.ieee_is_finite(metadata_cp_dry).OR.metadata_cp_dry<=0._wp) ERROR STOP 'V7 CP_DRY must be finite/positive'
    IF(.NOT.ieee_is_finite(metadata_mol_weight_dry).OR.metadata_mol_weight_dry<=0._wp) &
      ERROR STOP 'V7 MOL_WEIGHT_DRY must be finite/positive'
    CALL init_constants(gravity=metadata_gravity,heat_capacity_dry_air=metadata_cp_dry, &
                        mol_weight_dry_air=metadata_mol_weight_dry)
    CALL read_scalar_section(u_in,'FROZEN_MODE',frozen_mode_value)
    IF(.NOT.ieee_is_finite(frozen_mode_value).OR.frozen_mode_value/=1._wp) &
      ERROR STOP 'V7 FROZEN_MODE must equal one'
    CALL read_scalar_section(u_in,'FROZEN_OCCURRENCE',frozen_occurrence)
    IF(.NOT.ieee_is_finite(frozen_occurrence).OR.frozen_occurrence/=1._wp) &
      ERROR STOP 'V7 FROZEN_OCCURRENCE must equal one'
    CALL read_section(u_in,'FROZEN_TABLE_SHA256_BYTES',frozen_hash_bytes)
    IF(ANY(.NOT.ieee_is_finite(frozen_hash_bytes))) ERROR STOP 'V7 frozen table SHA bytes must be finite'
    frozen_sha_recorded=''
    DO i=1,64
      IF(frozen_hash_bytes(i,1)<0._wp.OR.frozen_hash_bytes(i,1)>127._wp) &
        ERROR STOP 'V7 frozen table SHA bytes must be integer ASCII'
      IF(frozen_hash_bytes(i,1)/=REAL(NINT(frozen_hash_bytes(i,1)),wp)) &
        ERROR STOP 'V7 frozen table SHA bytes must be integer ASCII'
      frozen_sha_recorded(i:i)=ACHAR(NINT(frozen_hash_bytes(i,1)))
    END DO
    DO i=1,64
      IF(.NOT.((frozen_sha_recorded(i:i)>='0'.AND.frozen_sha_recorded(i:i)<='9').OR. &
               (frozen_sha_recorded(i:i)>='a'.AND.frozen_sha_recorded(i:i)<='f'))) &
        ERROR STOP 'V7 frozen table SHA must be lowercase hexadecimal'
    END DO
    frozen_table_env=''
    CALL GET_ENVIRONMENT_VARIABLE('WRF_RRTMGP_FROZEN_TABLE',frozen_table_env,STATUS=env_status)
    IF(env_status/=0.OR.LEN_TRIM(frozen_table_env)==0) &
      ERROR STOP 'V7 requires WRF_RRTMGP_FROZEN_TABLE'
    CALL rrtmgp_file_sha256(TRIM(frozen_table_env),frozen_sha_raw,frozen_status,frozen_message)
    IF(frozen_status/=0) THEN
      WRITE(*,'(A)') TRIM(frozen_message)
      ERROR STOP 'V7 frozen table file cannot be hashed'
    END IF
    IF(frozen_sha_raw/=frozen_sha_recorded) ERROR STOP 'V7 frozen table SHA256 does not match input'
    CALL initialize_frozen(TRIM(frozen_table_env),frozen_status,frozen_message)
    IF(frozen_status/=0) THEN
      WRITE(*,'(A)') TRIM(frozen_message)
      ERROR STOP 'V7 frozen table initialization failed'
    END IF
    IF(frozen_table_sha256()/=frozen_sha_recorded) ERROR STOP 'V7 loaded table identity differs from input'
    READ(u_in,'(A)',IOSTAT=ios) section_line
    IF(ios>=0) ERROR STOP 'V7 contains trailing or unsupported records'
  END IF
  IF(TRIM(magic)=='RRTMGP_REPLAY_V5'.OR.TRIM(magic)=='RRTMGP_REPLAY_V6') THEN
    CALL read_scalar_section(u_in,'GRAVITY',metadata_gravity)
    CALL read_scalar_section(u_in,'CP_DRY',metadata_cp_dry)
    CALL read_scalar_section(u_in,'MOL_WEIGHT_DRY',metadata_mol_weight_dry)
    IF(.NOT.ieee_is_finite(metadata_gravity)) ERROR STOP 'V5/V6 GRAVITY must be finite'
    IF(metadata_gravity<=0._wp) ERROR STOP 'V5/V6 GRAVITY must be positive'
    IF(.NOT.ieee_is_finite(metadata_cp_dry)) ERROR STOP 'V5/V6 CP_DRY must be finite'
    IF(metadata_cp_dry<=0._wp) ERROR STOP 'V5/V6 CP_DRY must be positive'
    IF(.NOT.ieee_is_finite(metadata_mol_weight_dry)) ERROR STOP 'V5/V6 MOL_WEIGHT_DRY must be finite'
    IF(metadata_mol_weight_dry<=0._wp) ERROR STOP 'V5/V6 MOL_WEIGHT_DRY must be positive'
    CALL init_constants(gravity=metadata_gravity, heat_capacity_dry_air=metadata_cp_dry, &
                        mol_weight_dry_air=metadata_mol_weight_dry)
  END IF
  IF(TRIM(magic)/='RRTMGP_REPLAY_V7'.AND.TRIM(magic)/='RRTMGP_REPLAY_V9'.AND. &
     TRIM(magic)/='RRTMGP_REPLAY_V10'.AND.TRIM(magic)/='RRTMGP_REPLAY_V11') THEN
    READ(u_in,'(A)',IOSTAT=ios) section_line
    IF(ios==0) THEN
      READ(section_line,*,IOSTAT=ios) next_section
      IF(ios==0) THEN
        IF(TRIM(next_section)=='FROZEN_MODE'.OR.TRIM(next_section)=='FROZEN_OCCURRENCE'.OR. &
           TRIM(next_section)=='FROZEN_TABLE_SHA256_BYTES'.OR.TRIM(next_section)=='GWP'.OR. &
           TRIM(next_section)=='HWP'.OR.TRIM(next_section)=='LAMBDA_G'.OR.TRIM(next_section)=='LAMBDA_H') &
          ERROR STOP 'frozen optics records require RRTMGP_REPLAY_V7'
      END IF
    END IF
  END IF
  CLOSE(u_in)
  audit_sidecar_present=LEN_TRIM(audit_sidecar_path)>0
  audit_precip_active=.FALSE.
  IF(audit_sidecar_present) THEN
    IF(TRIM(magic)/='RRTMGP_REPLAY_V8'.AND.TRIM(magic)/='RRTMGP_REPLAY_V9'.AND. &
       TRIM(magic)/='RRTMGP_REPLAY_V10'.AND.TRIM(magic)/='RRTMGP_REPLAY_V11') &
      ERROR STOP 'CF0 precipitation audit sidecar requires V8/V9/V10/V11 held inputs'
    audit_expected_native=0
    IF(has_native_mass) audit_expected_native=n_native
    CALL read_cf0_precip_sidecar(TRIM(audit_sidecar_path),TRIM(phase),nc,nl,audit_expected_native,cf, &
                                 audit_rwp,audit_swp,audit_native_n,audit_sidecar_species,audit_occurrence)
    IF(TRIM(phase)=='SW'.AND.(.NOT.sw_direct_enabled.OR..NOT.use_precip)) &
      ERROR STOP 'SW CF0 precipitation audit requires V9 direct-diagnostic precipitation input'
    audit_precip_active=ANY(audit_rwp>0._wp).OR.ANY(audit_swp>0._wp)
  END IF
  IF(sw_policy/=1.AND.(TRIM(phase)/='SW'.OR..NOT.use_precip)) &
    ERROR STOP 'SW_POLICY override requires a SW replay with precipitation optics'
  IF(LEN_TRIM(override_path)>0.AND.TRIM(phase)/='SW') &
    ERROR STOP 'SW optics override requires an SW replay input'

  ALLOCATE(emissivity(16,nc),avdir(nc),avdif(nc),andir(nc),andif(nc),mu0(nc))
  ALLOCATE(zero(nc,nl),rl(nc,nl),di(nc,nl),ds(nc,nl))
  zero=0._wp
  IF(nemis==1) THEN
    emissivity=SPREAD(emis_in(:,1),1,16)
  ELSE IF(nemis==16) THEN
    emissivity=TRANSPOSE(emis_in)
  ELSE
    ERROR STOP 'EMIS section must be grey or have 16 bands'
  END IF
  avdir=avdir_in(:,1); avdif=avdif_in(:,1); andir=andir_in(:,1); andif=andif_in(:,1)
  mu0=mu0_in(:,1)
  IF(n2_override_requested) THEN
    CALL check_error(gases_lw%init(gas_names_lw_with_n2))
  ELSE
    CALL check_error(gases_lw%init(gas_names_lw))
  END IF
  CALL check_error(gases_sw%init(gas_names_sw))
  CALL load_and_init(gas_lw,TRIM(data_dir)//'/rrtmgp-gas-lw-g128.nc',gases_lw)
  CALL load_and_init(gas_sw,TRIM(data_dir)//'/rrtmgp-gas-sw-g112.nc',gases_sw)
  CALL load_cld_lutcoeff(cloud_lw,TRIM(data_dir)//'/rrtmgp-clouds-lw-bnd.nc')
  CALL load_cld_lutcoeff(cloud_sw,TRIM(data_dir)//'/rrtmgp-clouds-sw-bnd.nc')
  CALL check_error(cloud_lw%set_ice_roughness(ice_roughness))
  CALL check_error(cloud_sw%set_ice_roughness(ice_roughness))
  CALL check_error(gases_lw%set_vmr('h2o',h2o))
  CALL check_error(gases_lw%set_vmr('co2',co2))
  CALL check_error(gases_lw%set_vmr('o3',o3))
  CALL check_error(gases_lw%set_vmr('n2o',n2o))
  CALL check_error(gases_lw%set_vmr('ch4',ch4))
  CALL check_error(gases_lw%set_vmr('o2',o2))
  CALL check_error(gases_sw%set_vmr('h2o',h2o))
  CALL check_error(gases_sw%set_vmr('co2',co2))
  CALL check_error(gases_sw%set_vmr('o3',o3))
  CALL check_error(gases_sw%set_vmr('n2o',n2o))
  CALL check_error(gases_sw%set_vmr('ch4',ch4))
  CALL check_error(gases_sw%set_vmr('o2',o2))
  IF(.NOT.ALLOCATED(vmr_cfc11)) THEN
    ALLOCATE(vmr_cfc11(nc,nl),vmr_cfc12(nc,nl),vmr_cfc22(nc,nl),vmr_ccl4(nc,nl))
    vmr_cfc11=0._wp; vmr_cfc12=0._wp; vmr_cfc22=0._wp; vmr_ccl4=0._wp
  END IF
  CALL check_error(gases_lw%set_vmr('cfc11',vmr_cfc11))
  CALL check_error(gases_lw%set_vmr('cfc12',vmr_cfc12))
  CALL check_error(gases_lw%set_vmr('cfc22',vmr_cfc22))
  CALL check_error(gases_lw%set_vmr('ccl4',vmr_ccl4))
  IF(n2_override_requested) THEN
    ALLOCATE(vmr_n2(nc,nl)); vmr_n2=n2_override_vmr
    CALL check_error(gases_lw%set_vmr('n2',vmr_n2))
  END IF

  ! V1-V5 retain historical pressure-derived dry columns. V6/V7 replace the
  ! host-provided native prefix when that optional independent mass is present.
  ALLOCATE(col_dry(nc,nl))
  col_dry=get_col_dry(h2o,plev*100._wp)
  IF(has_native_mass) &
    col_dry(:,1:n_native)=native_dry_mass(:,1:n_native)*avogad/(m_dry*10000._wp)

  ALLOCATE(up_all(nc,nl+1),dn_all(nc,nl+1),hr_all(nc,nl))
  ALLOCATE(up_clear(nc,nl+1),dn_clear(nc,nl+1),hr_clear(nc,nl))
  ALLOCATE(fu(nc,nl+1),fd(nc,nl+1),heat(nc,nl))
  IF(TRIM(phase)=='LW') THEN
    ALLOCATE(gas_tau(nc,nl,gas_lw%get_ngpt()),cloud_tau(nc,nl,cloud_lw%get_nband()))
    ALLOCATE(mask(nc,nl,gas_lw%get_ngpt()),randoms(gas_lw%get_ngpt(),nl,nc))
    ALLOCATE(local_random(gas_lw%get_ngpt()))
    IF(use_precip) ALLOCATE(precip_tau(nc,nl,cloud_lw%get_nband()))
    CALL check_error(lw_atmos%alloc_1scl(nc,nl,gas_lw))
    CALL check_error(lw_cloud%alloc_1scl(nc,nl,cloud_lw))
    CALL check_error(lw_snow%alloc_1scl(nc,nl,cloud_lw))
    CALL check_error(lw_sampled%alloc_1scl(nc,nl,gas_lw))
    CALL check_error(lw_source%alloc(nc,nl,gas_lw))
    CALL check_error(gas_lw%gas_optics(play*100._wp,plev*100._wp,tlay,tsfc(:,1),gases_lw, &
                                      lw_atmos,lw_source,col_dry=col_dry,tlev=tlev))
    gas_tau=lw_atmos%tau
    emissivity=MAX(0._wp,MIN(1._wp,emissivity))
    lw_flux%flux_up=>fu; lw_flux%flux_dn=>fd
    IF(lw_transport_policy==2) THEN
      ALLOCATE(lw_ds_field(nc,gas_lw%get_ngpt())); lw_ds_field=1.66_wp
      CALL check_error(rte_lw(lw_atmos,.FALSE.,lw_source,emissivity,lw_flux,lw_Ds=lw_ds_field))
    ELSE IF(lw_transport_policy==3) THEN
      CALL check_error(rte_lw(lw_atmos,.FALSE.,lw_source,emissivity,lw_flux,n_gauss_angles=4))
    ELSE
      CALL check_error(rte_lw(lw_atmos,.FALSE.,lw_source,emissivity,lw_flux))
    END IF
    up_clear=fu; dn_clear=fd
    CALL check_error(compute_heating_rate(fu,fd,plev*100._wp,heat))
    hr_clear=heat*86400._wp
    rl=MAX(cloud_lw%get_min_radius_liq(),MIN(cloud_lw%get_max_radius_liq(),rel))
    di=MAX(cloud_lw%get_min_radius_ice(),MIN(cloud_lw%get_max_radius_ice(),ice_diameter(rei,iceflag)))
    ds=MAX(cloud_lw%get_min_radius_ice(),MIN(cloud_lw%get_max_radius_ice(),2._wp*res))
    IF(use_precip) ds=res ! V4 snow optics use native effective radius, not the cloud-ice LUT diameter.
    CALL check_error(cloud_lw%cloud_optics(lwp,iwp,rl,di,lw_cloud))
    IF(cu_population_enabled.AND..NOT.use_precip) THEN
      CALL check_error(cloud_lw%cloud_optics(zero,swp,rl,ds,lw_snow))
      CALL check_error(lw_snow%increment(lw_cloud))
    ELSE IF(.NOT.cu_population_enabled.AND..NOT.use_precip) THEN
      CALL check_error(cloud_lw%cloud_optics(zero,swp,rl,ds,lw_snow))
      CALL check_error(lw_snow%increment(lw_cloud))
    END IF
    IF(cu_population_enabled) THEN
      ALLOCATE(native_cu_tau(nc,nl,cloud_lw%get_nband()),cu_tau(nc,nl,cloud_lw%get_nband()))
      ALLOCATE(cu_rl_used(nc,nl),cu_di_used(nc,nl))
      native_cu_tau=lw_cloud%tau
      cu_rl_used=MAX(cloud_lw%get_min_radius_liq(),MIN(cloud_lw%get_max_radius_liq(),cu_rel))
      cu_di_used=MAX(cloud_lw%get_min_radius_ice(),MIN(cloud_lw%get_max_radius_ice(),2._wp*cu_rei))
      cu_tau=0._wp
      IF(cu_active) THEN
        CALL check_error(lw_cu%alloc_1scl(nc,nl,cloud_lw))
        CALL check_error(cloud_lw%cloud_optics(cu_lwp,cu_iwp,cu_rl_used,cu_di_used,lw_cu))
        cu_tau=lw_cu%tau
        CALL check_error(lw_cu%increment(lw_cloud))
      END IF
    END IF
    IF(use_precip) THEN
      CALL reference_lw_precip(rwp,swp,res,gas_lw%get_band_lims_wavenumber(),precip_tau)
      DO c=1,nc
        DO k=1,nl
          IF(cf(c,k)==0._wp) precip_tau(c,k,:)=0._wp
        END DO
      END DO
      CALL check_error(lw_precip%alloc_1scl(nc,nl,cloud_lw))
      lw_precip%tau=precip_tau
      CALL check_error(lw_precip%increment(lw_cloud))
    END IF
    cloud_tau=lw_cloud%tau
    ALLOCATE(prepared_tau(nc,nl,cloud_lw%get_nband()))
    prepared_tau=lw_cloud%tau
    CALL make_mask(cf,gas_lw%get_ngpt(),overlap,seed,mask,randoms,local_random)
    IF(ANY(cf>0._wp) .AND. overlap/=0) THEN
      CALL check_error(draw_samples(mask,lw_cloud,lw_sampled))
      CALL check_error(lw_sampled%increment(lw_atmos))
    END IF
    IF(audit_precip_active.AND.TRIM(phase)=='LW') THEN
      ALLOCATE(audit_tau(nc,nl,cloud_lw%get_nband()))
      CALL reference_lw_precip(audit_rwp,audit_swp,res,gas_lw%get_band_lims_wavenumber(),audit_tau)
      DO k=1,nl
        DO c=1,nc
          IF(audit_rwp(c,k)==0._wp.AND.audit_swp(c,k)==0._wp) audit_tau(c,k,:)=0._wp
        END DO
      END DO
      CALL check_error(lw_audit_precip%alloc_1scl(nc,nl,cloud_lw))
      lw_audit_precip%tau=audit_tau
      CALL check_error(lw_audit_precip%increment(lw_atmos))
    END IF
    IF(frozen_enabled) THEN
      ALLOCATE(frozen_gt(nc,nl,cloud_lw%get_nband()),frozen_ht(nc,nl,cloud_lw%get_nband()))
      ALLOCATE(frozen_tau(nc,nl,cloud_lw%get_nband()))
      CALL query_lw(FROZEN_GRAUPEL,REAL(lambda_g,real64),REAL(tlay,real64),REAL(gwp,real64), &
                   frozen_gt,frozen_status,frozen_message)
      IF(frozen_status/=0) THEN
        WRITE(*,'(A)') TRIM(frozen_message)
        ERROR STOP 'V7 frozen LW graupel query failed'
      END IF
      CALL query_lw(FROZEN_HAIL,REAL(lambda_h,real64),REAL(tlay,real64),REAL(hwp,real64), &
                   frozen_ht,frozen_status,frozen_message)
      IF(frozen_status/=0) THEN
        WRITE(*,'(A)') TRIM(frozen_message)
        ERROR STOP 'V7 frozen LW hail query failed'
      END IF
      CALL check_error(lw_frozen%alloc_1scl(nc,nl,cloud_lw))
      frozen_tau=REAL(frozen_gt+frozen_ht,wp)
      lw_frozen%tau=frozen_tau
      CALL check_error(lw_frozen%increment(lw_atmos))
    END IF
    IF(lw_transport_policy==2) THEN
      CALL check_error(rte_lw(lw_atmos,.FALSE.,lw_source,emissivity,lw_flux,lw_Ds=lw_ds_field))
    ELSE IF(lw_transport_policy==3) THEN
      CALL check_error(rte_lw(lw_atmos,.FALSE.,lw_source,emissivity,lw_flux,n_gauss_angles=4))
    ELSE
      CALL check_error(rte_lw(lw_atmos,.FALSE.,lw_source,emissivity,lw_flux))
    END IF
    up_all=fu; dn_all=fd
    CALL check_error(compute_heating_rate(fu,fd,plev*100._wp,heat))
    hr_all=heat*86400._wp
  ELSE
    ALLOCATE(gas_tau(nc,nl,gas_sw%get_ngpt()),gas_ssa(nc,nl,gas_sw%get_ngpt()),gas_g(nc,nl,gas_sw%get_ngpt()))
    ALLOCATE(cloud_tau(nc,nl,cloud_sw%get_nband()),cloud_ssa(nc,nl,cloud_sw%get_nband()), &
             cloud_g(nc,nl,cloud_sw%get_nband()))
    IF(use_precip) THEN
      ALLOCATE(precip_tau(nc,nl,cloud_sw%get_nband()),precip_ssa(nc,nl,cloud_sw%get_nband()), &
               precip_g(nc,nl,cloud_sw%get_nband()))
    END IF
    ALLOCATE(prepared_tau(nc,nl,cloud_sw%get_nband()),prepared_ssa(nc,nl,cloud_sw%get_nband()), &
             prepared_g(nc,nl,cloud_sw%get_nband()))
    ALLOCATE(mask(nc,nl,gas_sw%get_ngpt()),randoms(gas_sw%get_ngpt(),nl,nc))
    ALLOCATE(local_random(gas_sw%get_ngpt()),toa(nc,gas_sw%get_ngpt()))
    ALLOCATE(direct_all(nc,nl+1),diffuse_all(nc,nl+1),direct_clear(nc,nl+1))
    ALLOCATE(fdir(nc,nl+1))
    ALLOCATE(visdir(nc,nl+1),visdif(nc,nl+1),nirdir(nc,nl+1),nirdif(nc,nl+1))
    ALLOCATE(bands(2,gas_sw%get_nband()),flux_band_dn(nc,nl+1,gas_sw%get_nband()), &
             flux_band_dir(nc,nl+1,gas_sw%get_nband()))
    ALLOCATE(visible_weights(gas_sw%get_nband()))
    ALLOCATE(albdir(gas_sw%get_nband(),nc),albdif(gas_sw%get_nband(),nc))
    CALL check_error(sw_atmos%alloc_2str(nc,nl,gas_sw))
    CALL check_error(sw_cloud%alloc_2str(nc,nl,cloud_sw))
    CALL check_error(sw_snow%alloc_2str(nc,nl,cloud_sw))
    CALL check_error(sw_sampled%alloc_2str(nc,nl,gas_sw))
    CALL check_error(gas_sw%gas_optics(play*100._wp,plev*100._wp,tlay,gases_sw,sw_atmos,toa,col_dry=col_dry))
    gas_tau=sw_atmos%tau; gas_ssa=sw_atmos%ssa; gas_g=sw_atmos%g
    DO c=1,nc
      IF(SUM(toa(c,:))<=0._wp) ERROR STOP 'TOA solar spectrum integral must be positive'
      toa(c,:)=toa(c,:)*(REAL(solar,wp)/SUM(toa(c,:)))
    END DO
    bands=gas_sw%get_band_lims_wavenumber()
    IF(sw_direct_enabled) THEN
      IF(SIZE(v9_toa,1)/=nc.OR.SIZE(v9_toa,2)/=gas_sw%get_ngpt()) ERROR STOP 'V9 TOA_GPOINT shape mismatch'
      IF(ANY(SHAPE(v9_gas_tau)/=[nc,nl,gas_sw%get_ngpt()])) ERROR STOP 'V9 RAW_GAS_TAU shape mismatch'
      IF(ANY(SHAPE(v9_mask)/=[nc,nl,gas_sw%get_ngpt()])) ERROR STOP 'V9 MCICA_MASK shape mismatch'
      IF(ANY(SHAPE(v9_cloud_tau)/=[nc,nl,gas_sw%get_nband()])) ERROR STOP 'V9 RAW_CLOUD_TAU shape mismatch'
      IF(TRIM(magic)=='RRTMGP_REPLAY_V11') THEN
        IF(ANY(SHAPE(v11_native_cloud_tau)/=[nc,nl,gas_sw%get_nband()])) &
          ERROR STOP 'V11 RAW_NATIVE_CLOUD_TAU shape mismatch'
        IF(ANY(SHAPE(v11_cu_cloud_tau)/=[nc,nl,gas_sw%get_nband()])) &
          ERROR STOP 'V11 RAW_CU_CLOUD_TAU shape mismatch'
      END IF
      IF(ANY(SHAPE(v9_precip_tau)/=[nc,nl,gas_sw%get_nband()])) ERROR STOP 'V9 RAW_PRECIP_TAU shape mismatch'
      IF(ANY(SHAPE(v9_graupel_tau)/=[nc,nl,gas_sw%get_nband()])) ERROR STOP 'V9 RAW_GRAUPEL_TAU_EXT shape mismatch'
      IF(ANY(SHAPE(v9_hail_tau)/=[nc,nl,gas_sw%get_nband()])) ERROR STOP 'V9 RAW_HAIL_TAU_EXT shape mismatch'
      IF(ANY(SHAPE(v9_band_limits)/=[2,gas_sw%get_nband()])) ERROR STOP 'V9 BAND_LIMS_GPOINT shape mismatch'
      IF(ANY(SHAPE(v9_wavenumbers)/=SHAPE(bands))) ERROR STOP 'V9 BAND_LIMS_WAVENUMBER shape mismatch'
      IF(ANY(SHAPE(v9_visible)/=[gas_sw%get_nband(),1])) ERROR STOP 'V9 VISIBLE_WEIGHT shape mismatch'
      IF(ANY(v9_toa/=REAL(toa))) ERROR STOP 'V9 recorded TOA spectrum differs from independent gas optics'
      IF(ANY(v9_gas_tau/=REAL(gas_tau))) ERROR STOP 'V9 recorded gas optical depth differs from independent gas optics'
      band_limits_gpt=gas_sw%get_band_lims_gpoint(); gpoint_bands=gas_sw%get_gpoint_bands()
      IF(ANY(v9_band_limits/=REAL(band_limits_gpt,wp))) ERROR STOP 'V9 g-point band mapping mismatch'
      IF(ANY(v9_wavenumbers/=bands)) ERROR STOP 'V9 wavenumber bands mismatch'
      ALLOCATE(raw_cloud_tau_check(nc,nl,gas_sw%get_nband()), &
               raw_precip_tau_check(nc,nl,gas_sw%get_nband()))
      raw_cloud_tau_check=0._wp; raw_precip_tau_check=0._wp
      ALLOCATE(direct_predelta(nc,nl+1),directc_predelta(nc,nl+1), &
               visdir_predelta(nc,nl+1),nirdir_predelta(nc,nl+1), &
               direct_predelta_gpt(nc,nl+1,gas_sw%get_ngpt()), &
               direct_predelta_band(nc,nl+1,gas_sw%get_nband()))
      direct_predelta=0._wp; directc_predelta=0._wp; visdir_predelta=0._wp; nirdir_predelta=0._wp
      direct_predelta_gpt=0._wp; direct_predelta_band=0._wp
    END IF
    DO b=1,gas_sw%get_nband()
      IF((TRIM(magic)=='RRTMGP_REPLAY_V3'.OR.TRIM(magic)=='RRTMGP_REPLAY_V4'.OR. &
          TRIM(magic)=='RRTMGP_REPLAY_V5'.OR.TRIM(magic)=='RRTMGP_REPLAY_V6'.OR. &
          TRIM(magic)=='RRTMGP_REPLAY_V7'.OR.TRIM(magic)=='RRTMGP_REPLAY_V9'.OR. &
          TRIM(magic)=='RRTMGP_REPLAY_V11').AND. &
         bands(1,b)==12850._wp) THEN
        IF(bands(2,b)/=16000._wp) ERROR STOP 'unexpected transition-band upper limit'
        visible_weight=0.5_wp
        albdir(b,:)=0.5_wp*(andir+avdir); albdif(b,:)=0.5_wp*(andif+avdif)
      ELSE IF(bands(1,b)>=12850._wp) THEN
        visible_weight=1._wp
        albdir(b,:)=avdir; albdif(b,:)=avdif
      ELSE
        visible_weight=0._wp
        albdir(b,:)=andir; albdif(b,:)=andif
      END IF
      visible_weights(b)=visible_weight
      IF(sw_direct_enabled) THEN
        IF(v9_visible(b,1)/=visible_weight) ERROR STOP 'V9 visible/NIR band weights mismatch'
      END IF
    END DO
    sw_flux%flux_up=>fu; sw_flux%flux_dn=>fd; sw_flux%flux_dn_dir=>fdir
    sw_flux%bnd_flux_dn=>flux_band_dn; sw_flux%bnd_flux_dn_dir=>flux_band_dir
    CALL check_error(rte_sw(sw_atmos,.FALSE.,mu0,toa,albdir,albdif,sw_flux))
    up_clear=fu; dn_clear=fd; direct_clear=fdir
    CALL check_error(compute_heating_rate(fu,fd,plev*100._wp,heat))
    hr_clear=heat*86400._wp
    rl=MAX(cloud_sw%get_min_radius_liq(),MIN(cloud_sw%get_max_radius_liq(),rel))
    di=MAX(cloud_sw%get_min_radius_ice(),MIN(cloud_sw%get_max_radius_ice(),ice_diameter(rei,iceflag)))
    ds=MAX(cloud_sw%get_min_radius_ice(),MIN(cloud_sw%get_max_radius_ice(),2._wp*res))
    IF(use_precip) ds=res ! V4 snow optics use native effective radius, not the cloud-ice LUT diameter.
    CALL check_error(cloud_sw%cloud_optics(lwp,iwp,rl,di,sw_cloud))
    IF(cu_population_enabled.AND..NOT.use_precip) THEN
      CALL check_error(cloud_sw%cloud_optics(zero,swp,rl,ds,sw_snow))
      CALL check_error(sw_snow%increment(sw_cloud))
    END IF
    IF(cu_population_enabled) THEN
      ALLOCATE(native_cu_tau(nc,nl,cloud_sw%get_nband()),native_cu_ssa(nc,nl,cloud_sw%get_nband()), &
               native_cu_g(nc,nl,cloud_sw%get_nband()),cu_tau(nc,nl,cloud_sw%get_nband()), &
               cu_ssa(nc,nl,cloud_sw%get_nband()),cu_g(nc,nl,cloud_sw%get_nband()), &
               cu_rl_used(nc,nl),cu_di_used(nc,nl))
      native_cu_tau=sw_cloud%tau; native_cu_ssa=sw_cloud%ssa; native_cu_g=sw_cloud%g
      cu_rl_used=MAX(cloud_sw%get_min_radius_liq(),MIN(cloud_sw%get_max_radius_liq(),cu_rel))
      cu_di_used=MAX(cloud_sw%get_min_radius_ice(),MIN(cloud_sw%get_max_radius_ice(),2._wp*cu_rei))
      cu_tau=0._wp; cu_ssa=0._wp; cu_g=0._wp
      IF(cu_active) THEN
        CALL check_error(sw_cu%alloc_2str(nc,nl,cloud_sw))
        CALL check_error(cloud_sw%cloud_optics(cu_lwp,cu_iwp,cu_rl_used,cu_di_used,sw_cu))
        cu_tau=sw_cu%tau; cu_ssa=sw_cu%ssa; cu_g=sw_cu%g
        CALL check_error(sw_cu%increment(sw_cloud))
      END IF
    END IF
    IF(TRIM(magic)=='RRTMGP_REPLAY_V11') THEN
      IF(ANY(v11_native_cloud_tau/=native_cu_tau)) &
        ERROR STOP 'V11 RAW_NATIVE_CLOUD_TAU differs from independent native optics'
      IF(ANY(v11_cu_cloud_tau/=cu_tau)) &
        ERROR STOP 'V11 RAW_CU_CLOUD_TAU differs from independent CU optics'
      IF(ANY(v9_cloud_tau/=REAL(REAL(v11_native_cloud_tau+v11_cu_cloud_tau),wp))) &
        ERROR STOP 'V11 RAW_CLOUD_TAU differs from binary32 component sum'
    END IF
    IF(sw_direct_enabled) raw_cloud_tau_check=sw_cloud%tau
    IF(use_precip) THEN
      IF(sw_policy==1) CALL check_error(sw_cloud%delta_scale())
      IF(sw_direct_enabled) THEN
        CALL reference_sw_precip(rwp,swp,res,bands,precip_tau,precip_ssa,precip_g, &
                                 delta_scaled=(sw_policy/=3),raw_tau_out=raw_precip_tau_check)
        DO b=1,gas_sw%get_nband()
          WHERE(rwp==0._wp.AND.swp==0._wp)
            raw_precip_tau_check(:,:,b)=0._wp
          END WHERE
        END DO
      ELSE
        CALL reference_sw_precip(rwp,swp,res,bands,precip_tau,precip_ssa,precip_g, &
                                 delta_scaled=(sw_policy/=3))
      END IF
      DO c=1,nc
        DO k=1,nl
          IF(cf(c,k)==0._wp) THEN
            precip_tau(c,k,:)=0._wp
            precip_ssa(c,k,:)=0._wp
            precip_g(c,k,:)=0._wp
          END IF
        END DO
      END DO
      CALL check_error(sw_precip%alloc_2str(nc,nl,cloud_sw))
      sw_precip%tau=precip_tau
      sw_precip%ssa=precip_ssa
      sw_precip%g=precip_g
      CALL check_error(sw_precip%increment(sw_cloud))
      IF(sw_policy==3) CALL check_error(sw_cloud%delta_scale())
      cloud_tau=sw_cloud%tau; cloud_ssa=sw_cloud%ssa; cloud_g=sw_cloud%g
    ELSE IF(.NOT.cu_population_enabled) THEN
      CALL check_error(cloud_sw%cloud_optics(zero,swp,rl,ds,sw_snow))
      CALL check_error(sw_snow%increment(sw_cloud))
      cloud_tau=sw_cloud%tau; cloud_ssa=sw_cloud%ssa; cloud_g=sw_cloud%g
      IF(sw_direct_enabled) raw_cloud_tau_check=sw_cloud%tau
      CALL check_error(sw_cloud%delta_scale())
    ELSE
      cloud_tau=sw_cloud%tau; cloud_ssa=sw_cloud%ssa; cloud_g=sw_cloud%g
      IF(sw_direct_enabled) raw_cloud_tau_check=sw_cloud%tau
      CALL check_error(sw_cloud%delta_scale())
    END IF
    IF(LEN_TRIM(override_path)>0) &
      CALL apply_sw_optics_override(TRIM(override_path),gas_sw,sw_cloud)
    prepared_tau=sw_cloud%tau; prepared_ssa=sw_cloud%ssa; prepared_g=sw_cloud%g
    CALL make_mask(cf,gas_sw%get_ngpt(),overlap,seed,mask,randoms,local_random)
    IF(sw_direct_enabled) THEN
      IF(ANY(v9_mask/=REAL(MERGE(1._wp,0._wp,mask)))) ERROR STOP 'V9 recorded MCICA mask differs from independent seed'
      IF(ANY(v9_cloud_tau/=REAL(raw_cloud_tau_check))) ERROR STOP 'V9 raw cloud tau differs from independent optics'
      IF(ANY(v9_precip_tau/=REAL(raw_precip_tau_check))) ERROR STOP 'V9 raw precipitation tau differs from independent optics'
    END IF
    IF(ANY(cf>0._wp) .AND. overlap/=0) THEN
      CALL check_error(draw_samples(mask,sw_cloud,sw_sampled))
      CALL check_error(sw_sampled%increment(sw_atmos))
    END IF
    IF(audit_precip_active.AND.TRIM(phase)=='SW') THEN
      ALLOCATE(audit_tau(nc,nl,cloud_sw%get_nband()),audit_ssa(nc,nl,cloud_sw%get_nband()), &
               audit_g(nc,nl,cloud_sw%get_nband()),audit_tau_raw(nc,nl,cloud_sw%get_nband()))
      CALL reference_sw_precip(audit_rwp,audit_swp,res,bands,audit_tau,audit_ssa,audit_g, &
                               delta_scaled=.TRUE.,raw_tau_out=audit_tau_raw)
      DO k=1,nl
        DO c=1,nc
          IF(audit_rwp(c,k)==0._wp.AND.audit_swp(c,k)==0._wp) THEN
            audit_tau(c,k,:)=0._wp; audit_ssa(c,k,:)=0._wp
            audit_g(c,k,:)=0._wp; audit_tau_raw(c,k,:)=0._wp
          END IF
        END DO
      END DO
      CALL check_error(sw_audit_precip%alloc_2str(nc,nl,cloud_sw))
      sw_audit_precip%tau=audit_tau; sw_audit_precip%ssa=audit_ssa; sw_audit_precip%g=audit_g
      CALL check_error(sw_audit_precip%increment(sw_atmos))
    END IF
    IF(TRIM(magic)=='RRTMGP_REPLAY_V7'.OR. &
       ((TRIM(magic)=='RRTMGP_REPLAY_V9'.OR.TRIM(magic)=='RRTMGP_REPLAY_V11').AND.frozen_enabled)) THEN
      ALLOCATE(frozen_gt(nc,nl,cloud_sw%get_nband()),frozen_gw(nc,nl,cloud_sw%get_nband()), &
               frozen_gmg(nc,nl,cloud_sw%get_nband()),frozen_ht(nc,nl,cloud_sw%get_nband()), &
               frozen_hw(nc,nl,cloud_sw%get_nband()),frozen_hmg(nc,nl,cloud_sw%get_nband()))
      ALLOCATE(frozen_tau(nc,nl,cloud_sw%get_nband()),frozen_ssa(nc,nl,cloud_sw%get_nband()), &
               frozen_g(nc,nl,cloud_sw%get_nband()))
      CALL query_sw(FROZEN_GRAUPEL,REAL(lambda_g,real64),REAL(gwp,real64), &
                    frozen_gt,frozen_gw,frozen_gmg,frozen_status,frozen_message)
      IF(frozen_status/=0) THEN
        WRITE(*,'(A)') TRIM(frozen_message)
        ERROR STOP 'V7 frozen SW graupel query failed'
      END IF
      CALL query_sw(FROZEN_HAIL,REAL(lambda_h,real64),REAL(hwp,real64), &
                    frozen_ht,frozen_hw,frozen_hmg,frozen_status,frozen_message)
      IF(frozen_status/=0) THEN
        WRITE(*,'(A)') TRIM(frozen_message)
        ERROR STOP 'V7 frozen SW hail query failed'
      END IF
      IF(sw_direct_enabled) THEN
        IF(ANY(v9_graupel_tau/=REAL(frozen_gt)).OR.ANY(v9_hail_tau/=REAL(frozen_ht))) &
          ERROR STOP 'V9 raw frozen extinction differs from independent table query'
      END IF
      CALL check_error(sw_frozen%alloc_2str(nc,nl,cloud_sw))
      frozen_tau=REAL(frozen_gt+frozen_ht,wp)
      frozen_ssa=REAL((frozen_gw+frozen_hw)/MAX(frozen_gt+frozen_ht,TINY(1._real64)),wp)
      frozen_g=REAL((frozen_gmg+frozen_hmg)/MAX(frozen_gw+frozen_hw,TINY(1._real64)),wp)
      sw_frozen%tau=frozen_tau; sw_frozen%ssa=frozen_ssa; sw_frozen%g=frozen_g
      CALL check_error(sw_frozen%delta_scale())
      frozen_tau=sw_frozen%tau; frozen_ssa=sw_frozen%ssa; frozen_g=sw_frozen%g
      CALL check_error(sw_frozen%increment(sw_atmos))
    ELSE IF(sw_direct_enabled) THEN
      IF(ANY(v9_graupel_tau/=0._wp).OR.ANY(v9_hail_tau/=0._wp)) &
        ERROR STOP 'V9 raw frozen extinction must be zero when frozen optics are disabled'
    END IF
    CALL check_error(rte_sw(sw_atmos,.FALSE.,mu0,toa,albdir,albdif,sw_flux))
    up_all=fu; dn_all=fd; direct_all=fdir; diffuse_all=fd-fdir
    CALL check_error(compute_heating_rate(fu,fd,plev*100._wp,heat))
    hr_all=heat*86400._wp
    visdir=0._wp; visdif=0._wp; nirdir=0._wp; nirdif=0._wp
    DO b=1,gas_sw%get_nband()
      visible_weight=MERGE(1._wp,0._wp,bands(1,b)>=12850._wp)
      IF((TRIM(magic)=='RRTMGP_REPLAY_V3'.OR.TRIM(magic)=='RRTMGP_REPLAY_V4'.OR. &
          TRIM(magic)=='RRTMGP_REPLAY_V5'.OR.TRIM(magic)=='RRTMGP_REPLAY_V6'.OR. &
          TRIM(magic)=='RRTMGP_REPLAY_V7'.OR.TRIM(magic)=='RRTMGP_REPLAY_V9'.OR. &
          TRIM(magic)=='RRTMGP_REPLAY_V11').AND. &
         bands(1,b)==12850._wp) visible_weight=0.5_wp
      visdir=visdir+visible_weight*flux_band_dir(:,:,b)
      visdif=visdif+visible_weight*(flux_band_dn(:,:,b)-flux_band_dir(:,:,b))
      nirdir=nirdir+(1._wp-visible_weight)*flux_band_dir(:,:,b)
      nirdif=nirdif+(1._wp-visible_weight)*(flux_band_dn(:,:,b)-flux_band_dir(:,:,b))
    END DO
    IF(sw_direct_enabled) THEN
      directc_predelta=direct_clear
      IF(audit_precip_active) THEN
        ALLOCATE(audit_direct(nc,nl+1),audit_direct_gpt(nc,nl+1,gas_sw%get_ngpt()))
        audit_direct=0._wp; audit_direct_gpt=0._wp
      END IF
      DO c=1,nc
        DO g=1,gas_sw%get_ngpt()
          direct_predelta_gpt(c,nl+1,g)=toa(c,g)*mu0(c)
          IF(audit_precip_active) audit_direct_gpt(c,nl+1,g)=toa(c,g)*mu0(c)
          b=gpoint_bands(g)
          DO k=nl,1,-1
            raw_direct_tau=gas_tau(c,k,g)
            IF(overlap/=0.AND.mask(c,k,g)) &
              raw_direct_tau=raw_direct_tau+raw_cloud_tau_check(c,k,b)+raw_precip_tau_check(c,k,b)
            IF(frozen_enabled) raw_direct_tau=raw_direct_tau+REAL(frozen_gt(c,k,b)+frozen_ht(c,k,b),wp)
            IF(.NOT.ieee_is_finite(raw_direct_tau)) ERROR STOP 'V9 reference direct extinction is non-finite'
            IF(raw_direct_tau<0._wp) ERROR STOP 'V9 reference direct extinction is negative'
            direct_predelta_gpt(c,k,g)=direct_predelta_gpt(c,k+1,g)*EXP(-raw_direct_tau/mu0(c))
            IF(audit_precip_active) THEN
              raw_direct_tau=raw_direct_tau+audit_tau_raw(c,k,b)
              IF(.NOT.ieee_is_finite(raw_direct_tau).OR.raw_direct_tau<0._wp) &
                ERROR STOP 'audit direct extinction is invalid'
              audit_direct_gpt(c,k,g)=audit_direct_gpt(c,k+1,g)*EXP(-raw_direct_tau/mu0(c))
            END IF
          END DO
          DO k=1,nl+1
            direct_predelta_band(c,k,b)=direct_predelta_band(c,k,b)+direct_predelta_gpt(c,k,g)
          END DO
        END DO
      END DO
      DO k=1,nl+1
        direct_predelta(:,k)=SUM(direct_predelta_gpt(:,k,:),DIM=2)
        IF(audit_precip_active) audit_direct(:,k)=SUM(audit_direct_gpt(:,k,:),DIM=2)
        DO b=1,gas_sw%get_nband()
          visdir_predelta(:,k)=visdir_predelta(:,k)+visible_weights(b)*direct_predelta_band(:,k,b)
          nirdir_predelta(:,k)=nirdir_predelta(:,k)+(1._wp-visible_weights(b))*direct_predelta_band(:,k,b)
        END DO
      END DO
    END IF
  END IF

  ALLOCATE(mask_values(nc,nl,SIZE(mask,3)))
  WHERE(mask)
    mask_values=1._wp
  ELSEWHERE
    mask_values=0._wp
  END WHERE

  OPEN(NEWUNIT=u_out,FILE=TRIM(output_path),STATUS='REPLACE',ACTION='WRITE',IOSTAT=ios)
  IF(ios/=0) ERROR STOP 'could not open reference output file'
  WRITE(u_out,'(A)') 'RRTMGP_RESULT_V1'
  WRITE(u_out,'(A,1X,I0,1X,I0)') TRIM(phase),nc,nl
  CALL write3(u_out,'GAS_COL_DRY',RESHAPE(col_dry,[nc,nl,1]))
  CALL write3(u_out,'GAS_TAU',gas_tau)
  IF(TRIM(magic)=='RRTMGP_REPLAY_V8'.OR.TRIM(magic)=='RRTMGP_REPLAY_V10') &
    CALL write3(u_out,'GAS_TAU_RAW',gas_tau)
  IF(TRIM(phase)=='SW') THEN
    CALL write3(u_out,'GAS_SSA',gas_ssa); CALL write3(u_out,'GAS_G',gas_g)
  END IF
  IF(use_precip) THEN
    CALL write3(u_out,'PRECIP_TAU',precip_tau)
    IF(TRIM(phase)=='SW') THEN
      CALL write3(u_out,'PRECIP_SSA',precip_ssa); CALL write3(u_out,'PRECIP_G',precip_g)
    END IF
  END IF
  CALL write3(u_out,'CLOUD_TAU',cloud_tau)
  IF(cu_population_enabled) THEN
    CALL write3(u_out,'NATIVE_CLOUD_TAU',native_cu_tau)
    CALL write3(u_out,'CU_CLOUD_TAU',cu_tau)
    CALL write3(u_out,'CU_RL_USED',RESHAPE(cu_rl_used,[nc,nl,1]))
    CALL write3(u_out,'CU_DI_USED',RESHAPE(cu_di_used,[nc,nl,1]))
  END IF
  IF(TRIM(phase)=='SW') THEN
    CALL write3(u_out,'CLOUD_SSA',cloud_ssa); CALL write3(u_out,'CLOUD_G',cloud_g)
    IF(cu_population_enabled) THEN
      CALL write3(u_out,'NATIVE_CLOUD_SSA',native_cu_ssa)
      CALL write3(u_out,'NATIVE_CLOUD_G',native_cu_g)
      CALL write3(u_out,'CU_CLOUD_SSA',cu_ssa)
      CALL write3(u_out,'CU_CLOUD_G',cu_g)
    END IF
  END IF
  IF(frozen_enabled) THEN
    IF(TRIM(phase)=='LW') THEN
      CALL write3(u_out,'GRAUPEL_TAU_ABS',REAL(frozen_gt,wp))
      CALL write3(u_out,'HAIL_TAU_ABS',REAL(frozen_ht,wp))
      CALL write3(u_out,'FROZEN_TAU',frozen_tau)
    ELSE
      CALL write3(u_out,'GRAUPEL_TAU_EXT',REAL(frozen_gt,wp))
      CALL write3(u_out,'GRAUPEL_TAU_SCA',REAL(frozen_gw,wp))
      CALL write3(u_out,'GRAUPEL_TAU_SCA_G',REAL(frozen_gmg,wp))
      CALL write3(u_out,'HAIL_TAU_EXT',REAL(frozen_ht,wp))
      CALL write3(u_out,'HAIL_TAU_SCA',REAL(frozen_hw,wp))
      CALL write3(u_out,'HAIL_TAU_SCA_G',REAL(frozen_hmg,wp))
      CALL write3(u_out,'FROZEN_TAU',frozen_tau)
      CALL write3(u_out,'FROZEN_SSA',frozen_ssa)
      CALL write3(u_out,'FROZEN_G',frozen_g)
    END IF
  END IF
  CALL write3(u_out,'PREPARED_TAU',prepared_tau)
  IF(TRIM(phase)=='SW') THEN
    CALL write3(u_out,'PREPARED_SSA',prepared_ssa); CALL write3(u_out,'PREPARED_G',prepared_g)
  END IF
  CALL write3(u_out,'MASK',mask_values)
  IF(TRIM(phase)=='LW') THEN
    CALL write3(u_out,'TOTAL_TAU',lw_atmos%tau)
  ELSE
    CALL write3(u_out,'TOTAL_TAU',sw_atmos%tau); CALL write3(u_out,'TOTAL_SSA',sw_atmos%ssa)
    CALL write3(u_out,'TOTAL_G',sw_atmos%g)
  END IF
  CALL write3(u_out,'RL_USED',RESHAPE(rl,[nc,nl,1]))
  CALL write3(u_out,'DI_USED',RESHAPE(di,[nc,nl,1]))
  CALL write3(u_out,'DS_USED',RESHAPE(ds,[nc,nl,1]))
  CALL write3(u_out,'UP',RESHAPE(up_all,[nc,nl+1,1]))
  CALL write3(u_out,'DN',RESHAPE(dn_all,[nc,nl+1,1]))
  CALL write3(u_out,'HR',RESHAPE(hr_all,[nc,nl,1]))
  CALL write3(u_out,'UPC',RESHAPE(up_clear,[nc,nl+1,1]))
  CALL write3(u_out,'DNC',RESHAPE(dn_clear,[nc,nl+1,1]))
  CALL write3(u_out,'HRC',RESHAPE(hr_clear,[nc,nl,1]))
  IF(TRIM(phase)=='SW') THEN
    CALL write3(u_out,'DIRECT',RESHAPE(direct_all,[nc,nl+1,1]))
    CALL write3(u_out,'DIFFUSE',RESHAPE(diffuse_all,[nc,nl+1,1]))
    CALL write3(u_out,'DIRECTC',RESHAPE(direct_clear,[nc,nl+1,1]))
    CALL write3(u_out,'VISDIR',RESHAPE(visdir,[nc,nl+1,1]))
    CALL write3(u_out,'VISDIF',RESHAPE(visdif,[nc,nl+1,1]))
    CALL write3(u_out,'NIRDIR',RESHAPE(nirdir,[nc,nl+1,1]))
    CALL write3(u_out,'NIRDIF',RESHAPE(nirdif,[nc,nl+1,1]))
    IF(sw_direct_enabled) THEN
      IF(audit_precip_active) THEN
        CALL write3(u_out,'AUDIT_EXTRA_PRECIP_TAU',audit_tau)
        CALL write3(u_out,'AUDIT_EXTRA_PRECIP_TAU_RAW',audit_tau_raw)
        CALL write3(u_out,'AUDIT_EXTRA_PRECIP_SSA',audit_ssa)
        CALL write3(u_out,'AUDIT_EXTRA_PRECIP_G',audit_g)
        CALL write3(u_out,'AUDIT_DIRECT_PREDELTA',RESHAPE(audit_direct,[nc,nl+1,1]))
      END IF
      CALL write3(u_out,'DIRECT_PREDELTA',RESHAPE(direct_predelta,[nc,nl+1,1]))
      CALL write3(u_out,'DIRECTC_PREDELTA',RESHAPE(directc_predelta,[nc,nl+1,1]))
      CALL write3(u_out,'VISDIR_PREDELTA',RESHAPE(visdir_predelta,[nc,nl+1,1]))
      CALL write3(u_out,'NIRDIR_PREDELTA',RESHAPE(nirdir_predelta,[nc,nl+1,1]))
    END IF
  END IF
  IF(audit_precip_active.AND.TRIM(phase)=='LW') &
    CALL write3(u_out,'AUDIT_EXTRA_PRECIP_TAU',audit_tau)
  CLOSE(u_out)
  IF(lw_transport_requested.AND.TRIM(phase)=='LW') CALL write_lw_transport_trace(TRIM(output_path)//'.lw_transport')

CONTAINS
  SUBROUTINE write_lw_transport_trace(path)
    CHARACTER(LEN=*), INTENT(IN) :: path
    INTEGER :: unit,stat
    INTEGER, ALLOCATABLE :: bounds(:,:)
    REAL(wp), ALLOCATABLE :: wn_bounds(:,:),policy_value(:,:,:),bounds_value(:,:,:)
    OPEN(NEWUNIT=unit,FILE=path,STATUS='NEW',ACTION='WRITE',IOSTAT=stat)
    IF(stat/=0) ERROR STOP 'could not create LW transport trace'
    WRITE(unit,'(A)',IOSTAT=stat) 'RRTMGP_RESULT_V1'
    IF(stat/=0) ERROR STOP 'failed LW transport result magic write'
    WRITE(unit,'(A,1X,I0,1X,I0)',IOSTAT=stat) 'LW',nc,nl
    IF(stat/=0) ERROR STOP 'failed LW transport trace dimensions write'
    ALLOCATE(policy_value(1,1,1)); policy_value(1,1,1)=REAL(lw_transport_policy,wp)
    CALL write3(unit,'TRANSPORT_POLICY',policy_value)
    CALL write3(unit,'SOURCE_LAYER',lw_source%lay_source)
    CALL write3(unit,'SOURCE_LEVEL',lw_source%lev_source)
    CALL write3(unit,'SOURCE_SURFACE',RESHAPE(lw_source%sfc_source,[nc,1,SIZE(lw_source%sfc_source,2)]))
    bounds=gas_lw%get_band_lims_gpoint()
    ALLOCATE(bounds_value(SIZE(bounds,1),SIZE(bounds,2),1))
    bounds_value(:,:,1)=REAL(bounds,wp)
    CALL write3(unit,'BAND_LIMITS_GPOINT',bounds_value)
    wn_bounds=gas_lw%get_band_lims_wavenumber()
    CALL write3(unit,'BAND_LIMITS_WAVENUMBER',RESHAPE(wn_bounds,[SIZE(wn_bounds,1),SIZE(wn_bounds,2),1]))
    IF(lw_transport_policy==2) THEN
      policy_value(1,1,1)=1.66_wp
      CALL write3(unit,'LW_DIFFUSIVITY_ANGLE',policy_value)
    ELSE IF(lw_transport_policy==3) THEN
      policy_value(1,1,1)=4._wp
      CALL write3(unit,'GAUSS_ANGLE_COUNT',policy_value)
    END IF
    IF(n2_override_requested) CALL write3(unit,'N2_OVERRIDE',RESHAPE([n2_override_vmr],[1,1,1]))
    CLOSE(unit,IOSTAT=stat)
    IF(stat/=0) ERROR STOP 'failed to close LW transport trace'
  END SUBROUTINE write_lw_transport_trace
  SUBROUTINE read_cf0_precip_sidecar(path,expected_phase,ncol,nlay,expected_native_n,cloud_fraction,rain,snow,native_n,species,occurrence)
    CHARACTER(LEN=*), INTENT(IN) :: path,expected_phase
    INTEGER, INTENT(IN) :: ncol,nlay,expected_native_n
    REAL(wp), INTENT(IN) :: cloud_fraction(ncol,nlay)
    REAL(wp), ALLOCATABLE, INTENT(OUT) :: rain(:,:),snow(:,:)
    INTEGER, INTENT(OUT) :: native_n,species
    REAL(wp), INTENT(OUT) :: occurrence
    CHARACTER(LEN=64) :: header,side_phase,section
    CHARACTER(LEN=256) :: line
    INTEGER :: unit,stat,file_ncol
    OPEN(NEWUNIT=unit,FILE=path,STATUS='OLD',ACTION='READ',IOSTAT=stat)
    IF(stat/=0) ERROR STOP 'cannot open CF0 precipitation sidecar'
    READ(unit,*,IOSTAT=stat) header
    IF(stat/=0) ERROR STOP 'failed to read audit sidecar magic'
    IF(TRIM(header)/='RRTMGP_CF0_PRECIP_AUDIT_V1') ERROR STOP 'invalid audit sidecar magic'
    READ(unit,*,IOSTAT=stat) side_phase,file_ncol,native_n,species,occurrence
    IF(stat/=0) ERROR STOP 'invalid audit sidecar header'
    IF(file_ncol/=1.OR.ncol/=1) ERROR STOP 'CF0 audit sidecar currently supports one column only'
    IF(TRIM(side_phase)/=expected_phase.OR.file_ncol/=ncol) ERROR STOP 'audit sidecar phase/column mismatch'
    IF(native_n<1.OR.native_n>nlay) ERROR STOP 'audit sidecar native layer count out of bounds'
    IF(expected_native_n>0.AND.native_n/=expected_native_n) ERROR STOP 'audit sidecar native depth differs from replay input'
    IF(species<1.OR.species>2) ERROR STOP 'audit sidecar species must be rain or snow'
    IF(ANY(.NOT.ieee_is_finite(cloud_fraction)).OR.ANY(cloud_fraction<0._wp).OR.ANY(cloud_fraction>1._wp)) &
      ERROR STOP 'audit cloud fraction must be finite and in [0,1]'
    IF(.NOT.ieee_is_finite(occurrence)) ERROR STOP 'audit occurrence must be finite'
    IF(occurrence/=1._wp) ERROR STOP 'audit sidecar occurrence must equal one'
    ALLOCATE(rain(ncol,nlay),snow(ncol,nlay)); rain=0._wp; snow=0._wp
    READ(unit,*,IOSTAT=stat) section
    IF(stat/=0) ERROR STOP 'failed to read audit sidecar path units'
    IF(TRIM(section)/='PATH_UNITS_G_M2') ERROR STOP 'audit sidecar path units must be g m-2'
    CALL read_cf0_native_section(unit,'AUDIT_RWP_GRID',ncol,nlay,native_n,rain)
    CALL read_cf0_native_section(unit,'AUDIT_SWP_GRID',ncol,nlay,native_n,snow)
    IF(species==1.AND.ANY(snow/=0._wp)) ERROR STOP 'rain audit must have zero snow path'
    IF(species==2.AND.ANY(rain/=0._wp)) ERROR STOP 'snow audit must have zero rain path'
    IF(ANY(.NOT.ieee_is_finite(rain)).OR.ANY(.NOT.ieee_is_finite(snow))) ERROR STOP 'audit paths must be finite'
    IF(ANY(rain<0._wp).OR.ANY(snow<0._wp)) ERROR STOP 'audit paths must be nonnegative'
    IF(ANY((rain>0._wp.OR.snow>0._wp).AND.cloud_fraction/=0._wp)) &
      ERROR STOP 'audit path is only permitted where CF is zero'
    READ(unit,'(A)',IOSTAT=stat) line
    IF(stat==0) ERROR STOP 'audit sidecar has trailing records'
    IF(stat/=iostat_end) ERROR STOP 'I/O error checking audit sidecar end-of-file'
    CLOSE(unit)
  END SUBROUTINE read_cf0_precip_sidecar

  SUBROUTINE read_cf0_native_section(unit,wanted,ncol,nlay,native_n,engine_array)
    INTEGER, INTENT(IN) :: unit,ncol,nlay,native_n
    CHARACTER(LEN=*), INTENT(IN) :: wanted
    REAL(wp), INTENT(INOUT) :: engine_array(ncol,nlay)
    CHARACTER(LEN=64) :: section_name
    INTEGER :: rows,cols,read_status
    REAL(wp), ALLOCATABLE :: native_values(:,:)
    READ(unit,*,IOSTAT=read_status) section_name,rows,cols
    IF(read_status/=0) ERROR STOP 'failed to read audit path section header'
    IF(TRIM(section_name)/=wanted) ERROR STOP 'audit sidecar section name/order mismatch'
    IF(rows/=ncol.OR.cols/=native_n) ERROR STOP 'audit sidecar must contain native-prefix shape only'
    ALLOCATE(native_values(rows,cols))
    READ(unit,*,IOSTAT=read_status) native_values
    IF(read_status/=0) ERROR STOP 'failed reading native audit path values'
    engine_array=0._wp
    engine_array(:,1:native_n)=native_values
    IF(ANY(engine_array(:,native_n+1:nlay)/=0._wp)) ERROR STOP 'audit engine padding must be zero'
    DEALLOCATE(native_values)
  END SUBROUTINE read_cf0_native_section
  SUBROUTINE apply_sw_optics_override(path,gas_optics,optical_props)
    USE, INTRINSIC :: iso_fortran_env, ONLY: error_unit
    CHARACTER(LEN=*), INTENT(IN) :: path
    TYPE(ty_gas_optics_rrtmgp), INTENT(IN) :: gas_optics
    TYPE(ty_optical_props_2str), INTENT(INOUT) :: optical_props
    CHARACTER(LEN=32) :: override_magic,section_name
    INTEGER :: unit,stat,ncol_file,nlay_file,nband_file,n1,n2,n3,iband,igpt,gpt_bounds(2,gas_optics%get_nband())
    REAL(wp) :: file_bands(2,gas_optics%get_nband()),core_bands(2,gas_optics%get_nband())
    LOGICAL :: known_legacy_split
    REAL(wp), ALLOCATABLE :: tau_band(:,:,:),ssa_band(:,:,:),asym_band(:,:,:)

    OPEN(NEWUNIT=unit,FILE=path,STATUS='OLD',ACTION='READ',IOSTAT=stat)
    IF(stat/=0) ERROR STOP 'could not open SW optics override file'
    READ(unit,*,IOSTAT=stat) override_magic
    IF(stat/=0) ERROR STOP 'could not read SW optics override magic'
    IF(TRIM(override_magic)/='WRF_SW_OPTICS_OVERRIDE_V1') ERROR STOP 'invalid SW optics override magic'
    READ(unit,*,IOSTAT=stat) ncol_file,nlay_file,nband_file
    IF(stat/=0) ERROR STOP 'could not read SW optics override dimensions'
    IF(ncol_file/=nc.OR.nlay_file/=nl.OR.nband_file/=gas_optics%get_nband()) &
      ERROR STOP 'SW optics override dimensions do not match replay/core'
    READ(unit,*,IOSTAT=stat) section_name,n1,n2
    IF(stat/=0) ERROR STOP 'could not read SW optics override BAND_LIMITS header'
    IF(TRIM(section_name)/='BAND_LIMITS'.OR.n1/=2.OR.n2/=nband_file) &
      ERROR STOP 'invalid SW optics override BAND_LIMITS header'
    READ(unit,*,IOSTAT=stat) file_bands
    IF(stat/=0) ERROR STOP 'could not read SW optics override BAND_LIMITS values'
    IF(ANY(.NOT.ieee_is_finite(file_bands))) ERROR STOP 'invalid SW optics override BAND_LIMITS values'
    IF(ANY(file_bands(2,:)<=file_bands(1,:))) &
      ERROR STOP 'SW optics override spectral bands must be finite and increasing'
    core_bands=gas_optics%get_band_lims_wavenumber()
    known_legacy_split=.FALSE.
    IF(nband_file==14) THEN
      known_legacy_split=ALL(ABS(file_bands(:,1)-[820._wp,2600._wp])<1.e-8_wp).AND. &
        ALL(ABS(file_bands(:,2)-[2600._wp,3250._wp])<1.e-8_wp).AND. &
        ALL(ABS(core_bands(:,1)-[820._wp,2680._wp])<1.e-8_wp).AND. &
        ALL(ABS(core_bands(:,2)-[2680._wp,3250._wp])<1.e-8_wp).AND. &
        ALL(ABS(file_bands(:,3:14)-core_bands(:,3:14))<1.e-8_wp)
    END IF
    IF(ANY(ABS(file_bands-core_bands)>1.e-8_wp).AND..NOT.known_legacy_split) &
      ERROR STOP 'SW optics override bands differ from pinned RRTMGP gas bands'
    IF(known_legacy_split) THEN
      WRITE(error_unit,'(A)') 'WARNING: mapping known RRTMG 2600 cm-1 split to RRTMGP 2680 cm-1 bands by index;'
      WRITE(error_unit,'(A)') '         this index mapping is not spectrally identical'
    END IF

    ALLOCATE(tau_band(ncol_file,nlay_file,nband_file), &
             ssa_band(ncol_file,nlay_file,nband_file), &
             asym_band(ncol_file,nlay_file,nband_file))
    CALL read_override_field(unit,'TAU',tau_band)
    CALL read_override_field(unit,'SSA',ssa_band)
    CALL read_override_field(unit,'ASYM',asym_band)
    READ(unit,*,IOSTAT=stat) section_name
    IF(stat==0) ERROR STOP 'unexpected trailing SW optics override data'
    CLOSE(unit)
    IF(ANY(.NOT.ieee_is_finite(tau_band))) ERROR STOP 'SW optics override TAU must be finite and nonnegative'
    IF(ANY(tau_band<0._wp)) ERROR STOP 'SW optics override TAU must be finite and nonnegative'
    IF(ANY(.NOT.ieee_is_finite(ssa_band))) ERROR STOP 'SW optics override SSA must be finite and in [0,1]'
    IF(ANY(ssa_band<0._wp).OR.ANY(ssa_band>1._wp)) ERROR STOP 'SW optics override SSA must be finite and in [0,1]'
    IF(ANY(.NOT.ieee_is_finite(asym_band))) ERROR STOP 'SW optics override ASYM must be finite and in [-1,1]'
    IF(ANY(asym_band< -1._wp).OR.ANY(asym_band>1._wp)) ERROR STOP 'SW optics override ASYM must be finite and in [-1,1]'

    IF(optical_props%get_nband()/=nband_file) ERROR STOP 'SW override band count differs from cloud optical properties'
    gpt_bounds=optical_props%get_band_lims_gpoint()
    IF(SIZE(optical_props%tau,1)/=ncol_file.OR.SIZE(optical_props%tau,2)/=nlay_file) &
      ERROR STOP 'SW optics override does not match allocated prepared optical properties'
    DO iband=1,nband_file
      IF(gpt_bounds(1,iband)<1.OR.gpt_bounds(2,iband)<gpt_bounds(1,iband).OR. &
         gpt_bounds(2,iband)>SIZE(optical_props%tau,3)) ERROR STOP 'invalid pinned SW gpoint band bounds'
      DO igpt=gpt_bounds(1,iband),gpt_bounds(2,iband)
        optical_props%tau(:,:,igpt)=tau_band(:,:,iband)
        optical_props%ssa(:,:,igpt)=ssa_band(:,:,iband)
        optical_props%g(:,:,igpt)=asym_band(:,:,iband)
      END DO
    END DO
  END SUBROUTINE apply_sw_optics_override

  SUBROUTINE read_override_field(unit,wanted,array)
    INTEGER, INTENT(IN) :: unit
    CHARACTER(LEN=*), INTENT(IN) :: wanted
    REAL(wp), INTENT(OUT) :: array(:,:,:)
    CHARACTER(LEN=32) :: got
    INTEGER :: n1,n2,n3,stat
    READ(unit,*,IOSTAT=stat) got,n1,n2,n3
    IF(stat/=0) ERROR STOP 'could not read SW optics override section header'
    IF(TRIM(got)/=TRIM(wanted).OR.n1/=SIZE(array,1).OR. &
       n2/=SIZE(array,2).OR.n3/=SIZE(array,3)) ERROR STOP 'SW optics override section name/shape mismatch'
    READ(unit,*,IOSTAT=stat) array
    IF(stat/=0) ERROR STOP 'failed to read SW optics override section values'
  END SUBROUTINE read_override_field

  SUBROUTINE read_section(unit,wanted,array)
    INTEGER, INTENT(IN) :: unit
    CHARACTER(LEN=*), INTENT(IN) :: wanted
    REAL(wp), INTENT(OUT) :: array(:,:)
    CHARACTER(LEN=32) :: got
    INTEGER :: rows,cols,stat
    READ(unit,*,IOSTAT=stat) got,rows,cols
    IF(stat/=0) ERROR STOP 'failed to read replay section header'
    IF(TRIM(got)/=TRIM(wanted) .OR. rows/=SIZE(array,1) .OR. cols/=SIZE(array,2)) &
      ERROR STOP 'replay section name or shape mismatch'
    READ(unit,*,IOSTAT=stat) array
    IF(stat/=0) ERROR STOP 'failed to read replay section values'
  END SUBROUTINE

  SUBROUTINE read_section2_alloc(unit,wanted,array)
    INTEGER, INTENT(IN) :: unit
    CHARACTER(LEN=*), INTENT(IN) :: wanted
    REAL(wp), ALLOCATABLE, INTENT(OUT) :: array(:,:)
    CHARACTER(LEN=64) :: got
    INTEGER :: rows,cols,stat
    READ(unit,*,IOSTAT=stat) got,rows,cols
    IF(stat/=0) ERROR STOP 'failed to read dynamic rank2 section header'
    IF(TRIM(got)/=TRIM(wanted).OR.rows<1.OR.cols<1) ERROR STOP 'dynamic rank2 section shape/name invalid'
    ALLOCATE(array(rows,cols))
    READ(unit,*,IOSTAT=stat) array
    IF(stat/=0) ERROR STOP 'failed to read dynamic rank2 section values'
  END SUBROUTINE

  SUBROUTINE read_section3_alloc(unit,wanted,array)
    INTEGER, INTENT(IN) :: unit
    CHARACTER(LEN=*), INTENT(IN) :: wanted
    REAL(wp), ALLOCATABLE, INTENT(OUT) :: array(:,:,:)
    CHARACTER(LEN=64) :: got
    INTEGER :: n1,n2,n3,stat
    READ(unit,*,IOSTAT=stat) got,n1,n2,n3
    IF(stat/=0) ERROR STOP 'failed to read dynamic rank3 section header'
    IF(TRIM(got)/=TRIM(wanted).OR.MIN(n1,n2,n3)<1) ERROR STOP 'dynamic rank3 section shape/name invalid'
    ALLOCATE(array(n1,n2,n3))
    READ(unit,*,IOSTAT=stat) array
    IF(stat/=0) ERROR STOP 'failed to read dynamic rank3 section values'
  END SUBROUTINE

  SUBROUTINE read_section_flexible(unit,wanted,array,ncols_read)
    INTEGER, INTENT(IN) :: unit
    CHARACTER(LEN=*), INTENT(IN) :: wanted
    REAL(wp), INTENT(INOUT) :: array(:,:)
    INTEGER, INTENT(OUT) :: ncols_read
    CHARACTER(LEN=32) :: got
    INTEGER :: rows,cols,stat
    READ(unit,*,IOSTAT=stat) got,rows,cols
    IF(stat/=0) ERROR STOP 'failed to read replay section header'
    IF(TRIM(got)/=TRIM(wanted) .OR. rows/=SIZE(array,1) .OR. cols<1 .OR. cols>SIZE(array,2)) &
      ERROR STOP 'replay section name or shape mismatch'
    ncols_read=cols
    array=0._wp
    READ(unit,*,IOSTAT=stat) array(:,1:cols)
    IF(stat/=0) ERROR STOP 'failed to read replay section values'
  END SUBROUTINE

  SUBROUTINE read_scalar_section(unit,wanted,value)
    INTEGER, INTENT(IN) :: unit
    CHARACTER(LEN=*), INTENT(IN) :: wanted
    REAL(wp), INTENT(OUT) :: value
    CHARACTER(LEN=32) :: got
    INTEGER :: rows,cols,stat
    READ(unit,*,IOSTAT=stat) got,rows,cols
    IF(stat/=0) ERROR STOP 'failed to read scalar section header'
    IF(TRIM(got)/=TRIM(wanted) .OR. rows/=1 .OR. cols/=1) ERROR STOP 'scalar section shape mismatch'
    READ(unit,*,IOSTAT=stat) value
    IF(stat/=0) ERROR STOP 'failed to read scalar section value'
  END SUBROUTINE

  SUBROUTINE write3(unit,name,array)
    INTEGER, INTENT(IN) :: unit
    CHARACTER(LEN=*), INTENT(IN) :: name
    REAL(wp), INTENT(IN) :: array(:,:,:)
    INTEGER :: stat
    WRITE(unit,'(A,1X,I0,1X,I0,1X,I0)') TRIM(name),SIZE(array,1),SIZE(array,2),SIZE(array,3)
    WRITE(unit,'(*(ES25.16E3,1X))',IOSTAT=stat) array
    IF(stat/=0) ERROR STOP 'failed to write result array'
  END SUBROUTINE

  SUBROUTINE check_error(message)
    CHARACTER(LEN=*), INTENT(IN) :: message
    IF(LEN_TRIM(message)>0) THEN
      WRITE(*,'(A)') TRIM(message)
      ERROR STOP 'reference RRTMGP/RTE call failed'
    END IF
  END SUBROUTINE

  FUNCTION ice_diameter(radius,flag) RESULT(diameter)
    REAL(wp), INTENT(IN) :: radius(:,:)
    INTEGER, INTENT(IN) :: flag
    REAL(wp) :: diameter(SIZE(radius,1),SIZE(radius,2))
    diameter=2._wp*radius
    IF(flag==3) diameter=diameter/1.0315_wp
  END FUNCTION

  SUBROUTINE reference_lw_precip(rain_path,snow_path,snow_radius,band_limits,tau)
    ! Independent replay implementation copied from the pinned public CCPP
    ! RRTMGP source commit 3e6660c6df54e95a0871e990c2294dd397ae3860.
    ! It intentionally does not call module_ra_rrtmgp_precip; results validate
    ! array assembly and core/RTE replay, but not the shared source formula.
    REAL(wp), INTENT(IN) :: rain_path(:,:),snow_path(:,:),snow_radius(:,:),band_limits(:,:)
    REAL(wp), INTENT(OUT) :: tau(:,:,:)
    REAL(wp), PARAMETER :: expected(2,16)=RESHAPE([ &
      10._wp,250._wp,250._wp,500._wp,500._wp,630._wp,630._wp,700._wp, &
      700._wp,820._wp,820._wp,980._wp,980._wp,1080._wp,1080._wp,1180._wp, &
      1180._wp,1390._wp,1390._wp,1480._wp,1480._wp,1800._wp,1800._wp,2080._wp, &
      2080._wp,2250._wp,2250._wp,2390._wp,2390._wp,2680._wp,2680._wp,3250._wp], [2,16])
    REAL(wp) :: tau_rain,tau_snow
    INTEGER :: col,lev
    IF(SIZE(tau,1)/=SIZE(rain_path,1).OR.SIZE(tau,2)/=SIZE(rain_path,2).OR.SIZE(tau,3)/=16) &
      ERROR STOP 'invalid LW precipitation optics shape'
    IF(ANY(SHAPE(rain_path)/=SHAPE(snow_path)).OR.ANY(SHAPE(rain_path)/=SHAPE(snow_radius))) &
      ERROR STOP 'LW precipitation inputs have inconsistent shapes'
    IF(ANY(SHAPE(band_limits)/=SHAPE(expected)).OR.ANY(band_limits/=expected)) &
      ERROR STOP 'LW precipitation bands differ from pinned CCPP order'
    IF(ANY(.NOT.ieee_is_finite(rain_path)).OR.ANY(.NOT.ieee_is_finite(snow_path)).OR. &
       ANY(.NOT.ieee_is_finite(snow_radius))) ERROR STOP 'LW precipitation inputs must be finite'
    IF(ANY(rain_path<0._wp).OR.ANY(snow_path<0._wp)) &
      ERROR STOP 'LW precipitation paths must be nonnegative'
    IF(ANY(snow_path>0._wp.AND.snow_radius<=0._wp)) ERROR STOP 'active snow radius must be positive'
    DO lev=1,SIZE(rain_path,2)
      DO col=1,SIZE(rain_path,1)
        tau_rain=0.33E-3_wp*rain_path(col,lev)
        tau_snow=0._wp
        IF(snow_path(col,lev)>0._wp.AND.snow_radius(col,lev)>10._wp) &
          tau_snow=1.5_wp*1.05756_wp*snow_path(col,lev)/snow_radius(col,lev)
        tau(col,lev,:)=tau_rain+tau_snow
      END DO
    END DO
  END SUBROUTINE reference_lw_precip

  SUBROUTINE reference_sw_precip(rain_path,snow_path,snow_radius,band_limits,tau,ssa,asymmetry,delta_scaled,raw_tau_out)
    ! See the source/validation-scope note above reference_lw_precip.
    REAL(wp), INTENT(IN) :: rain_path(:,:),snow_path(:,:),snow_radius(:,:),band_limits(:,:)
    REAL(wp), INTENT(OUT) :: tau(:,:,:),ssa(:,:,:),asymmetry(:,:,:)
    LOGICAL, OPTIONAL, INTENT(IN) :: delta_scaled
    REAL(wp), OPTIONAL, INTENT(OUT) :: raw_tau_out(:,:,:)
    REAL(wp), PARAMETER :: expected(2,14)=RESHAPE([ &
      820._wp,2680._wp,2680._wp,3250._wp,3250._wp,4000._wp,4000._wp,4650._wp, &
      4650._wp,5150._wp,5150._wp,6150._wp,6150._wp,7700._wp,7700._wp,8050._wp, &
      8050._wp,12850._wp,12850._wp,16000._wp,16000._wp,22650._wp,22650._wp,29000._wp, &
      29000._wp,38000._wp,38000._wp,50000._wp], [2,14])
    ! The upstream tables assign default-real literals into kind(wp) arrays;
    ! preserve that conversion order for exact parity with the pinned source.
    REAL(wp), PARAMETER :: b0r(14)=[.496,.466,.437,.416,.391,.374,.352, &
      .183,.048,.012,0.,0.,0.,0.]
    REAL(wp), PARAMETER :: b0s(14)=[.460,.460,.460,.460,.460,.460,.460, &
      .460,0.,0.,0.,0.,0.,0.]
    REAL(wp), PARAMETER :: b1s(14)=[0.,0.,0.,0.,0.,0.,0.,0., &
      1.62E-5,1.62E-5,0.,0.,0.,0.]
    REAL(wp), PARAMETER :: c0r(14)=[.980,.975,.965,.960,.955,.952,.950, &
      .944,.894,.884,.883,.883,.883,.883]
    REAL(wp), PARAMETER :: c0s(14)=[.970,.970,.970,.970,.970,.970,.970, &
      .970,.970,.970,.700,.700,.700,.700]
    REAL(wp) :: tau_rain,tau_snow,ssa_rain,ssa_snow,asy_rain,asy_snow
    REAL(wp) :: tau_prec,ssa_prec,asy_prec,asyw,ssaw,za1,za2
    LOGICAL :: apply_delta
    INTEGER :: col,lev,band
    apply_delta=.TRUE.
    IF(PRESENT(delta_scaled)) apply_delta=delta_scaled
    IF(SIZE(tau,1)/=SIZE(rain_path,1).OR.SIZE(tau,2)/=SIZE(rain_path,2).OR.SIZE(tau,3)/=14) &
      ERROR STOP 'invalid SW precipitation optics shape'
    IF(ANY(SHAPE(ssa)/=SHAPE(tau)).OR.ANY(SHAPE(asymmetry)/=SHAPE(tau))) &
      ERROR STOP 'SW precipitation optics output shapes differ'
    IF(PRESENT(raw_tau_out)) THEN
      IF(ANY(SHAPE(raw_tau_out)/=SHAPE(tau))) ERROR STOP 'SW raw precipitation output shapes differ'
      raw_tau_out=0._wp
    END IF
    IF(ANY(SHAPE(rain_path)/=SHAPE(snow_path)).OR.ANY(SHAPE(rain_path)/=SHAPE(snow_radius))) &
      ERROR STOP 'SW precipitation inputs have inconsistent shapes'
    IF(ANY(SHAPE(band_limits)/=SHAPE(expected)).OR.ANY(band_limits/=expected)) &
      ERROR STOP 'SW precipitation bands differ from pinned CCPP coefficient order'
    IF(ANY(.NOT.ieee_is_finite(rain_path)).OR.ANY(.NOT.ieee_is_finite(snow_path)).OR. &
       ANY(.NOT.ieee_is_finite(snow_radius))) ERROR STOP 'SW precipitation inputs must be finite'
    IF(ANY(rain_path<0._wp).OR.ANY(snow_path<0._wp)) &
      ERROR STOP 'SW precipitation paths must be nonnegative'
    IF(ANY(snow_path>0._wp.AND.snow_radius<=0._wp)) ERROR STOP 'active snow radius must be positive'
    DO lev=1,SIZE(rain_path,2)
      DO col=1,SIZE(rain_path,1)
        tau_rain=rain_path(col,lev)*3.07E-3_wp
        tau_snow=0._wp
        IF(snow_path(col,lev)>0._wp.AND.snow_radius(col,lev)>10._wp) &
          tau_snow=snow_path(col,lev)*1.09087_wp*(1.5_wp/(1.0315_wp*snow_radius(col,lev)))
        DO band=1,14
          ssa_rain=tau_rain*(1._wp-b0r(band))
          asy_rain=ssa_rain*c0r(band)
          ssa_snow=tau_snow*(1._wp-(b0s(band)+b1s(band)*1.0315_wp*snow_radius(col,lev)))
          asy_snow=ssa_snow*c0s(band)
          tau_prec=MAX(1.E-12_wp,tau_rain+tau_snow)
          IF(PRESENT(raw_tau_out)) raw_tau_out(col,lev,band)=tau_prec
          ssa_prec=MAX(1.E-12_wp,ssa_rain+ssa_snow)
          asy_prec=MAX(1.E-12_wp,asy_rain+asy_snow)
          asyw=asy_prec/MAX(1.E-12_wp,ssa_prec)
          ssaw=MIN(1._wp-1.E-6_wp,ssa_prec/tau_prec)
          IF(apply_delta) THEN
            za1=asyw*asyw
            za2=ssaw*za1
            tau(col,lev,band)=(1._wp-za2)*tau_prec
            ssa(col,lev,band)=(ssaw-za2)/(1._wp-za2)
            asymmetry(col,lev,band)=asyw/(1._wp+asyw)
          ELSE
            tau(col,lev,band)=tau_prec
            ssa(col,lev,band)=ssaw
            asymmetry(col,lev,band)=asyw
          END IF
        END DO
      END DO
    END DO
  END SUBROUTINE reference_sw_precip

  SUBROUTINE make_mask(frac,npoint,mode,base_seed,cloud_mask,rand,local)
    REAL(wp), INTENT(IN) :: frac(:,:)
    INTEGER, INTENT(IN) :: npoint,mode,base_seed
    LOGICAL, INTENT(OUT) :: cloud_mask(SIZE(frac,1),SIZE(frac,2),npoint)
    REAL(wp), INTENT(OUT) :: rand(npoint,SIZE(frac,2),SIZE(frac,1))
    REAL(wp), INTENT(OUT) :: local(:)
    INTEGER :: col,lev,point,first,last
    LOGICAL :: is_cloud(SIZE(frac,2))
    INTEGER(i8) :: state
    state=MODULO(INT(base_seed,i8),2147483646_i8)+1_i8
    DO col=1,SIZE(frac,1)
      DO lev=1,SIZE(frac,2)
        DO point=1,npoint
          state=MODULO(48271_i8*state,2147483647_i8)
          rand(point,lev,col)=REAL(state,wp)/2147483647._wp
        END DO
      END DO
    END DO
    SELECT CASE(mode)
    CASE(0)
      cloud_mask=.FALSE.
    CASE(2)
      DO col=1,SIZE(frac,1)
        is_cloud=frac(col,:)>0._wp
        IF(.NOT.ANY(is_cloud)) THEN
          cloud_mask(col,:,:)=.FALSE.
          CYCLE
        END IF
        first=FINDLOC(is_cloud,.TRUE.,DIM=1)
        last=FINDLOC(is_cloud,.TRUE.,DIM=1,BACK=.TRUE.)
        cloud_mask(col,1:first-1,:)=.FALSE.
        local=rand(:,first,col)
        cloud_mask(col,first,:)=local>1._wp-frac(col,first)
        DO lev=first+1,last
          IF(is_cloud(lev)) THEN
            IF(.NOT.is_cloud(lev-1)) local=rand(:,lev,col)
            cloud_mask(col,lev,:)=local>1._wp-frac(col,lev)
          ELSE
            cloud_mask(col,lev,:)=.FALSE.
          END IF
        END DO
        cloud_mask(col,last+1:SIZE(frac,2),:)=.FALSE.
      END DO
    CASE(1,3)
      DO col=1,SIZE(frac,1)
        DO lev=1,SIZE(frac,2)
          DO point=1,npoint
            IF(mode==3) THEN
              cloud_mask(col,lev,point)=rand(point,1,col)>1._wp-frac(col,lev)
            ELSE
              cloud_mask(col,lev,point)=rand(point,lev,col)>1._wp-frac(col,lev)
            END IF
          END DO
        END DO
      END DO
    CASE DEFAULT
      ERROR STOP 'overlap must be one of 0,1,2,3'
    END SELECT
  END SUBROUTINE
END PROGRAM rrtmgp_reference_column
