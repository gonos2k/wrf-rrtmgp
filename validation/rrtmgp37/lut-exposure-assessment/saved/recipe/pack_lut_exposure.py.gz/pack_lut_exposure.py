from pathlib import Path
import gzip,json,hashlib,netCDF4,numpy as np,shutil
r=Path.cwd();b=r/'validation/rrtmgp37/lut-exposure-assessment';saved=b/'saved';saved.mkdir(exist_ok=True)
sha=lambda x:hashlib.sha256(x).hexdigest()
def save(n,x):
 p=saved/(n+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(x,mtime=0))
def file(n,p):save(n,Path(p).read_bytes())
def js(n,v):save(n,(json.dumps(v,indent=2)+'\n').encode())
# Exact prior histories/coefficients already live in sealed PR181 / PR180 packages.
prior={}
for n in ['host/day_00.json','host/day_00.bin','host/day_11.json','host/day_11.bin']:
 p=r/'validation/rrtmgp37/sustained-research/saved'/(n+'.gz');prior[n]={'path':str(p.relative_to(r)),'gzip_sha256':sha(p.read_bytes())}
for ph in ['lw','sw']:
 p=r/'validation/rrtmgp37/native-radiation-capacity/saved/coefficients'/(ph+'.json.gz');prior['coefficients/'+ph+'.json']={'path':str(p.relative_to(r)),'gzip_sha256':sha(p.read_bytes())}
(b/'prior-evidence.json').write_text(json.dumps(prior,indent=2)+'\n')
for dirname,targets in [('udm37-lut-exposure-captures-v1',['night_peak','day_peak']),('udm37-lut-exposure-low-capture-v1',['low_peak'])]:
 d=r.parent/dirname
 for p in d.glob('command-*'):file('host/'+dirname+'/'+p.name,p)
 for n in ['plan.json','receipt.json']:file('host/'+dirname+'/'+n,d/n)
 for target in targets:
  case=d/target
  for p in (case/'capture').iterdir():file('capture/'+target+'/'+p.name,p)
  file('host/'+target+'.namelist',case/'namelist.input')
for dirname in ['udm37-lut-attribution-v1','udm37-lut-attribution-low-v1']:
 d=r.parent/dirname;rec=json.loads((d/'receipt.json').read_text())
 for p in d.glob('command-*'):file('driver/'+dirname+'/'+p.name,p)
 for n in ['plan.json','receipt.json']:file('driver/'+dirname+'/'+n,d/n)
 for row in rec['scenarios']:
  case=d/row['case']
  file('attribution/'+case.name+'/input.dat',case/'input.dat')
  for p in (case/'capture').iterdir():file('attribution/'+case.name+'/'+p.name,p)
for version in ['v1','v2']:
 d=r.parent/('udm37-lut-water-observer-'+version)
 for p in d.glob('command-*'):file('observer/'+version+'/'+p.name,p)
 for n in ['receipt.json','solve_em.F']:file('observer/'+version+'/'+n,d/n)
d=r.parent/'udm37-lut-water-window-v1'
for p in d.glob('command-*.json'):file('water/'+p.name,p)
for n in ['plan.json','receipt.json']:file('water/'+n,d/n)
for idx,name in [(1,'window_00'),(2,'window_11')]:
 file('water/'+name+'.stdout',d/f'command-{idx:02d}.stdout')
 file('water/'+name+'.stderr',d/f'command-{idx:02d}.stderr')
 file('water/'+name+'.namelist',d/name/'namelist.input')
for n in ['capture_lut_targets.py','capture_lut_low.py','run_lut_attribution.py','run_lut_low_attribution.py','build_lut_water_observer.py','build_lut_water_observer_v2.py','run_lut_water_window.py','pack_lut_exposure.py']:
 file('recipe/'+n,'/tmp/'+n)
def packet(name,path):
 data=bytearray();rows=[]
 with netCDF4.Dataset(path) as nc:
  attrs={key:int(nc.getncattr(key)) for key in ('UDM_NUMBER_POLICY','UDM_POPULATION_POLICY','RRTMGP_CAPACITY_POLICY','RRTMGP_LIQUID_SIZE_POLICY')}
  for name0,var in nc.variables.items():
   if 'Time' not in var.dimensions:continue
   values=np.asarray(var[:]);raw=values.tobytes();rows.append({'variable':name0,'dtype':values.dtype.str,'shape':list(values.shape),'offset':len(data),'bytes':len(raw),'sha256':sha(raw),'units':getattr(var,'units','')});data.extend(raw)
 js('history/'+name+'.json',{'source_NetCDF_sha256':sha(path.read_bytes()),'attrs':attrs,'records':rows,'payload_sha256':sha(data)});save('history/'+name+'.bin',data)
for dirname,names in [('udm37-lut-exposure-captures-v1',['night_peak','day_peak']),('udm37-lut-exposure-low-capture-v1',['low_peak']),('udm37-lut-water-window-v1',['window_00','window_11'])]:
 for name in names:packet(name,next((r.parent/dirname/name).glob('wrfout*')))
file('source/WRF/dyn_em/solve_em.F',r/'WRF/dyn_em/solve_em.F')
# Existing source baseline and build/library hashes; no historical hash overwritten.
old=json.loads((r/'validation/rrtmgp37/sustained-research/identity.json').read_text())
identity={'baseline_main':'36671629c460c013603e50991069a96f2e60ce78','baseline_tree':'ba4d273fd48b79996804cdc7f0f35a621035fe96','source_files':old['source_files'],'runtime_source_changed':False,'defaults_changed':False,'normal_WRF_executable':old['execution'],'new_targeted_WRF_processes':5,'new_public_column_processes':15,'new_full_WRF_builds':0,'Fortran_compilations':3,'observer_build_versions':{'v1':'Compiled but never executed; log-window refinement only','v2':'Read-only solve_em observer compiled against current PR180 normal-build modules; all 214 Time arrays match original continuous run at all common outputs'},'seven_conditions_changed':False,'production_accepted':False,'component_removal_is_clipping_error_estimate':False}
identity['source_files']['WRF/dyn_em/solve_em.F']=sha((r/'WRF/dyn_em/solve_em.F').read_bytes())
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
shutil.copy2(r/'validation/rrtmgp37/sustained-research/closure-conditions.json',b/'closure-conditions.json')
print('packed',len(list(saved.rglob('*.gz'))),'files')
