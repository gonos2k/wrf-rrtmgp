from pathlib import Path
import sys,importlib.util,json,os,shlex
r=Path.cwd();sys.path.insert(0,str(r/'WRF/test/rrtmgp'))
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
h=load(r/'WRF/test/rrtmgp/test_netcdf_zz.py','runner');p=load(r/'validation/rrtmgp37/radiation-occurrence-runtime/verify_saved.py','parser')
build=r.parent/'udm37-radiation-options-build-v1';out=r.parent/'udm37-lut-attribution-v1';out.mkdir(exist_ok=False)
env=dict(os.environ,LD_LIBRARY_PATH=str(r.parent/'deps/netcdf/lib')+':'+os.environ.get('LD_LIBRARY_PATH',''),OMP_NUM_THREADS='1')
for k in list(env):
 if k.startswith(('WRF_RRTMGP_','WRF_UDM_','WRF_RESEARCH_','WRF_RADIATION_ENERGY')):env.pop(k)
runner=h.Runner(out,120,env,12)
link=shlex.split((build/'producer/main/CMakeFiles/wrf.dir/link.txt').read_text());libs=[]
for x in link:
 if x.endswith(('.a','.so')):
  z=Path(x) if x.startswith('/') else (build/'producer/main'/x).resolve();libs.append(str(z))
cmd=['gfortran','-O2','-ffree-line-length-none','-I'+str(build/'install/modules'),'-I'+str(build/'producer/external/rte_rrtmgp/modules'),str(r/'WRF/test/rrtmgp/lut_path_attribution.f90'),'-o',str(out/'attribution'),'-Wl,--start-group',*libs,'-Wl,--end-group']
receipt={'schema':'LUT_PUBLIC_COLUMN_ATTRIBUTION_V1','source':h.pin(r/'WRF/test/rrtmgp/lut_path_attribution.f90'),'unchanged_library':h.pin(build/'producer/libWRF_Core.a'),'scenarios':[],'production_accepted':False}
h.write_json(out/'plan.json',receipt)
runner.run(cmd,out,'compile_diagnostic_caller')
for name,phase in [('night_peak','lw'),('day_peak','lw'),('day_peak','sw')]:
 cap=r.parent/'udm37-lut-exposure-captures-v1'/name/'capture'
 header,inp=p.trace((cap/(phase+'.input')).read_bytes(),'input');_,raw=p.trace((cap/(phase+'.raw')).read_bytes(),'raw');_,res=p.trace((cap/(phase+'.result')).read_bytes(),'result')
 # The fixed-format header holds phase,nc,nl,overlap,seed,iceflag.
 words=(cap/(phase+'.input')).read_text().splitlines()[1].split();ph=words[0];nl=int(words[2]);nn=len(raw['SOURCE_QC']['values'])
 for mode in ['baseline','omit_high','omit_low']:
  d=out/(name+'_'+phase+'_'+mode);d.mkdir();(d/'capture').mkdir()
  field=lambda n:inp[n]['values'][:]
  L=field('LWP');ul=raw['UNIFORM_CF0_LWP']['values'][:]+[0.]*(nl-nn);ur=raw['UNIFORM_CF0_RWP']['values'][:]+[0.]*(nl-nn)
  removed=[]
  if mode!='baseline':
   for k,rr in enumerate(field('REL')[:nn]):
    if (mode=='omit_high' and rr>21.5) or (mode=='omit_low' and rr<2.5):L[k]=0.;ul[k]=0.;removed.append(k+1)
  arrays=[field(n) for n in ['PLAY','PLEV','TLAY']]
  arrays += [field('TLEV') if 'TLEV' in inp else [0.]*(nl+1), field('TSFC') if 'TSFC' in inp else [0.],field('EMIS') if 'EMIS' in inp else [0.]]
  arrays += [field(n) for n in ['H2O','CO2','O3','N2O','CH4','O2']]
  arrays += [field(n) if n in inp else [0.]*nl for n in ['VMR_CFC11','VMR_CFC12','VMR_CFC22','VMR_CCL4']]
  arrays += [field('CF'),L,field('IWP'),field('SWP'),field('RWP'),field('REL'),field('REI'),field('RES'),field('NATIVE_DRY_LAYER_MASS_KG_M2'),ul,ur,res['NATIVE_CAPACITY_J_M2_K']['values']]
  arrays += [field(n) for n in ['AVDIR','AVDIF','ANDIR','ANDIF','MU0']]
  vals=[ph,str(nl),str(nn),words[4],words[3],words[5],str(int(field('ICE_ROUGHNESS')[0]))]
  text=' '.join(vals)+'\n'+' '.join(format(field(n)[0],'.17e') for n in ['GRAVITY','CP_DRY','MOL_WEIGHT_DRY','SOLAR'])+'\n'
  text+='\n'.join(' '.join(format(x,'.17e') for x in a) for a in arrays)+'\n';(d/'input.dat').write_text(text)
  runner.environment.update(WRF_RRTMGP_CAPTURE_DIR=str(d/'capture'),WRF_RRTMGP_CAPTURE_CALL='1')
  log=runner.run([out/'attribution',r/'WRF/run',d/'input.dat'],d,d.name).read_text();assert 'LUT_PATH_ATTRIBUTION_COMPLETE' in log
  _,got=p.trace((d/'capture'/(phase+'.result')).read_bytes(),'result')
  if mode=='baseline':
   for n in ['UP','DN','HR','UPC','DNC','HRC','UP_WP','DN_WP','HEAT_WP_K_S','RL_USED','MASK','CLOUD_TAU','CLOUD_SSA','CLOUD_G']:
    if n in res:assert got[n]==res[n],(name,phase,n)
  receipt['scenarios'].append({'case':d.name,'phase':phase,'mode':mode,'removed_native_levels':removed,'input':h.pin(d/'input.dat'),'baseline_capture':h.pin(cap/(phase+'.result'))})
  receipt['processes']=runner.commands;h.write_json(out/'receipt.json',receipt)
  print(d.name,'removed',removed,flush=True)
