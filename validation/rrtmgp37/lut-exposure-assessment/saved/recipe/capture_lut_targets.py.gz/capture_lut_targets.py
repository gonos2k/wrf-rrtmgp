from pathlib import Path
import sys,importlib.util,json,os,shutil,datetime as dt
import netCDF4,numpy as np
r=Path.cwd();sys.path.insert(0,str(r/'WRF/test/rrtmgp'))
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
h=load(r/'WRF/test/rrtmgp/test_netcdf_zz.py','runner');setup=load(r/'WRF/test/rrtmgp/test_udm_startup_snow_scm.py','setup')
out=r.parent/'udm37-lut-exposure-captures-v1';out.mkdir(exist_ok=False)
old=r.parent/'udm37-sustained-v2/day/day_11';exe=r.parent/'udm37-radiation-options-build-v1/producer/main/wrf'
assert h.pin(exe)['sha256']=='2e1f099ea0a0629ceb1dbc5868dece8658666bd7a82a509473feb5789cb75e41'
env=dict(os.environ,OMP_NUM_THREADS='1',LD_LIBRARY_PATH=str(r.parent/'deps/netcdf/lib')+':'+os.environ.get('LD_LIBRARY_PATH',''))
for k in list(env):
 if k.startswith(('WRF_RRTMGP_','WRF_UDM_','WRF_RESEARCH_','WRF_RADIATION_ENERGY')):env.pop(k)
runner=h.Runner(out,900,env,2);epoch=dt.datetime(1999,10,22,19)
targets=[{'name':'night_peak','checkpoint_s':43220,'source_s':54300,'i':2,'j':1},{'name':'day_peak','checkpoint_s':64830,'source_s':65100,'i':1,'j':2}]
receipt={'schema':'LUT_TARGETED_CAPTURE_V1','executable':h.pin(exe),'selection':'Maximum outside-grid-path history time at night/day, then maximum outside-grid-path column at that time, from retained 11; no atmospheric adjustment','targets':targets,'production_accepted':False}
h.write_json(out/'plan.json',receipt)
for x in targets:
 d=out/x['name'];d.mkdir()
 for p in old.iterdir():
  if p.is_file() and not p.name.startswith(('wrfout','wrfrst','rsl.','udm_')) and p.name not in ('stdout.log','namelist.output'):shutil.copy2(p,d/p.name)
 cp=old/('wrfrst_d01_'+(epoch+dt.timedelta(seconds=x['checkpoint_s'])).strftime('%Y-%m-%d_%H:%M:%S'));shutil.copy2(cp,d/cp.name)
 start=epoch+dt.timedelta(seconds=x['checkpoint_s']);end=epoch+dt.timedelta(seconds=x['source_s']+10);seconds=int((end-start).total_seconds())
 settings={'run_days':0,'run_hours':seconds//3600,'run_minutes':seconds%3600//60,'run_seconds':seconds%60,'restart':'.true.','write_hist_at_0h_rst':'.true.','restart_interval_s':0,'override_restart_timers':'.true.','history_begin_s':(-x['checkpoint_s'])%300}
 for pref,time in [('start',start),('end',end)]:
  for part in ('year','month','day','hour','minute','second'):settings[pref+'_'+part]=getattr(time,part)
 text=(old/'namelist.input').read_text()
 for k,v in settings.items():text=setup.set_assignment(text,k,str(v),group='time_control')
 (d/'namelist.input').write_text(text);(d/'capture').mkdir()
 next_call=((x['checkpoint_s']+29)//30)*30;ordinal=(x['source_s']-next_call)//30+1;x['capture_ordinal']=ordinal
 runner.environment.update(WRF_RRTMGP_CAPTURE_DIR=str(d/'capture'),WRF_RRTMGP_CAPTURE_CALL=str(ordinal),WRF_RRTMGP_BATCH_SIZE='1',WRF_RRTMGP_COLUMN_I=str(x['i']),WRF_RRTMGP_COLUMN_J=str(x['j']))
 log=runner.run([exe],d,x['name']).read_text();assert 'SUCCESS COMPLETE WRF' in log and 'FATAL CALLED' not in log
 with netCDF4.Dataset(next(old.glob('wrfout*'))) as a,netCDF4.Dataset(next(d.glob('wrfout*'))) as b:
  ta=netCDF4.chartostring(a['Times'][:]).tolist();tb=netCDF4.chartostring(b['Times'][:]).tolist();common=sorted(set(ta)&set(tb));assert common
  eq=[]
  for n in a.variables:
   if 'Time' not in a[n].dimensions:continue
   assert all(np.asarray(a[n][ta.index(t)]).tobytes()==np.asarray(b[n][tb.index(t)]).tobytes() for t in common),(x['name'],n)
   eq.append(n)
  x['history_overlap_times']=len(common);x['history_arrays_bit_equal']=len(eq)
 x['checkpoint']=h.pin(cp);x['namelist']=h.pin(d/'namelist.input');receipt['processes']=runner.commands;h.write_json(out/'receipt.json',receipt)
 print(x['name'],ordinal,len(common),len(eq),flush=True)
