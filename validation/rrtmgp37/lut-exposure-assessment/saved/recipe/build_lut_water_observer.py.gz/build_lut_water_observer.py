from pathlib import Path
import re,os,shlex,shutil,importlib.util
r=Path.cwd();b=r.parent/'udm37-lut-water-observer-v1';b.mkdir(exist_ok=False);old=r.parent/'udm37-radiation-options-build-v1/producer';src=(r.parent/'udm37-budget-observer-v2/solve_em.F').read_text()
fields=['-(grid%c1h(k)*(grid%mu_1(i,j)+grid%mub(i,j))+grid%c2h(k))*grid%dnw(k)/g','-(grid%c1h(k)*(grid%mu_2(i,j)+grid%mub(i,j))+grid%c2h(k))*grid%dnw(k)/g','-(grid%c1h(k)*grid%mut(i,j)+grid%c2h(k))*grid%dnw(k)/g','moist(i,k,j,P_QV)','moist(i,k,j,P_QC)','moist(i,k,j,P_QR)','grid%rqvblten(i,k,j)','grid%rqcblten(i,k,j)','grid%qfx(i,j)','p8w(i,k,j)','p8w(i,k+1,j)','grid%aclhf(i,j)','grid%dt','grid%rho(i,k,j)','dz8w(i,k,j)']
def block(tag):
 s='! BUDGET_OBSERVER_BEGIN\n udm_budget_env=""\n call get_environment_variable("WRF_UDM_BUDGET",udm_budget_env)\n if(trim(udm_budget_env)=="1") then\n do j=jds,jde-1\n do k=kds,kde-1\n do i=ids,ide-1\n'
 s+=f' write(*,\'(a,5(i0,1x),15(es24.16,1x))\') "WQ_{tag} ",grid%itimestep,rk_step,i,j,k, &\n'+', &\n'.join(' real('+x+',8)' for x in fields)+'\n enddo\n enddo\n enddo\n endif\n! BUDGET_OBSERVER_END\n';return s
anchor='       CALL first_rk_step_part2 (';assert src.count(anchor)==1;src=src.replace(anchor,block('PBL')+anchor)
anchor='   END DO Runge_Kutta_loop';src=src.replace(anchor+'\n',anchor+'\n'+block('RK_END'))
# Scalar update reports the actual coupled old/new mass and both source terms.
sf=['-(grid%c1h(k)*(grid%mu_1(i,j)+grid%mub(i,j))+grid%c2h(k))*grid%dnw(k)/g','-(grid%c1h(k)*(grid%mu_2(i,j)+grid%mub(i,j))+grid%c2h(k))*grid%dnw(k)/g','moist_old(i,k,j,im)','moist(i,k,j,im)','moist_tend(i,k,j,im)','advect_tend(i,k,j)','dt_rk','grid%msfty(i,j)','-grid%dnw(k)/g','grid%qfx(i,j)']
def scalar(tag):
 s='! BUDGET_OBSERVER_BEGIN\n udm_budget_env=""\n call get_environment_variable("WRF_UDM_BUDGET",udm_budget_env)\n if(trim(udm_budget_env)=="1" .and. (im==P_QV.or.im==P_QC.or.im==P_QR)) then\n do j=jds,jde-1\n do k=kds,kde-1\n do i=ids,ide-1\n'
 s+=f' write(*,\'(a,6(i0,1x),10(es24.16,1x))\') "SQ_{tag} ",grid%itimestep,rk_step,im,i,j,k, &\n'+', &\n'.join(' real('+x+',8)' for x in sf)+'\n enddo\n enddo\n enddo\n endif\n! BUDGET_OBSERVER_END\n';return s
anchor='               CALL rk_update_scalar( scs=im, sce=im,';assert src.count(anchor)==1;src=src.replace(anchor,scalar('PRE')+anchor)
anchor='               IF( rk_step == rk_order .AND. config_flags%use_q_diabatic == 1 )THEN';assert src.count(anchor)==1;src=src.replace(anchor,scalar('POST')+anchor)
anchor='           CALL rk_update_scalar_pd( im, im,'
assert src.count(anchor)>=1
src=src.replace(anchor,scalar('PD_PRE')+anchor,1)
pos=src.index(anchor);end=src.index('                                     k_start    , k_end                       )',pos)+len('                                     k_start    , k_end                       )\n')
src=src[:end]+scalar('PD_POST')+src[end:]
assert re.sub(r'! BUDGET_OBSERVER_BEGIN\n.*?! BUDGET_OBSERVER_END\n','',src,flags=re.S)==(r/'WRF/dyn_em/solve_em.F').read_text()
def narrow(match):
 block=match.group(0)
 # Preserve only records from accepted physical steps [84900,85200].
 block=block.replace('if(trim(udm_budget_env)=="1") then','if(trim(udm_budget_env)=="1" .and. grid%itimestep>=8491 .and. grid%itimestep<=8520) then')
 block=block.replace('if(trim(udm_budget_env)=="1" .and.', 'if(trim(udm_budget_env)=="1" .and. grid%itimestep>=8491 .and. grid%itimestep<=8520 .and.') if 'im==P_QV' in block else block
 return block
src=re.sub(r'! BUDGET_OBSERVER_BEGIN\n.*?! BUDGET_OBSERVER_END\n',narrow,src,flags=re.S)
assert re.sub(r'! BUDGET_OBSERVER_BEGIN\n.*?! BUDGET_OBSERVER_END\n','',src,flags=re.S)==(r/'WRF/dyn_em/solve_em.F').read_text()
(b/'solve_em.F').write_text(src);(b/'modules').mkdir();s=importlib.util.spec_from_file_location('h',r/'WRF/test/rrtmgp/test_netcdf_zz.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);runner=h.Runner(b,240,dict(os.environ),3)
flags=(old/'CMakeFiles/WRF_Core.dir/flags.make').read_text();args=[]
for key in ['Fortran_DEFINES','Fortran_INCLUDES','Fortran_FLAGS']:args+=shlex.split(re.search('^'+key+r' = (.*)$',flags,re.M).group(1))
args=[x for x in args if not x.startswith('-J')]+['-J'+str(b/'modules')]
runner.run(['/usr/bin/gfortran',*args,'-ffree-form','-cpp','-O2','-ftree-vectorize','-funroll-loops','-ffree-line-length-none','-fallow-argument-mismatch','-fallow-invalid-boz','-c',b/'solve_em.F','-o',b/'solve_em.F.o'],b,'compile_readonly_source_observer')
shutil.copy2(old/'libWRF_Core.a',b/'libWRF_Core.a');runner.run(['ar','r',b/'libWRF_Core.a',b/'solve_em.F.o'],b,'replace_diagnostic_member')
args=shlex.split((old/'main/CMakeFiles/wrf.dir/link.txt').read_text());out=[];skip=False
for x in args:
 if skip:skip=False;continue
 if x.startswith('-Wl,--dependency-file='):continue
 if x=='-o':out+=['-o',str(b/'wrf')];skip=True
 elif x=='../libWRF_Core.a':out.append(str(b/'libWRF_Core.a'))
 elif x.endswith(('.a','.o')) and not x.startswith('/'):out.append(str((old/'main'/x).resolve()))
 else:out.append(x)
runner.run(out,b,'link_source_observer');h.write_json(b/'receipt.json',{'commands':runner.commands,'executable':h.pin(b/'wrf'),'original_source':h.pin(r/'WRF/dyn_em/solve_em.F'),'observer_source':h.pin(b/'solve_em.F'),'base_archive':h.pin(old/'libWRF_Core.a'),'new_archive':h.pin(b/'libWRF_Core.a'),'WQ_fields':fields,'SQ_fields':sf,'production_source_changed':False})
